# Test report — honest status

Environment used for this integration: Linux sandbox, JDK 21, **no Android SDK, no Gradle distribution, no network, no emulator/device**.

## Executed
- XML well-formedness of all 11 resource/manifest XML files, plus the workflow YAML: pass.
- Kotlin bracket/paren/brace balance across all 50 Kotlin files (tokenizer-based): pass.
- Duplicate top-level declarations in main sources: none.
- Project-package import resolution: all resolve (the only unresolved names are the generated `com.example.R`).
- Manifest component classes exist; every `@string/@drawable/@xml/@mipmap` and `R.*` reference resolves to a resource.
- MediaPipe assets present (face 3.76 MB, hand 7.82 MB).
- Independent Python re-derivation of the expected numbers used in `CoordinateMapperTest` (FILL_CENTER scale/offset, mirror equivalence, pixel-space roll): all assertions hold. This checks the math, **not** the Kotlin code.

## NOT executed (could not be, in this environment)
- Kotlin compilation, Gradle sync, lint, `testDebugUnitTest`, Robolectric tests, instrumented tests.
- Debug and release APK builds. **No APK exists in this delivery.**
- Any camera, face/hand tracking, PiP, floating HUD, accessibility, microphone, or Gemini network test on a device.
- Stability tests (repeated camera start/stop, PiP entry/exit, rotation, network loss).

New unit tests written but not run: `CoordinateMapperTest`, `AiEndpointUtilsTest`, `PermissionLogicTest`. Run them with `./gradlew :app:testDebugUnitTest` or let GitHub Actions do it.

## Treat as unverified until built and tried on a phone
Mask/hand alignment, front-camera mirroring, PiP overlay alignment, and Accessibility enabling on Android 13+ sideloads.
