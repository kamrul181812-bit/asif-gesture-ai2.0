# ASIF GESTURE AI

**Next-Generation AI Phone Controller, Intelligent Camera Assistant, Reels Controller & AI Chat Hub**

**Developer:** ASIF ISLAM  
**Target Hardware:** Symphony Inova 30 (Android 13 / API 33, 6 GB RAM, 2.0 GHz Octa-Core, ARM Mali-G57 @ 750 MHz)

---

## Key Features Implemented

1. **Crash-Resistant CameraX Pipeline (`camera/CameraController.kt`)**
   - `ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST` with single-thread background executor.
   - Unconditional `ImageProxy.close()` inside `finally {}` and `MPImage.close()` inside `finally {}` in MediaPipe engines to prevent native JNI leaks.
   - Synchronized (`bitmapLock`) reusable RGBA `Bitmap` & row-stride-safe copying to prevent cross-thread recycling races and `OutOfMemoryError`.
   - `WeakReference<PreviewView>` and `reattachPreviewIfRunning(...)` to avoid Activity/View leaks across tab switches and PiP transitions, plus `CameraState` error observer for camera conflicts.
   - Single-initialization lock (`AtomicBoolean`) and non-stacking inference guard.
   - Front/Rear camera switching, 320x240 / 480x360 / 640x480 resolution profiles, high-preview quality toggle, auto-recovery option, and FPS pacing.

2. **Adaptive Performance Engine (`performance/AdaptivePerformanceEngine.kt`)**
   - Profiles: **Battery Saver**, **Balanced (Symphony Inova 30 Default)**, and **Performance**.
   - Live monitoring of available RAM, process CPU time delta, thermal status (`PowerManager.getCurrentThermalStatus`), and per-pipeline latency (camera, face, hand).
   - Automatic throttling, face-tracking prioritization, animation reduction, and user warnings under load.

3. **Real-Time MediaPipe Face Landmarker & 6 Custom Cyber Masks (`face/`, `mask/`)**
   - Bundled `face_landmarker.task` (478 landmarks including iris), verified via asset check before model creation.
   - 6 landmark-aligned mask styles: Digital Anonymous, Cybernetic Robotic, Futuristic Neon Visor, Dark Digital Stealth, Minimal Black Cyber, and Custom Designer.
   - Live sliders for scale, width/height, offset X/Y, rotation, transparency, neon color, glow intensity, edge thickness, smoothing, and local preset saving.

4. **21-Point MediaPipe Hand Landmarker & 11 Gestures (`gesture/`)**
   - Bundled `hand_landmarker.task`, respecting performance-mode max hands (`1` in Battery Saver, `2` in Balanced/Performance).
   - Recognizes: Index Pointing, Pinch, Open Palm, Closed Fist, Swipe Up, Swipe Down, Two-Finger, Thumbs Up, Hand Wave, Pinch Spread, and Two-Hand Gestures.
   - Individually configurable action mappings, sensitivity, confidence threshold, activation delay, cooldown, one-tap hand baseline calibration, and Room-backed history.

5. **Virtual Mouse & Legitimate Accessibility Control (`virtualmouse/`, `accessibility/`, `service/`)**
   - 8 customizable cursor designs with live interactive preview pad + system-wide non-touchable Virtual Pointer overlay (`FloatingControlService`).
   - Authorized `GestureAccessibilityService` supporting tap, double-tap, scroll, Global Back, Home, and Recent Apps.
   - **Security Guard:** Automatically pauses automation and hides system pointer when password fields, lockscreens, permission dialogs, or banking/payment surfaces are active.

6. **Floating Overlay, Hidden Panel Mode & Android PiP (`service/FloatingControlService.kt`, `MainActivity.kt`)**
   - **Visible Mode**, **Mini Mode**, and **Hidden Panel Mode** (hides floating visual panel while keeping persistent notification with **Restore Panel** & **Emergency STOP** actions).
   - Customizable size preset, aspect ratio (`3:4`, `1:1`, `16:9`), corner radius, border color/thickness, edge snapping, and compact controls toggle.
   - Separate native Android Picture-in-Picture (`PictureInPictureParams`) support.
   - Never hides system privacy indicators.

7. **ASIF REELS MODE & Optional Eye Tracking (`reels/`, `eye/`)**
   - Finger gesture navigation + optional calibrated iris gaze zones and blink EAR detection.
   - Intentional-Like safety guard: eye gaze alone **never** triggers Like; requires deliberate user-configured Pinch with cooldown protection.

8. **Voice Control & Synthesized Sound Engine (`voice/`)**
   - On-demand Android `SpeechRecognizer` with visible listening status and immediate Stop control.
   - Low-latency synthesized `AudioTrack` cyber cues (Button, Gesture, Click, Camera, Mode Switch toggles) + optional `TextToSpeech` voice feedback.

9. **ASIF AI HUB (`aihub/`, `security/`)**
   - Supports OpenAI-compatible, Gemini OpenAI-compatible, Anthropic-compatible, and Custom REST endpoints.
   - Real endpoint validation, `/models` discovery, and live connection test before saving.
   - **Android Keystore (`AES/GCM/NoPadding`)** encryption for stored API keys; redacting logger (`AppLogger`) ensures keys are never logged.
   - Streaming SSE chat with Markdown/fenced code blocks, regenerate, stop generation, and Room chat history.

---

## MediaPipe Models & Licenses

Bundled in `app/src/main/assets/`:
- `face_landmarker.task` — Apache License 2.0 (`https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task`)
- `hand_landmarker.task` — Apache License 2.0 (`https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`)

---

## Build, Gradle Wrapper & GitHub Actions CI

### Prerequisites
- JDK 17+
- Android SDK (`compileSdk 36`, `minSdk 24`, `targetSdk 36`)
- Included Gradle Wrapper (`./gradlew` / `gradlew.bat` configured for Gradle `9.3.1`)

### Build Commands (Android Studio / Local / CI)
```bash
# Run JVM & Robolectric unit tests
./gradlew :app:testDebugUnitTest

# Build Debug APK
./gradlew :app:assembleDebug

# Build Release APK (requires signing keystore configured via KEYSTORE_PATH / STORE_PASSWORD / KEY_PASSWORD)
./gradlew :app:assembleRelease
```

### GitHub Actions Workflow (`.github/workflows/android-ci.yml`)
- Runs on Ubuntu with JDK 17, `./gradlew :app:testDebugUnitTest`, `./gradlew :app:assembleDebug`, and `./gradlew :app:compileReleaseKotlin :app:lintVitalRelease`.
- Automatically prepares `debug.keystore` on CI runners (decodes `debug.keystore.base64` or generates a standard Android debug keystore via `keytool` if absent — no manual keystore upload needed).
- Optionally decodes `RELEASE_KEYSTORE_BASE64` and builds/uploads a signed Release APK when `RELEASE_KEYSTORE_BASE64`, `STORE_PASSWORD`, and `KEY_PASSWORD` GitHub Secrets are configured.

### Release Keystore Guidance
Never commit `my-upload-key.jks` or keystore passwords to git. Provide:
- `KEYSTORE_PATH`: path to `.jks` keystore
- `STORE_PASSWORD`: keystore password
- `KEY_PASSWORD`: key password for alias `upload`

---

## Honest Verification & Test Scope

- **Unit & Robolectric JVM Tests (`:app:testDebugUnitTest`)**: Verified in the build environment (**14 tests total, 0 failures, 0 skipped** across `CoreModulesUnitTest` [8 tests], `ExampleRobolectricTest` [5 tests], and `ExampleUnitTest` [1 test] — covering gesture classification, eye tracking gaze zones, logger key redaction, AI Hub URL/header parsing, CameraController permission-denial safety, AccessibilityBridge protected-surface & emergency stop, VirtualMouseController bounds mapping, voice command parsing, Reels gaze safety guard, and Compose UI launch).
- **APK Build Verification**:
  - `:app:assembleDebug`: **Built & verified** (`app/build/outputs/apk/debug/app-debug.apk`, 101 MB including MediaPipe native JNI libraries and `.task` model assets).
  - `:app:compileReleaseKotlin` & `:app:lintVitalRelease`: **Passed** (`BUILD SUCCESSFUL`); `:app:packageRelease` requires a private `my-upload-key.jks` keystore (`KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD`) which is intentionally omitted from source control.
- **Physical Device / Soak Testing**: A physical **Symphony Inova 30** device and live ADB emulator are **not** available in this cloud build environment. Therefore, 30-minute / 60-minute / 2-hour hardware soak tests, live physical camera sensor feeds, real Android System Settings Accessibility toggling, and hardware thermal throttling curves have **not** been executed on physical hardware and should be validated on the target Symphony Inova 30 device before wide distribution.

---

## Merge notes (v1.0 + v2.0)

Base: v2.0 (application ID `com.aistudio.gestureai.asifvx`, namespace `com.example`, minSdk 24, release signing untouched).

| Area | Change |
|---|---|
| Tracking accuracy | New `core/CoordinateMapper.kt` (`FillCenterTransform`) ported from v1.0's verified FILL_CENTER mapping. Face mask, hand skeleton and mesh debug now share it. Engines report the upright analysis-image size; preview and analysis are both forced to 4:3 so the field of view matches. |
| Front-camera mask roll | v2.0 computed head roll from already-mirrored points (could flip ~180° on the front camera) and in normalized units. Now computed in pixel units and mirror-independent (`FaceGeometry`). |
| Accessibility | Service is `exported="true"` with `BIND_ACCESSIBILITY_SERVICE` (v1.0 declaration). Honest 3-state status helper, Restricted-Settings guidance + App Info shortcut in the Permission Manager card, status refreshed on resume. |
| AI Hub / Gemini | `AiEndpointUtils`: single-slash URL joining, `models/` prefix stripped from discovered/selected model IDs, per-status (400/401/403/404/429/5xx) error text. Keys are never logged. |
| Branding | Original **ASIF GESTURE AI** name kept. New adaptive launcher icon (vector + legacy PNGs); 512px store icon in `docs/`. |
| CI | `.github/workflows/android-ci.yml` fixed: `secrets` cannot be used in step-level `if`, so a job-level boolean is used for the optional signed release. |

Restricted Settings (Android 13+ sideloaded apps) cannot be bypassed in code: Settings → Apps → ASIF GESTURE AI → ⋮ → *Allow restricted settings* → Accessibility → enable.

## Build

```
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug        # app/build/outputs/apk/debug/app-debug.apk
```
Or push to GitHub: the workflow runs tests, builds the debug APK and uploads it as an artifact. For a signed release add secrets `RELEASE_KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_PASSWORD`.

## Verification status
See `TEST_REPORT.md` for exactly what was and was not executed.
