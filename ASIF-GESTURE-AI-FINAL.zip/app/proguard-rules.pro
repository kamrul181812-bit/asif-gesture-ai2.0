# ASIF GESTURE AI 2.0 - ProGuard / R8 Keep Rules

-keepattributes SourceFile,LineNumberTable
-keepattributes *Annotation*,InnerClasses

# MediaPipe Tasks Vision & JNI
-keep class com.google.mediapipe.** { *; }
-dontwarn com.google.mediapipe.**

# Kotlinx Serialization
-keepattributes Signature
-keepclassmembers class kotlinx.serialization.json.** { *; }
-keep,includedescriptorclasses class com.asif.gestureai.settings.**$$serializer { *; }
-keep,includedescriptorclasses class com.asif.gestureai.ui.navigation.**$$serializer { *; }

# Accessibility & Foreground Services
-keep class com.asif.gestureai.accessibility.GestureAccessibilityService { *; }
-keep class com.asif.gestureai.service.FloatingControlService { *; }
