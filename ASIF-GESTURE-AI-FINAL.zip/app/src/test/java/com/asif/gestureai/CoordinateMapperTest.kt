package com.asif.gestureai

import com.asif.gestureai.core.CoordinateMapper
import com.asif.gestureai.core.FillCenterTransform
import com.asif.gestureai.face.FaceGeometry
import com.asif.gestureai.face.FacePoint
import org.junit.Assert.assertEquals
import org.junit.Test

class CoordinateMapperTest {

    private val eps = 0.01f

    @Test
    fun uprightSize_swapsOnQuarterTurns() {
        assertEquals(480, CoordinateMapper.uprightWidth(640, 480, 90))
        assertEquals(640, CoordinateMapper.uprightHeight(640, 480, 90))
        assertEquals(480, CoordinateMapper.uprightWidth(640, 480, 270))
        assertEquals(640, CoordinateMapper.uprightWidth(640, 480, 0))
        assertEquals(480, CoordinateMapper.uprightHeight(640, 480, 180))
        assertEquals(480, CoordinateMapper.uprightWidth(640, 480, -90)) // normalizes negative angles
    }

    @Test
    fun mirrorX_onlyFlipsFrontCamera() {
        assertEquals(0.8f, CoordinateMapper.mirrorX(0.2f, true), eps)
        assertEquals(0.2f, CoordinateMapper.mirrorX(0.2f, false), eps)
        assertEquals(0.5f, CoordinateMapper.mirrorX(0.5f, true), eps)
    }

    @Test
    fun fillCenter_tallPhone_cropsSidesAndCentersImage() {
        // Upright analysis image 480x640 (3:4) shown on a 1080x2400 canvas: scale = max(2.25, 3.75) = 3.75
        val t = FillCenterTransform(480, 640, 1080f, 2400f)
        assertEquals(1800f, t.scaledWidth, eps)
        assertEquals(2400f, t.scaledHeight, eps)
        assertEquals(-360f, t.offsetX, eps)
        assertEquals(0f, t.offsetY, eps)
        // Image centre must land on canvas centre
        assertEquals(540f, t.x(0.5f), eps)
        assertEquals(1200f, t.y(0.5f), eps)
        // Left image edge is cropped off-screen (negative x), right edge past the canvas width
        assertEquals(-360f, t.x(0f), eps)
        assertEquals(1440f, t.x(1f), eps)
    }

    @Test
    fun fillCenter_wideCanvas_cropsTopAndBottom() {
        val t = FillCenterTransform(480, 640, 1200f, 800f) // scale = max(2.5, 1.25) = 2.5
        assertEquals(1200f, t.scaledWidth, eps)
        assertEquals(1600f, t.scaledHeight, eps)
        assertEquals(0f, t.offsetX, eps)
        assertEquals(-400f, t.offsetY, eps)
        assertEquals(600f, t.x(0.5f), eps)
        assertEquals(400f, t.y(0.5f), eps)
    }

    @Test
    fun fillCenter_isUniformScale_noStretch() {
        val t = FillCenterTransform(480, 640, 1080f, 2400f)
        val pxPerNormX = t.scaledWidth / 480f
        val pxPerNormY = t.scaledHeight / 640f
        assertEquals(pxPerNormX, pxPerNormY, 0.0001f)
    }

    @Test
    fun fillCenter_inverseRoundTrips() {
        val t = FillCenterTransform(480, 640, 1080f, 2400f)
        val nx = 0.37f
        val ny = 0.81f
        assertEquals(nx, t.normX(t.x(nx)), 0.0001f)
        assertEquals(ny, t.normY(t.y(ny)), 0.0001f)
    }

    @Test
    fun fillCenter_unknownImageSize_fallsBackToStretchWithoutCrashing() {
        val t = FillCenterTransform(0, 0, 1080f, 2400f)
        assertEquals(540f, t.x(0.5f), eps)
        assertEquals(1200f, t.y(0.5f), eps)
    }

    @Test
    fun frontCamera_mirroredLandmark_landsOnMirroredPreviewPixel() {
        // Subject's feature at x=0.2 of the unmirrored upright frame appears at 0.8 in the mirrored preview.
        val t = FillCenterTransform(480, 640, 1080f, 2400f)
        val mirrored = CoordinateMapper.mirrorX(0.2f, true)
        val mirroredPreviewPx = 1080f - t.x(0.2f) // flipping the whole preview horizontally about its centre
        // x(0.8) = 0.8*1800-360 = 1080 - (0.2*1800-360) = 1080-0 = 1080 ; check equality of the two derivations
        assertEquals(mirroredPreviewPx, t.x(mirrored), eps)
    }

    @Test
    fun roll_zeroForLevelEyes_bothMirroredAndNot() {
        val level = MutableList(478) { FacePoint(0.5f, 0.5f) }
        level[33] = FacePoint(0.35f, 0.40f)
        level[263] = FacePoint(0.65f, 0.40f)
        assertEquals(0f, FaceGeometry.computeRollDegrees(level, 480, 640), eps)

        // Front camera mirroring swaps the x-order of the two eye corners; roll must still be 0 (not ~180).
        val mirrored = level.toMutableList()
        mirrored[33] = FacePoint(0.65f, 0.40f)
        mirrored[263] = FacePoint(0.35f, 0.40f)
        assertEquals(0f, FaceGeometry.computeRollDegrees(mirrored, 480, 640), eps)
    }

    @Test
    fun roll_usesPixelUnits_notNormalizedUnits() {
        val pts = MutableList(478) { FacePoint(0.5f, 0.5f) }
        // dx = 0.3*480 = 144 px, dy = 0.225*640 = 144 px  => exactly 45 degrees in pixel space
        pts[33] = FacePoint(0.35f, 0.4f)
        pts[263] = FacePoint(0.65f, 0.625f)
        assertEquals(45f, FaceGeometry.computeRollDegrees(pts, 480, 640), 0.05f)
    }
}
