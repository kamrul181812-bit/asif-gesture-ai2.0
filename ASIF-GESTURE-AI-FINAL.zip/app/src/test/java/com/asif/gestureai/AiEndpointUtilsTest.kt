package com.asif.gestureai

import com.asif.gestureai.aihub.AiAdapterType
import com.asif.gestureai.aihub.AiEndpointUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AiEndpointUtilsTest {

    @Test
    fun geminiDefaults_matchDocumentedOpenAiCompatEndpoint() {
        val g = AiAdapterType.GEMINI_COMPAT
        assertEquals("gemini-2.5-flash", g.defaultModel)
        assertEquals(
            "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
            AiEndpointUtils.chatUrl(g.defaultBaseUrl, g.defaultChatPath)
        )
    }

    @Test
    fun chatUrl_hasExactlyOneSlash_whateverTheInputSlashes() {
        val expected = "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions"
        assertEquals(expected, AiEndpointUtils.chatUrl("https://generativelanguage.googleapis.com/v1beta/openai/", "chat/completions"))
        assertEquals(expected, AiEndpointUtils.chatUrl("https://generativelanguage.googleapis.com/v1beta/openai", "/chat/completions"))
        assertEquals(expected, AiEndpointUtils.chatUrl("  https://generativelanguage.googleapis.com/v1beta/openai//", " /chat/completions "))
    }

    @Test
    fun modelsUrl_isBasePlusModels() {
        assertEquals("https://api.openai.com/v1/models", AiEndpointUtils.modelsUrl("https://api.openai.com/v1/"))
    }

    @Test
    fun normalizeModelId_stripsModelsPrefixOnly() {
        assertEquals("gemini-2.5-flash", AiEndpointUtils.normalizeModelId("models/gemini-2.5-flash"))
        assertEquals("gemini-2.5-flash", AiEndpointUtils.normalizeModelId("  Models/gemini-2.5-flash "))
        assertEquals("gemini-2.5-flash", AiEndpointUtils.normalizeModelId("gemini-2.5-flash"))
        assertEquals("gpt-4o-mini", AiEndpointUtils.normalizeModelId("gpt-4o-mini"))
        assertEquals("org/models/x", AiEndpointUtils.normalizeModelId("org/models/x"))
    }

    @Test
    fun describeHttpError_coversAllRequiredStatusCodes() {
        listOf(400, 401, 403, 404, 429, 500).forEach { code ->
            val msg = AiEndpointUtils.describeHttpError(code, "provider detail")
            assertTrue("code $code should be mentioned", msg.contains(code.toString()))
            assertTrue(msg.contains("provider detail"))
        }
        assertTrue(AiEndpointUtils.describeHttpError(429, "").contains("Rate limited"))
        assertTrue(AiEndpointUtils.describeHttpError(503, "").contains("server error"))
        assertFalse(AiEndpointUtils.describeHttpError(401, "").contains("—"))
    }
}
