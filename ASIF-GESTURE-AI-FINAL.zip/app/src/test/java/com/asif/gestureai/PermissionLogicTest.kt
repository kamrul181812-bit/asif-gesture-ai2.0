package com.asif.gestureai

import android.os.Build
import com.asif.gestureai.core.PermissionHelper
import com.asif.gestureai.core.PermissionHelper.AccessibilityState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PermissionLogicTest {

    @Test
    fun accessibilityState_neverReportsEnabledWhenDisabled() {
        assertEquals(AccessibilityState.DISABLED, PermissionHelper.resolveAccessibilityState(false, false))
        assertEquals(AccessibilityState.ENABLED_NOT_CONNECTED, PermissionHelper.resolveAccessibilityState(true, false))
        assertEquals(AccessibilityState.ENABLED_AND_CONNECTED, PermissionHelper.resolveAccessibilityState(true, true))
        assertEquals(AccessibilityState.ENABLED_AND_CONNECTED, PermissionHelper.resolveAccessibilityState(false, true))
    }

    @Test
    fun restrictedSettings_predictedForSideloadedAndroid13Plus() {
        val t = Build.VERSION_CODES.TIRAMISU
        assertTrue(PermissionHelper.isRestrictedSettingsLikely(t, null))
        assertTrue(PermissionHelper.isRestrictedSettingsLikely(34, "com.google.android.apps.nbu.files"))
        assertFalse(PermissionHelper.isRestrictedSettingsLikely(34, "com.android.vending"))
        assertFalse(PermissionHelper.isRestrictedSettingsLikely(Build.VERSION_CODES.S, null)) // Android 12 and older: not applicable
    }

    @Test
    fun restrictedSettingsSteps_mentionEveryRequiredStep() {
        val s = PermissionHelper.RESTRICTED_SETTINGS_STEPS
        assertTrue(s.contains("Allow restricted settings"))
        assertTrue(s.contains("App Info"))
        assertTrue(s.contains("Accessibility"))
    }
}
