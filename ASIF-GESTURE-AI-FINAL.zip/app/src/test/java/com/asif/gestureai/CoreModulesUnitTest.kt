package com.asif.gestureai

import android.content.Context
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.test.core.app.ApplicationProvider
import com.asif.gestureai.accessibility.AccessibilityBridge
import com.asif.gestureai.aihub.AiHubClient
import com.asif.gestureai.camera.CameraController
import com.asif.gestureai.camera.CameraStatus
import com.asif.gestureai.core.AppLogger
import com.asif.gestureai.eye.EyeTrackingEngine
import com.asif.gestureai.eye.GazeZone
import com.asif.gestureai.eye.LightingQuality
import com.asif.gestureai.face.FacePoint
import com.asif.gestureai.face.FaceTrackingResult
import com.asif.gestureai.gesture.GestureLiveState
import com.asif.gestureai.gesture.GestureRecognizer
import com.asif.gestureai.gesture.HandTrackingResult
import com.asif.gestureai.gesture.TrackedHand
import com.asif.gestureai.performance.AdaptivePerformanceEngine
import com.asif.gestureai.performance.PerformanceMode
import com.asif.gestureai.settings.CameraSettings
import com.asif.gestureai.settings.EyeTrackingSettings
import com.asif.gestureai.settings.GestureSettings
import com.asif.gestureai.settings.GestureType
import com.asif.gestureai.settings.VirtualMouseSettings
import com.asif.gestureai.virtualmouse.VirtualMouseController
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CoreModulesUnitTest {

    private fun baseHandLandmarks(): MutableList<FacePoint> {
        // 21 landmarks normalized near center, wrist at (0.5, 0.8), MCPs around y=0.55
        return MutableList(21) { FacePoint(0.5f, 0.55f) }.apply {
            this[0] = FacePoint(0.5f, 0.82f) // wrist
            this[1] = FacePoint(0.42f, 0.72f)
            this[2] = FacePoint(0.38f, 0.64f)
            this[3] = FacePoint(0.36f, 0.58f)
            this[4] = FacePoint(0.34f, 0.54f) // thumb tip
            this[5] = FacePoint(0.44f, 0.56f)
            this[6] = FacePoint(0.44f, 0.50f)
            this[7] = FacePoint(0.44f, 0.54f)
            this[8] = FacePoint(0.44f, 0.58f) // index tip curled by default
            this[9] = FacePoint(0.50f, 0.55f) // middle MCP
            this[10] = FacePoint(0.50f, 0.50f)
            this[11] = FacePoint(0.50f, 0.54f)
            this[12] = FacePoint(0.50f, 0.58f) // middle tip curled
            this[13] = FacePoint(0.56f, 0.56f)
            this[14] = FacePoint(0.56f, 0.50f)
            this[15] = FacePoint(0.56f, 0.54f)
            this[16] = FacePoint(0.56f, 0.58f) // ring tip curled
            this[17] = FacePoint(0.62f, 0.58f)
            this[18] = FacePoint(0.62f, 0.52f)
            this[19] = FacePoint(0.62f, 0.56f)
            this[20] = FacePoint(0.62f, 0.60f) // pinky tip curled
        }
    }

    @Test
    fun `gesture recognizer classifies pinch, open palm, peace, index point, and two hands`() {
        val recognizer = GestureRecognizer()
        val settings = GestureSettings(enabled = true, activationDelayMs = 0L, cooldownMs = 0L)

        // Open palm: all fingers extended above PIPs
        val palmPts = baseHandLandmarks().apply {
            this[8] = FacePoint(0.44f, 0.30f)
            this[12] = FacePoint(0.50f, 0.28f)
            this[16] = FacePoint(0.56f, 0.30f)
            this[20] = FacePoint(0.62f, 0.34f)
        }
        val palmState = recognizer.process(
            HandTrackingResult(listOf(TrackedHand(palmPts, "Right", 0.95f))),
            settings,
            nowMs = 1000L
        )
        assertEquals(GestureType.OPEN_PALM, palmState.detectedGesture)

        // Pinch: thumb tip close to index tip
        val pinchPts = baseHandLandmarks().apply {
            this[4] = FacePoint(0.44f, 0.45f)
            this[8] = FacePoint(0.45f, 0.45f)
        }
        val pinchState = recognizer.process(
            HandTrackingResult(listOf(TrackedHand(pinchPts, "Right", 0.95f))),
            settings,
            nowMs = 2000L
        )
        assertEquals(GestureType.PINCH, pinchState.detectedGesture)
        assertTrue(pinchState.isPinching)

        // Two-hand gesture
        val twoHandState = recognizer.process(
            HandTrackingResult(
                listOf(
                    TrackedHand(palmPts, "Left", 0.9f),
                    TrackedHand(palmPts, "Right", 0.9f)
                )
            ),
            settings,
            nowMs = 3000L
        )
        assertEquals(GestureType.TWO_HAND, twoHandState.detectedGesture)
        assertTrue(twoHandState.twoHandsPresent)
    }

    @Test
    fun `eye tracking engine detects gaze zones and lighting quality`() {
        val engine = EyeTrackingEngine()
        val facePts = MutableList(478) { FacePoint(0.5f, 0.5f) }.apply {
            // Left eye box: x [0.3, 0.4], y [0.4, 0.45]
            this[33] = FacePoint(0.30f, 0.425f)
            this[133] = FacePoint(0.40f, 0.425f)
            this[159] = FacePoint(0.35f, 0.40f)
            this[145] = FacePoint(0.35f, 0.45f)
            this[468] = FacePoint(0.31f, 0.425f) // looking far left

            // Right eye box: x [0.6, 0.7], y [0.4, 0.45]
            this[362] = FacePoint(0.60f, 0.425f)
            this[263] = FacePoint(0.70f, 0.425f)
            this[386] = FacePoint(0.65f, 0.40f)
            this[374] = FacePoint(0.65f, 0.45f)
            this[473] = FacePoint(0.61f, 0.425f) // looking far left
        }
        val state = engine.update(
            face = FaceTrackingResult(detected = true, landmarks = facePts),
            avgLuminance = 0.55f,
            settings = EyeTrackingSettings(enabled = true, sensitivity = 0.8f),
            nowMs = 1000L
        )
        assertTrue(state.detected)
        assertEquals(GazeZone.LEFT, state.gazeZone)
        assertEquals(LightingQuality.GOOD, state.lightingQuality)
    }

    @Test
    fun `logger redacts api keys and bearer tokens`() {
        val raw = "Authorization: Bearer sk-abc123456789xyz and key AIzaSyD1234567890abcdefg"
        val safe = AppLogger.redact(raw)
        assertFalse(safe.contains("sk-abc123456789xyz"))
        assertFalse(safe.contains("AIzaSyD1234567890abcdefg"))
        assertTrue(safe.contains("REDACTED"))
    }

    @Test
    fun `ai hub client validates endpoint urls and custom headers`() {
        val client = AiHubClient()
        assertTrue(client.validateUrlSyntax("https://api.openai.com/v1"))
        assertTrue(client.validateUrlSyntax("http://192.168.1.50:11434/v1"))
        assertFalse(client.validateUrlSyntax("not-a-url"))
        val headers = client.parseHeaders("""{"X-Title":"AsifGestureAI"}""")
        assertEquals("AsifGestureAI", headers["X-Title"])
    }

    @Test
    fun `symphony inova 30 balanced mode uses 480x360 and adaptive throttling`() {
        assertEquals(480, PerformanceMode.BALANCED.analysisSize.width)
        assertEquals(360, PerformanceMode.BALANCED.analysisSize.height)
        assertEquals(1, PerformanceMode.BATTERY_SAVER.maxHands)
    }

    @Test
    fun `camera controller handles missing permission safely without crashing`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val perf = AdaptivePerformanceEngine(context)
        val controller = CameraController(context, perf)
        val owner = object : LifecycleOwner {
            private val reg = LifecycleRegistry(this).apply { currentState = Lifecycle.State.STARTED }
            override val lifecycle: Lifecycle = reg
        }
        controller.startCamera(owner, null, CameraSettings())
        assertTrue(controller.status.value is CameraStatus.Error)
        controller.shutdown()
        assertEquals(CameraStatus.Stopped, controller.status.value)
    }

    @Test
    fun `accessibility bridge pauses on protected surfaces and stops on emergency`() {
        AccessibilityBridge.setPaused(false)
        AccessibilityBridge.updateProtectedPause(true, "Banking screen active")
        assertTrue(AccessibilityBridge.status.value.protectedSurfacePaused)
        assertFalse(AccessibilityBridge.performTap(100f, 100f))

        AccessibilityBridge.updateProtectedPause(false, null)
        AccessibilityBridge.emergencyStop()
        assertTrue(AccessibilityBridge.status.value.paused)
        assertEquals("EMERGENCY STOP activated", AccessibilityBridge.status.value.lastAction)
        AccessibilityBridge.setPaused(false)
    }

    @Test
    fun `virtual mouse controller maps hand pointer coordinates within safe screen bounds`() {
        val controller = VirtualMouseController()
        val settings = VirtualMouseSettings(enabled = true, sensitivity = 1.5f, calibrationPadding = 0.1f)
        controller.updateFromGesture(
            gestureState = GestureLiveState(handPresent = true, pointerX = 0.5f, pointerY = 0.5f, isPinching = false),
            settings = settings,
            screenWidthPx = 1080,
            screenHeightPx = 2400,
            nowMs = 100L
        )
        val centered = controller.mouseState.value
        assertTrue(centered.active)
        assertEquals(0.5f, centered.normX, 0.02f)
        assertEquals(0.5f, centered.normY, 0.02f)

        controller.updateFromGesture(
            gestureState = GestureLiveState(handPresent = true, pointerX = 0.0f, pointerY = 1.0f, isPinching = false),
            settings = settings,
            screenWidthPx = 1080,
            screenHeightPx = 2400,
            nowMs = 200L
        )
        val clamped = controller.mouseState.value
        assertEquals(0.02f, clamped.normX, 0.001f)
        assertEquals(0.98f, clamped.normY, 0.001f)
    }
}
