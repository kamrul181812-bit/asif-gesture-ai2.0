package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.test.core.app.ApplicationProvider
import com.asif.gestureai.eye.EyeTrackingState
import com.asif.gestureai.eye.GazeZone
import com.asif.gestureai.performance.AdaptivePerformanceEngine
import com.asif.gestureai.reels.ReelsModeController
import com.asif.gestureai.settings.ReelsModeSettings
import com.asif.gestureai.voice.VoiceCommandIntent
import com.asif.gestureai.voice.VoiceControlManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `read updated app_name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Gesture AI 2.0", appName)
    }

    @Test
    fun `main dashboard renders HUD title and emergency stop`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithText("ASIF GESTURE AI 2.0").assertIsDisplayed()
        composeRule.onNodeWithTag("emergency_stop_button").assertIsDisplayed()
    }

    @Test
    fun `voice command parser maps core commands accurately`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val voice = VoiceControlManager(context)

        assertEquals(VoiceCommandIntent.START_CAMERA, voice.parseTranscript("start camera").intent)
        assertEquals(VoiceCommandIntent.ENABLE_MASK, voice.parseTranscript("enable mask").intent)
        assertEquals(VoiceCommandIntent.MODE_BATTERY_SAVER, voice.parseTranscript("switch to battery saver").intent)
        assertEquals(VoiceCommandIntent.OPEN_AI_HUB, voice.parseTranscript("open ai hub").intent)
        val openApp = voice.parseTranscript("open youtube")
        assertEquals(VoiceCommandIntent.OPEN_APP, openApp.intent)
        assertEquals("youtube", openApp.appTargetQuery)
    }

    @Test
    fun `reels controller never auto-likes from eye gaze alone`() {
        val controller = ReelsModeController()
        controller.setActive(true)
        val eye = EyeTrackingState(
            detected = true,
            gazeZone = GazeZone.CENTER,
            confidence = 0.95f,
            blinkDetected = true,
            dwellProgress = 1.0f
        )
        val res = controller.handleEyeGaze(
            eyeState = eye,
            settings = ReelsModeSettings(active = true, gazeScrollEnabled = true),
            nowMs = 5000L
        )
        assertNull(res)
    }

    @Test
    fun `adaptive performance engine samples memory metrics cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = AdaptivePerformanceEngine(context)
        engine.sampleSystemMetrics()
        assertTrue(engine.telemetry.value.totalMemoryMb >= 0L)
    }
}
