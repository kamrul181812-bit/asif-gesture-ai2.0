package com.asif.gestureai.ui.components

import androidx.camera.view.PreviewView
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.asif.gestureai.camera.CameraStatus
import com.asif.gestureai.face.FaceTrackingResult
import com.asif.gestureai.gesture.HandOverlayCanvas
import com.asif.gestureai.gesture.HandTrackingResult
import com.asif.gestureai.mask.MaskOverlayCanvas
import com.asif.gestureai.settings.MaskSettings
import com.asif.gestureai.settings.VirtualMouseSettings
import com.asif.gestureai.virtualmouse.VirtualCursorGlyph
import com.asif.gestureai.virtualmouse.VirtualMouseState
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    borderColor: Color = GlassBorder,
    backgroundColor: Color = GlassSurface,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = backgroundColor,
        border = BorderStroke(1.dp, borderColor),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun StatusPill(
    label: String,
    active: Boolean,
    accentColor: Color = NeonEmerald,
    modifier: Modifier = Modifier
) {
    val dotColor by animateColorAsState(
        targetValue = if (active) accentColor else TextMuted,
        label = "statusDot"
    )
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(if (active) accentColor.copy(alpha = 0.14f) else DeepSlate)
            .border(
                width = 1.dp,
                color = if (active) accentColor.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.08f),
                shape = RoundedCornerShape(50)
            )
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) Color.White else TextSecondary
        )
    }
}

@Composable
fun HudMetricBar(
    label: String,
    valueText: String,
    progress: Float,
    color: Color = ElectricBlue,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text(text = valueText, style = MaterialTheme.typography.labelMedium, color = color)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = Color.White.copy(alpha = 0.08f)
        )
    }
}

@Composable
fun CameraViewportSurface(
    cameraStatus: CameraStatus,
    faceResult: FaceTrackingResult,
    handResult: HandTrackingResult,
    maskSettings: MaskSettings,
    mouseState: VirtualMouseState,
    mouseSettings: VirtualMouseSettings,
    showLandmarks: Boolean,
    onPreviewViewCreated: (PreviewView) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .clip(MaterialTheme.shapes.large)
            .background(
                Brush.verticalGradient(listOf(Color(0xFF09111D), ObsidianBlack))
            )
            .border(1.dp, GlassBorder, MaterialTheme.shapes.large)
    ) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)

        AndroidView(
            factory = { ctx ->
                PreviewView(ctx).apply {
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    onPreviewViewCreated(this)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (cameraStatus !is CameraStatus.Running) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ObsidianBlack.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(20.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VideocamOff,
                        contentDescription = "Camera inactive",
                        tint = if (cameraStatus is CameraStatus.Error) AlertCrimson else ElectricBlue,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = when (cameraStatus) {
                            is CameraStatus.Starting -> "Initializing CameraX..."
                            is CameraStatus.Error -> cameraStatus.message
                            CameraStatus.Stopped -> "Camera Standby • Tap Start Camera"
                            is CameraStatus.Running -> ""
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (cameraStatus is CameraStatus.Error) AlertCrimson else TextSecondary
                    )
                }
            }
        }

        // Dynamic Landmark-Aligned Cyber Mask
        MaskOverlayCanvas(
            faceResult = faceResult,
            maskSettings = maskSettings,
            showFaceMeshDebug = showLandmarks
        )

        // 21-Point Hand Skeleton Overlay
        HandOverlayCanvas(
            handResult = handResult,
            showLandmarks = showLandmarks
        )

        // Virtual Cursor Preview Inside Viewport
        if (mouseState.active && mouseSettings.enabled) {
            Box(
                modifier = Modifier.offset {
                    IntOffset(
                        x = (mouseState.normX * widthPx - 28f).roundToInt(),
                        y = (mouseState.normY * heightPx - 28f).roundToInt()
                    )
                }
            ) {
                VirtualCursorGlyph(
                    design = mouseSettings.cursorDesign,
                    color = Color(mouseSettings.cursorColorArgb.toInt()),
                    sizeDp = mouseSettings.cursorSizeDp,
                    neonGlow = mouseSettings.neonGlowEnabled,
                    isClicking = mouseState.isClicking
                )
            }
        }
    }
}
