package com.asif.gestureai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.asif.gestureai.accessibility.AccessibilityBridge
import com.asif.gestureai.accessibility.AccessibilityStatus
import com.asif.gestureai.data.local.GestureHistoryEntity
import com.asif.gestureai.eye.EyeTrackingState
import com.asif.gestureai.gesture.GestureLiveState
import com.asif.gestureai.reels.ReelsRuntimeState
import com.asif.gestureai.settings.AllAppSettings
import com.asif.gestureai.settings.CursorDesign
import com.asif.gestureai.settings.EyeTrackingSettings
import com.asif.gestureai.settings.GestureAction
import com.asif.gestureai.settings.GestureSettings
import com.asif.gestureai.settings.GestureType
import com.asif.gestureai.settings.ReelsModeSettings
import com.asif.gestureai.settings.VirtualMouseSettings
import com.asif.gestureai.ui.components.GlassCard
import com.asif.gestureai.ui.components.HudMetricBar
import com.asif.gestureai.ui.components.StatusPill
import com.asif.gestureai.virtualmouse.VirtualCursorGlyph
import com.asif.gestureai.virtualmouse.VirtualMouseState
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GlassBorderBlue
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun GestureMouseScreen(
    initialTab: Int,
    settings: AllAppSettings,
    gestureLiveState: GestureLiveState,
    gestureHistory: List<GestureHistoryEntity>,
    eyeState: EyeTrackingState,
    mouseState: VirtualMouseState,
    reelsState: ReelsRuntimeState,
    accessibilityStatus: AccessibilityStatus,
    onUpdateGesture: ((GestureSettings) -> GestureSettings) -> Unit,
    onUpdateMouse: ((VirtualMouseSettings) -> VirtualMouseSettings) -> Unit,
    onUpdateReels: ((ReelsModeSettings) -> ReelsModeSettings) -> Unit,
    onUpdateEye: ((EyeTrackingSettings) -> EyeTrackingSettings) -> Unit,
    onCalibrateEyeCenter: () -> Unit,
    onCalibrateGesture: () -> Unit,
    onToggleReelsMode: (Boolean) -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onEmergencyStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab.coerceIn(0, 3)) }
    val tabs = listOf("Gestures", "Virtual Mouse", "Reels Mode", "Eye Gaze")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DeepSlate,
                contentColor = NeonEmerald
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, style = MaterialTheme.typography.labelLarge) }
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (selectedTab) {
                    0 -> GesturesTabContent(settings.gesture, gestureLiveState, gestureHistory, onCalibrateGesture, onUpdateGesture)
                    1 -> VirtualMouseTabContent(settings.virtualMouse, mouseState, accessibilityStatus, onUpdateMouse, onOpenAccessibilitySettings)
                    2 -> ReelsModeTabContent(settings.reels, reelsState, eyeState, accessibilityStatus, onUpdateReels, onToggleReelsMode, onOpenAccessibilitySettings, onEmergencyStop)
                    3 -> EyeTrackingTabContent(settings.eyeTracking, eyeState, onUpdateEye, onCalibrateEyeCenter)
                }
            }
        }
    }
}

@Composable
private fun GesturesTabContent(
    gestureSettings: GestureSettings,
    liveState: GestureLiveState,
    history: List<GestureHistoryEntity>,
    onCalibrateGesture: () -> Unit,
    onUpdate: ((GestureSettings) -> GestureSettings) -> Unit
) {
    GlassCard(borderColor = NeonEmerald.copy(alpha = 0.4f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("AI Hand Gesture Engine", style = MaterialTheme.typography.titleMedium)
                Text("21-landmark MediaPipe tracking", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Switch(
                checked = gestureSettings.enabled,
                onCheckedChange = { v -> onUpdate { it.copy(enabled = v) } },
                modifier = Modifier.testTag("gesture_enable_switch")
            )
        }
        Spacer(Modifier.height(10.dp))
        StatusPill(
            label = if (liveState.detectedGesture != null) {
                "Live: ${liveState.detectedGesture.displayName} (${(liveState.confidence * 100).toInt()}%)"
            } else if (liveState.handPresent) {
                "Hand Detected • Analyzing Pose"
            } else {
                "No Hand in Frame"
            },
            active = liveState.handPresent
        )
        Spacer(Modifier.height(10.dp))
        Text("Sensitivity: ${String.format("%.2f", gestureSettings.sensitivity)}", style = MaterialTheme.typography.labelSmall)
        Slider(
            value = gestureSettings.sensitivity,
            onValueChange = { v -> onUpdate { it.copy(sensitivity = v) } },
            valueRange = 0.2f..1.0f
        )
        Text("Confidence Threshold: ${(gestureSettings.confidenceThreshold * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
        Slider(
            value = gestureSettings.confidenceThreshold,
            onValueChange = { v -> onUpdate { it.copy(confidenceThreshold = v) } },
            valueRange = 0.4f..0.95f
        )
        Text("Activation Delay: ${gestureSettings.activationDelayMs} ms", style = MaterialTheme.typography.labelSmall)
        Slider(
            value = gestureSettings.activationDelayMs.toFloat(),
            onValueChange = { v -> onUpdate { it.copy(activationDelayMs = v.toLong()) } },
            valueRange = 0f..500f
        )
        Text("Cooldown: ${gestureSettings.cooldownMs} ms", style = MaterialTheme.typography.labelSmall)
        Slider(
            value = gestureSettings.cooldownMs.toFloat(),
            onValueChange = { v -> onUpdate { it.copy(cooldownMs = v.toLong()) } },
            valueRange = 200f..1500f
        )
        Spacer(Modifier.height(6.dp))
        OutlinedButton(
            onClick = onCalibrateGesture,
            modifier = Modifier.fillMaxWidth().testTag("calibrate_gesture_button")
        ) {
            Icon(Icons.Rounded.CenterFocusStrong, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("Calibrate Hand Baseline")
        }
    }

    Text("11 Gesture Action Mappings", style = MaterialTheme.typography.titleSmall, color = ElectricBlue)
    GestureType.entries.forEach { gesture ->
        val enabled = gestureSettings.enabledGestures[gesture.name] ?: true
        val mappedName = gestureSettings.actionMappings[gesture.name] ?: GestureAction.NONE.name
        val mappedAction = runCatching { GestureAction.valueOf(mappedName) }.getOrDefault(GestureAction.NONE)
        var menuOpen by remember { mutableStateOf(false) }

        GlassCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(gesture.displayName, style = MaterialTheme.typography.titleSmall)
                    Text(gesture.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
                Switch(
                    checked = enabled,
                    onCheckedChange = { on ->
                        onUpdate {
                            it.copy(enabledGestures = it.enabledGestures + (gesture.name to on))
                        }
                    }
                )
            }
            Spacer(Modifier.height(6.dp))
            Box {
                OutlinedButton(onClick = { menuOpen = true }) {
                    Text("Action: ${mappedAction.displayName}", style = MaterialTheme.typography.labelSmall)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    GestureAction.entries.forEach { action ->
                        DropdownMenuItem(
                            text = { Text(action.displayName) },
                            onClick = {
                                menuOpen = false
                                onUpdate {
                                    it.copy(actionMappings = it.actionMappings + (gesture.name to action.name))
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (history.isNotEmpty()) {
        GlassCard {
            Text("Recent Gesture History", style = MaterialTheme.typography.titleSmall, color = NeonEmerald)
            Spacer(Modifier.height(6.dp))
            history.take(8).forEach { entry ->
                Text(
                    text = "• ${entry.gestureName} → ${entry.actionName} (${(entry.confidence * 100).toInt()}%)",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VirtualMouseTabContent(
    mouseSettings: VirtualMouseSettings,
    mouseState: VirtualMouseState,
    accessibilityStatus: AccessibilityStatus,
    onUpdate: ((VirtualMouseSettings) -> VirtualMouseSettings) -> Unit,
    onOpenAccessibilitySettings: () -> Unit
) {
    val swatches = listOf(0xFF00D4FFL, 0xFF00FF88L, 0xFFFFB800L, 0xFFFF4D6DL, 0xFFFFFFFFL)
    var previewX by remember { mutableFloatStateOf(0.5f) }
    var previewY by remember { mutableFloatStateOf(0.5f) }

    GlassCard(borderColor = GlassBorderBlue) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Virtual Mouse Pointer", style = MaterialTheme.typography.titleMedium)
                Text("Hand-tracked system pointer via Accessibility", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Switch(
                checked = mouseSettings.enabled,
                onCheckedChange = { v -> onUpdate { it.copy(enabled = v) } },
                modifier = Modifier.testTag("virtual_mouse_switch")
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill(
                label = if (accessibilityStatus.connected) "Accessibility Connected" else "Accessibility Disabled",
                active = accessibilityStatus.connected
            )
            if (!accessibilityStatus.connected) {
                OutlinedButton(onClick = onOpenAccessibilitySettings) {
                    Icon(Icons.Rounded.AccessibilityNew, null)
                    Spacer(Modifier.width(4.dp))
                    Text("Enable")
                }
            }
        }
        if (accessibilityStatus.protectedSurfacePaused) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = accessibilityStatus.protectedReason ?: "Paused on protected surface.",
                style = MaterialTheme.typography.bodySmall,
                color = CyberAmber
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { AccessibilityBridge.performGlobalBack() }, modifier = Modifier.weight(1f)) { Text("Test Back") }
            OutlinedButton(onClick = { AccessibilityBridge.performGlobalHome() }, modifier = Modifier.weight(1f)) { Text("Home") }
            OutlinedButton(onClick = { AccessibilityBridge.performGlobalRecents() }, modifier = Modifier.weight(1f)) { Text("Recents") }
        }
    }

    // Live Cursor Preview Pad
    GlassCard {
        Text("Live Cursor Preview (Drag or Point Hand)", style = MaterialTheme.typography.titleSmall, color = ElectricBlue)
        Spacer(Modifier.height(8.dp))
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(MaterialTheme.shapes.medium)
                .background(ObsidianBlack)
                .border(1.dp, ElectricBlue.copy(alpha = 0.35f), MaterialTheme.shapes.medium)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        previewX = (previewX + dragAmount.x / size.width.toFloat()).coerceIn(0.05f, 0.95f)
                        previewY = (previewY + dragAmount.y / size.height.toFloat()).coerceIn(0.05f, 0.95f)
                    }
                }
        ) {
            val activeX = if (mouseState.active) mouseState.normX else previewX
            val activeY = if (mouseState.active) mouseState.normY else previewY
            val w = constraints.maxWidth.toFloat()
            val h = constraints.maxHeight.toFloat()
            Box(
                modifier = Modifier.offset {
                    IntOffset((activeX * w - 24f).roundToInt(), (activeY * h - 24f).roundToInt())
                }
            ) {
                VirtualCursorGlyph(
                    design = mouseSettings.cursorDesign,
                    color = Color(mouseSettings.cursorColorArgb.toInt()),
                    sizeDp = mouseSettings.cursorSizeDp,
                    neonGlow = mouseSettings.neonGlowEnabled,
                    isClicking = mouseState.isClicking
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("8 Cursor Designs", style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(6.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            CursorDesign.entries.forEach { design ->
                FilterChip(
                    selected = mouseSettings.cursorDesign == design,
                    onClick = { onUpdate { it.copy(cursorDesign = design) } },
                    label = { Text(design.displayName, style = MaterialTheme.typography.labelSmall) }
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            swatches.forEach { hex ->
                val selected = mouseSettings.cursorColorArgb == hex
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(Color(hex.toInt()))
                        .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color.Gray, CircleShape)
                        .clickable { onUpdate { it.copy(cursorColorArgb = hex) } }
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("Cursor Size: ${mouseSettings.cursorSizeDp.toInt()} dp", style = MaterialTheme.typography.labelSmall)
        Slider(value = mouseSettings.cursorSizeDp, onValueChange = { v -> onUpdate { it.copy(cursorSizeDp = v) } }, valueRange = 18f..54f)
        Text("Pointer Sensitivity: ${String.format("%.2f", mouseSettings.sensitivity)}x", style = MaterialTheme.typography.labelSmall)
        Slider(value = mouseSettings.sensitivity, onValueChange = { v -> onUpdate { it.copy(sensitivity = v) } }, valueRange = 0.6f..2.4f)
        Text("Pinch Click Sensitivity: ${String.format("%.3f", mouseSettings.clickSensitivity)}", style = MaterialTheme.typography.labelSmall)
        Slider(value = mouseSettings.clickSensitivity, onValueChange = { v -> onUpdate { it.copy(clickSensitivity = v) } }, valueRange = 0.025f..0.10f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Double-Tap Support", style = MaterialTheme.typography.bodyMedium)
            Switch(checked = mouseSettings.doubleClickEnabled, onCheckedChange = { v -> onUpdate { it.copy(doubleClickEnabled = v) } })
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Neon Cursor Glow", style = MaterialTheme.typography.bodyMedium)
            Switch(checked = mouseSettings.neonGlowEnabled, onCheckedChange = { v -> onUpdate { it.copy(neonGlowEnabled = v) } })
        }
    }
}

@Composable
private fun ReelsModeTabContent(
    reelsSettings: ReelsModeSettings,
    reelsState: ReelsRuntimeState,
    eyeState: EyeTrackingState,
    accessibilityStatus: AccessibilityStatus,
    onUpdateReels: ((ReelsModeSettings) -> ReelsModeSettings) -> Unit,
    onToggleReelsMode: (Boolean) -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onEmergencyStop: () -> Unit
) {
    GlassCard(borderColor = if (reelsSettings.active) NeonEmerald else GlassBorderBlue) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("ASIF REELS MODE", style = MaterialTheme.typography.headlineSmall, color = NeonEmerald)
                Text("Hands-free short video navigation via finger gestures & optional gaze", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Switch(
                checked = reelsSettings.active,
                onCheckedChange = onToggleReelsMode,
                modifier = Modifier.testTag("reels_mode_switch")
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill(
                label = if (reelsSettings.active) "REELS ARMED • ${reelsState.lastTriggeredLabel}" else "Standby",
                active = reelsSettings.active
            )
            StatusPill(
                label = if (accessibilityStatus.connected) "Accessibility OK" else "Needs Accessibility",
                active = accessibilityStatus.connected,
                accentColor = ElectricBlue
            )
        }
        if (!accessibilityStatus.connected) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOpenAccessibilitySettings) {
                Text("Authorize Accessibility in Android Settings")
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onEmergencyStop,
            colors = ButtonDefaults.buttonColors(containerColor = AlertCrimson, contentColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("reels_large_stop_button")
        ) {
            Icon(Icons.Rounded.Stop, contentDescription = "Stop Reels Mode")
            Spacer(Modifier.width(8.dp))
            Text("STOP REELS MODE", style = MaterialTheme.typography.titleMedium)
        }
    }

    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = ElectricBlue)
            Spacer(Modifier.width(8.dp))
            Text("Intentional Engagement Safeguards", style = MaterialTheme.typography.titleSmall, color = ElectricBlue)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "• Swipe Up → Next Video  • Swipe Down → Previous Video\n• Two-Finger → Play/Pause  • Open Palm → Pause/Resume\n• Pinch → Intentional Like (2s cooldown guard; eye gaze alone NEVER triggers Like).",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Optional Eye-Gaze Up/Down Scroll", style = MaterialTheme.typography.bodyMedium)
                Text(
                    if (eyeState.detected) "Gaze: ${eyeState.gazeZone.label} • ${eyeState.lightingQuality.label}" else "Enable Eye Gaze & calibrate first",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Switch(
                checked = reelsSettings.gazeScrollEnabled,
                onCheckedChange = { v -> onUpdateReels { it.copy(gazeScrollEnabled = v) } }
            )
        }
    }
}

@Composable
private fun EyeTrackingTabContent(
    eyeSettings: EyeTrackingSettings,
    eyeState: EyeTrackingState,
    onUpdateEye: ((EyeTrackingSettings) -> EyeTrackingSettings) -> Unit,
    onCalibrateCenter: () -> Unit
) {
    GlassCard(borderColor = ElectricBlue.copy(alpha = 0.45f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Optional Eye & Iris Tracking", style = MaterialTheme.typography.titleMedium)
                Text("Front-camera iris landmarks with glasses-tolerant smoothing", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Switch(
                checked = eyeSettings.enabled,
                onCheckedChange = { v -> onUpdateEye { it.copy(enabled = v) } },
                modifier = Modifier.testTag("eye_tracking_switch")
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill("Zone: ${eyeState.gazeZone.label}", eyeState.detected, ElectricBlue)
            StatusPill(eyeState.lightingQuality.label, eyeState.lightingQuality.isAdequate, NeonEmerald)
        }
        Spacer(Modifier.height(10.dp))
        HudMetricBar(
            label = "Iris Tracking Confidence",
            valueText = "${(eyeState.confidence * 100).toInt()}%",
            progress = eyeState.confidence,
            color = NeonEmerald
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onCalibrateCenter,
            modifier = Modifier.fillMaxWidth().testTag("calibrate_eye_button")
        ) {
            Icon(Icons.Rounded.CenterFocusStrong, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(if (eyeSettings.isCalibrated) "Re-Calibrate Center Gaze" else "Calibrate Center Gaze")
        }
        Spacer(Modifier.height(8.dp))
        Text("Gaze Sensitivity: ${String.format("%.2f", eyeSettings.sensitivity)}", style = MaterialTheme.typography.labelSmall)
        Slider(
            value = eyeSettings.sensitivity,
            onValueChange = { v -> onUpdateEye { it.copy(sensitivity = v) } },
            valueRange = 0.25f..1.0f
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Blink Trigger Support", style = MaterialTheme.typography.bodyMedium)
            Switch(
                checked = eyeSettings.blinkTriggerEnabled,
                onCheckedChange = { v -> onUpdateEye { it.copy(blinkTriggerEnabled = v) } },
                modifier = Modifier.testTag("eye_blink_switch")
            )
        }
    }
}
