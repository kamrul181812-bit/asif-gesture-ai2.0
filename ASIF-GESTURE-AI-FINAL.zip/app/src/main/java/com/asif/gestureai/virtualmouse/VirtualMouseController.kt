package com.asif.gestureai.virtualmouse

import com.asif.gestureai.accessibility.AccessibilityBridge
import com.asif.gestureai.gesture.GestureLiveState
import com.asif.gestureai.settings.VirtualMouseSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VirtualMouseState(
    val active: Boolean = false,
    val normX: Float = 0.5f,
    val normY: Float = 0.5f,
    val isClicking: Boolean = false,
    val lastClickTimestamp: Long = 0L
)

class VirtualMouseController {

    private val _mouseState = MutableStateFlow(VirtualMouseState())
    val mouseState: StateFlow<VirtualMouseState> = _mouseState.asStateFlow()

    private var wasPinching = false
    private var lastClickMs = 0L

    fun updateFromGesture(
        gestureState: GestureLiveState,
        settings: VirtualMouseSettings,
        screenWidthPx: Int,
        screenHeightPx: Int,
        nowMs: Long
    ) {
        if (!settings.enabled || !gestureState.handPresent) {
            wasPinching = false
            _mouseState.value = _mouseState.value.copy(active = settings.enabled, isClicking = false)
            return
        }

        // Map calibrated region [pad .. 1-pad] -> [0..1] multiplied by sensitivity
        val pad = settings.calibrationPadding.coerceIn(0f, 0.35f)
        val span = (1f - 2f * pad).coerceAtLeast(0.2f)
        val centeredX = ((gestureState.pointerX - pad) / span) - 0.5f
        val centeredY = ((gestureState.pointerY - pad) / span) - 0.5f
        val mappedX = (0.5f + centeredX * settings.sensitivity).coerceIn(0.02f, 0.98f)
        val mappedY = (0.5f + centeredY * settings.sensitivity).coerceIn(0.02f, 0.98f)

        val pinchRisingEdge = gestureState.isPinching && !wasPinching
        wasPinching = gestureState.isPinching

        var clickedNow = false
        if (pinchRisingEdge && screenWidthPx > 0 && screenHeightPx > 0) {
            val px = mappedX * screenWidthPx
            val py = mappedY * screenHeightPx
            if (settings.doubleClickEnabled && nowMs - lastClickMs in 120L..420L) {
                AccessibilityBridge.performDoubleTap(px, py)
                lastClickMs = 0L
            } else {
                AccessibilityBridge.performTap(px, py)
                lastClickMs = nowMs
            }
            clickedNow = true
        }

        _mouseState.value = VirtualMouseState(
            active = true,
            normX = mappedX,
            normY = mappedY,
            isClicking = clickedNow || gestureState.isPinching,
            lastClickTimestamp = if (clickedNow) nowMs else _mouseState.value.lastClickTimestamp
        )
    }
}
