package com.asif.gestureai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ai_providers")
data class AiProviderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val adapterType: String, // OPENAI_COMPATIBLE, ANTHROPIC_COMPATIBLE, CUSTOM_REST
    val baseUrl: String,
    val chatEndpointPath: String,
    val modelName: String,
    val encryptedApiKey: String,
    val customHeadersJson: String = "{}",
    val temperature: Float = 0.7f,
    val maxContextMessages: Int = 12,
    val isVerified: Boolean = false,
    val lastStatusMessage: String = "Not tested",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val providerId: Long,
    val modelName: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val role: String, // user, assistant, system
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "gesture_history")
data class GestureHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val gestureName: String,
    val actionName: String,
    val confidence: Float,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_masks")
data class CustomMaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val maskJson: String,
    val createdAt: Long = System.currentTimeMillis()
)
