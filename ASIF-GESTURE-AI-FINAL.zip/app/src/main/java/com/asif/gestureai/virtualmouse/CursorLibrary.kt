package com.asif.gestureai.virtualmouse

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.asif.gestureai.settings.CursorDesign

@Composable
fun VirtualCursorGlyph(
    design: CursorDesign,
    color: Color,
    sizeDp: Float,
    neonGlow: Boolean,
    isClicking: Boolean,
    modifier: Modifier = Modifier
) {
    val pulseTransition = rememberInfiniteTransition(label = "cursorPulse")
    val pulse by pulseTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseScale"
    )

    Canvas(modifier = modifier.size(sizeDp.dp)) {
        val c = center
        val r = (size.minDimension * 0.38f)
        val clickScale = if (isClicking) 1.35f else 1.0f

        if (neonGlow) {
            drawCircle(
                color = color.copy(alpha = if (isClicking) 0.36f else 0.18f),
                radius = r * 1.45f * clickScale,
                center = c
            )
        }

        when (design) {
            CursorDesign.CLASSIC_ARROW -> drawClassicArrow(color)
            CursorDesign.NEON_CIRCLE -> {
                drawCircle(color.copy(alpha = 0.25f), radius = r * clickScale, center = c)
                drawCircle(color, radius = r * clickScale, center = c, style = Stroke(width = 4f))
                drawCircle(Color.White, radius = r * 0.22f, center = c)
            }
            CursorDesign.FUTURISTIC_TARGET -> {
                drawCircle(color, radius = r * 0.9f, center = c, style = Stroke(width = 3f))
                drawCircle(color, radius = r * 0.35f, center = c, style = Stroke(width = 2.5f))
                val len = r * 1.2f
                drawLine(color, Offset(c.x - len, c.y), Offset(c.x - r * 0.45f, c.y), 3f, StrokeCap.Round)
                drawLine(color, Offset(c.x + r * 0.45f, c.y), Offset(c.x + len, c.y), 3f, StrokeCap.Round)
                drawLine(color, Offset(c.x, c.y - len), Offset(c.x, c.y - r * 0.45f), 3f, StrokeCap.Round)
                drawLine(color, Offset(c.x, c.y + r * 0.45f), Offset(c.x, c.y + len), 3f, StrokeCap.Round)
            }
            CursorDesign.MINIMAL_DOT -> {
                drawCircle(color, radius = r * 0.45f * clickScale, center = c)
                drawCircle(Color.White, radius = r * 0.18f, center = c)
            }
            CursorDesign.CROSSHAIR -> {
                val len = r * 1.15f
                drawLine(color, Offset(c.x - len, c.y), Offset(c.x + len, c.y), 3f, StrokeCap.Round)
                drawLine(color, Offset(c.x, c.y - len), Offset(c.x, c.y + len), 3f, StrokeCap.Round)
                drawCircle(Color.White, radius = 4f, center = c)
            }
            CursorDesign.CYBER_POINTER -> {
                val p = Path().apply {
                    moveTo(size.width * 0.18f, size.height * 0.15f)
                    lineTo(size.width * 0.85f, size.height * 0.50f)
                    lineTo(size.width * 0.48f, size.height * 0.58f)
                    lineTo(size.width * 0.38f, size.height * 0.88f)
                    close()
                }
                drawPath(p, color = color.copy(alpha = 0.35f))
                drawPath(p, color = color, style = Stroke(width = 3.5f))
            }
            CursorDesign.GLOWING_RING -> {
                drawCircle(color, radius = r * 1.05f * clickScale, center = c, style = Stroke(width = 5.5f))
                drawCircle(Color.White, radius = r * 0.2f, center = c)
            }
            CursorDesign.ANIMATED_PULSE -> {
                drawCircle(color.copy(alpha = 0.5f), radius = r * pulse, center = c, style = Stroke(width = 3f))
                drawCircle(color, radius = r * 0.42f * clickScale, center = c)
            }
        }
    }
}

private fun DrawScope.drawClassicArrow(color: Color) {
    val path = Path().apply {
        moveTo(size.width * 0.2f, size.height * 0.12f)
        lineTo(size.width * 0.2f, size.height * 0.82f)
        lineTo(size.width * 0.42f, size.height * 0.64f)
        lineTo(size.width * 0.58f, size.height * 0.90f)
        lineTo(size.width * 0.70f, size.height * 0.84f)
        lineTo(size.width * 0.54f, size.height * 0.58f)
        lineTo(size.width * 0.80f, size.height * 0.56f)
        close()
    }
    drawPath(path, color = Color.White)
    drawPath(path, color = color, style = Stroke(width = 3f))
}
