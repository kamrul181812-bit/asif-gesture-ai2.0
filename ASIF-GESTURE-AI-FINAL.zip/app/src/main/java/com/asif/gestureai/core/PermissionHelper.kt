package com.asif.gestureai.core

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.text.TextUtils
import androidx.core.content.ContextCompat
import com.asif.gestureai.accessibility.GestureAccessibilityService

data class PermissionStatusSnapshot(
    val cameraGranted: Boolean = false,
    val microphoneGranted: Boolean = false,
    val notificationsGranted: Boolean = true,
    val overlayGranted: Boolean = false,
    val accessibilityEnabled: Boolean = false
)

object PermissionHelper {

    fun snapshot(context: Context): PermissionStatusSnapshot {
        val camera = ContextCompat.checkSelfPermission(
            context, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        val mic = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        val overlay = Settings.canDrawOverlays(context)
        val accessibility = isAccessibilityServiceEnabled(context)

        return PermissionStatusSnapshot(
            cameraGranted = camera,
            microphoneGranted = mic,
            notificationsGranted = notif,
            overlayGranted = overlay,
            accessibilityEnabled = accessibility
        )
    }

    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedComponent = ComponentName(context, GestureAccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            val componentStr = splitter.next()
            val enabledComponent = ComponentName.unflattenFromString(componentStr)
            if (enabledComponent == expectedComponent) {
                return true
            }
        }
        return false
    }

    /** Honest three-state accessibility status: never reports "enabled" unless Android says so. */
    enum class AccessibilityState { ENABLED_AND_CONNECTED, ENABLED_NOT_CONNECTED, DISABLED }

    /** Pure decision logic (unit-testable, no Android calls). */
    fun resolveAccessibilityState(enabledInSettings: Boolean, serviceConnected: Boolean): AccessibilityState = when {
        serviceConnected -> AccessibilityState.ENABLED_AND_CONNECTED
        enabledInSettings -> AccessibilityState.ENABLED_NOT_CONNECTED
        else -> AccessibilityState.DISABLED
    }

    private val TRUSTED_INSTALLERS = setOf(
        "com.android.vending",            // Google Play
        "com.google.android.packageinstaller",
        "com.android.packageinstaller"
    )

    /**
     * Android 13+ "Restricted settings" blocks Accessibility for apps installed from outside a trusted store
     * (sideloaded APKs, including GitHub Actions builds). This can NOT be bypassed in code. We only predict
     * it so the UI can show the manual steps up-front. Pure function so it can be unit tested.
     */
    fun isRestrictedSettingsLikely(sdkInt: Int, installerPackage: String?): Boolean =
        sdkInt >= Build.VERSION_CODES.TIRAMISU && (installerPackage == null || installerPackage !in TRUSTED_INSTALLERS)

    @Suppress("DEPRECATION")
    fun installerPackageName(context: Context): String? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context.packageManager.getInstallSourceInfo(context.packageName).installingPackageName
        } else {
            context.packageManager.getInstallerPackageName(context.packageName)
        }
    } catch (_: Exception) {
        null
    }

    fun restrictedSettingsLikely(context: Context): Boolean =
        isRestrictedSettingsLikely(Build.VERSION.SDK_INT, installerPackageName(context))

    const val RESTRICTED_SETTINGS_STEPS: String =
        "1. Tap \"App Info\" below.\n" +
        "2. Tap the three-dot menu (top right) \u2192 \"Allow restricted settings\" and confirm.\n" +
        "3. Tap \"Accessibility\" below \u2192 ASIF GESTURE AI \u2192 turn the service ON.\n" +
        "Android blocks this step for sideloaded apps and it cannot be skipped from inside the app."

    private fun safeStart(context: Context, intent: Intent): Boolean = try {
        context.startActivity(intent)
        true
    } catch (_: Exception) {
        false
    }

    fun openOverlaySettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!safeStart(context, intent)) openAppSettings(context)
    }

    fun openAccessibilitySettings(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!safeStart(context, intent)) openAppSettings(context)
    }

    fun openAppSettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        safeStart(context, intent)
    }
}
