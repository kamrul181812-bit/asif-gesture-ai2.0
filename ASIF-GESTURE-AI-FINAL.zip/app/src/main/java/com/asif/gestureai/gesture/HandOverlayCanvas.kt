package com.asif.gestureai.gesture

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import com.asif.gestureai.core.FillCenterTransform
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonEmerald

private val HAND_CONNECTIONS = listOf(
    0 to 1, 1 to 2, 2 to 3, 3 to 4,
    0 to 5, 5 to 6, 6 to 7, 7 to 8,
    5 to 9, 9 to 10, 10 to 11, 11 to 12,
    9 to 13, 13 to 14, 14 to 15, 15 to 16,
    13 to 17, 17 to 18, 18 to 19, 19 to 20, 0 to 17
)

@Composable
fun HandOverlayCanvas(
    handResult: HandTrackingResult,
    showLandmarks: Boolean,
    modifier: Modifier = Modifier
) {
    if (!showLandmarks || handResult.hands.isEmpty()) return

    Canvas(modifier = modifier.fillMaxSize()) {
        // One FILL_CENTER transform shared by every landmark of this frame (same math as the mask + preview).
        val t = FillCenterTransform(handResult.imageWidth, handResult.imageHeight, size.width, size.height)
        handResult.hands.forEachIndexed { idx, hand ->
            val pts = hand.landmarks
            if (pts.size < 21) return@forEachIndexed
            val boneColor = if (idx == 0) NeonEmerald.copy(alpha = 0.85f) else ElectricBlue.copy(alpha = 0.85f)
            val jointColor = Color.White

            for ((startIdx, endIdx) in HAND_CONNECTIONS) {
                val p1 = pts[startIdx]
                val p2 = pts[endIdx]
                drawLine(
                    color = boneColor,
                    start = Offset(t.x(p1.x), t.y(p1.y)),
                    end = Offset(t.x(p2.x), t.y(p2.y)),
                    strokeWidth = 4f,
                    cap = StrokeCap.Round
                )
            }
            pts.forEachIndexed { lmIdx, pt ->
                val isTip = lmIdx == 4 || lmIdx == 8 || lmIdx == 12 || lmIdx == 16 || lmIdx == 20
                drawCircle(
                    color = if (lmIdx == 8) ElectricBlue else jointColor,
                    radius = if (isTip) 8f else 5f,
                    center = Offset(t.x(pt.x), t.y(pt.y))
                )
            }
        }
    }
}
