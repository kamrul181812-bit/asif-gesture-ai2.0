package com.asif.gestureai.settings

import com.asif.gestureai.performance.PerformanceMode
import kotlinx.serialization.Serializable

@Serializable
enum class CameraLensOption(val label: String) {
    FRONT("Front Camera"),
    REAR("Rear Camera")
}

@Serializable
enum class ResolutionTier(val label: String, val width: Int, val height: Int) {
    LOW_320("320x240 (Ultra Stable)", 320, 240),
    MID_480("480x360 (Inova 30 Optimal)", 480, 360),
    HIGH_640("640x480 (High Detail)", 640, 480)
}

@Serializable
data class CameraSettings(
    val lens: CameraLensOption = CameraLensOption.FRONT,
    val resolutionTier: ResolutionTier = ResolutionTier.MID_480,
    val targetFps: Int = 20,
    val highPreviewQuality: Boolean = false,
    val autoRecoveryEnabled: Boolean = true
)

@Serializable
enum class MaskStyle(val displayName: String, val subtitle: String) {
    NONE("No Mask", "Raw camera feed with optional landmarks"),
    DIGITAL_ANONYMOUS("Digital Anonymous", "Sculpted cybernetic Guy-style wireframe"),
    CYBERNETIC_ROBOT("Cybernetic Robotic", "Segmented armored visor & jaw hydraulics"),
    NEON_VISOR("Futuristic Neon Visor", "Sleek HUD optic band & cheek telemetry"),
    DARK_DIGITAL("Dark Digital Stealth", "Smoked obsidian plate & luminous contour"),
    MINIMAL_CYBER("Minimal Black Cyber", "Low-profile carbon bridge & subtle nodes"),
    CUSTOM_DESIGN("Custom Designer", "User-configured geometry, nodes & glow")
}

@Serializable
data class MaskSettings(
    val enabled: Boolean = false,
    val style: MaskStyle = MaskStyle.NEON_VISOR,
    val scale: Float = 1.0f,
    val widthScale: Float = 1.0f,
    val heightScale: Float = 1.0f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val rotationDeg: Float = 0f,
    val transparency: Float = 0.85f,
    val neonColorArgb: Long = 0xFF00FF88L,
    val glowIntensity: Float = 0.7f,
    val edgeThickness: Float = 3.0f,
    val alignToFace: Boolean = true,
    val smoothing: Float = 0.45f
)

@Serializable
enum class GestureType(val displayName: String, val description: String) {
    INDEX_POINT("Index Pointing", "Move virtual cursor or point target"),
    PINCH("Pinch", "Thumb & index tip pinch to click/select"),
    OPEN_PALM("Open Palm", "All 5 fingers open — pause/release"),
    CLOSED_FIST("Closed Fist", "Hold or lock gesture state"),
    SWIPE_UP("Swipe Up", "Rapid upward hand motion"),
    SWIPE_DOWN("Swipe Down", "Rapid downward hand motion"),
    TWO_FINGER("Two-Finger Peace", "Index + middle extended"),
    THUMBS_UP("Thumbs Up", "Positive confirm / custom trigger"),
    HAND_WAVE("Hand Wave", "Lateral open-palm wave"),
    PINCH_SPREAD("Pinch Spread", "Expand thumb-index pinch outward"),
    TWO_HAND("Two-Hand Gesture", "Dual hands detected together")
}

@Serializable
enum class GestureAction(val displayName: String) {
    NONE("No Action"),
    VIRTUAL_CLICK("Virtual Mouse Click"),
    VIRTUAL_DOUBLE_CLICK("Double Click"),
    SCROLL_UP("Scroll Up / Previous"),
    SCROLL_DOWN("Scroll Down / Next"),
    GLOBAL_BACK("System Back"),
    GLOBAL_HOME("System Home"),
    GLOBAL_RECENTS("Recent Apps"),
    PAUSE_RESUME_TRACKING("Pause / Resume Tracking"),
    TOGGLE_MASK("Toggle Cyber Mask"),
    REELS_NEXT("Reels Next Video"),
    REELS_PREVIOUS("Reels Previous Video"),
    REELS_PLAY_PAUSE("Reels Pause / Play"),
    REELS_INTENTIONAL_LIKE("Reels Intentional Like"),
    REELS_COMMENTS("Reels Open Comments"),
    REELS_PROFILE("Reels Open Profile"),
    OPEN_AI_HUB("Open AI Chat Hub")
}

@Serializable
data class GestureSettings(
    val enabled: Boolean = true,
    val sensitivity: Float = 0.7f,
    val confidenceThreshold: Float = 0.65f,
    val activationDelayMs: Long = 160L,
    val cooldownMs: Long = 650L,
    val enabledGestures: Map<String, Boolean> = GestureType.entries.associate { it.name to true },
    val actionMappings: Map<String, String> = mapOf(
        GestureType.INDEX_POINT.name to GestureAction.NONE.name,
        GestureType.PINCH.name to GestureAction.VIRTUAL_CLICK.name,
        GestureType.OPEN_PALM.name to GestureAction.PAUSE_RESUME_TRACKING.name,
        GestureType.CLOSED_FIST.name to GestureAction.GLOBAL_BACK.name,
        GestureType.SWIPE_UP.name to GestureAction.SCROLL_DOWN.name,
        GestureType.SWIPE_DOWN.name to GestureAction.SCROLL_UP.name,
        GestureType.TWO_FINGER.name to GestureAction.REELS_PLAY_PAUSE.name,
        GestureType.THUMBS_UP.name to GestureAction.TOGGLE_MASK.name,
        GestureType.HAND_WAVE.name to GestureAction.GLOBAL_HOME.name,
        GestureType.PINCH_SPREAD.name to GestureAction.GLOBAL_RECENTS.name,
        GestureType.TWO_HAND.name to GestureAction.OPEN_AI_HUB.name
    )
)

@Serializable
data class EyeTrackingSettings(
    val enabled: Boolean = false,
    val sensitivity: Float = 0.65f,
    val gazeScrollEnabled: Boolean = false,
    val blinkTriggerEnabled: Boolean = false,
    val centerOffsetX: Float = 0.5f,
    val centerOffsetY: Float = 0.5f,
    val horizontalRange: Float = 0.14f,
    val verticalRange: Float = 0.12f,
    val isCalibrated: Boolean = false
)

@Serializable
enum class CursorDesign(val displayName: String) {
    CLASSIC_ARROW("Classic Arrow"),
    NEON_CIRCLE("Neon Circle"),
    FUTURISTIC_TARGET("Futuristic Target"),
    MINIMAL_DOT("Minimal Dot"),
    CROSSHAIR("Precision Crosshair"),
    CYBER_POINTER("Cyber Pointer"),
    GLOWING_RING("Glowing Ring"),
    ANIMATED_PULSE("Animated Pulse")
}

@Serializable
data class VirtualMouseSettings(
    val enabled: Boolean = false,
    val cursorDesign: CursorDesign = CursorDesign.FUTURISTIC_TARGET,
    val cursorSizeDp: Float = 30f,
    val cursorColorArgb: Long = 0xFF00D4FFL,
    val sensitivity: Float = 1.35f,
    val clickSensitivity: Float = 0.055f,
    val doubleClickEnabled: Boolean = true,
    val neonGlowEnabled: Boolean = true,
    val calibrationPadding: Float = 0.12f
)

@Serializable
enum class FloatingVisibilityMode(val displayName: String, val subtitle: String) {
    VISIBLE("Visible Mode", "Floating camera preview + compact controls"),
    MINI("Mini Mode", "Compact floating camera pill"),
    HIDDEN_PANEL("Hidden Panel Mode", "Hide overlay panel while keeping permitted controls")
}

@Serializable
enum class FloatingSizePreset(val displayName: String, val widthDp: Int, val heightDp: Int) {
    SMALL("Small", 128, 176),
    MEDIUM("Medium", 172, 236),
    LARGE("Large", 220, 300)
}

@Serializable
data class FloatingWindowSettings(
    val visibilityMode: FloatingVisibilityMode = FloatingVisibilityMode.VISIBLE,
    val sizePreset: FloatingSizePreset = FloatingSizePreset.MEDIUM,
    val aspectRatioW: Float = 3f,
    val aspectRatioH: Float = 4f,
    val cornerRadiusDp: Float = 20f,
    val borderColorArgb: Long = 0xFF00FF88L,
    val borderThicknessDp: Float = 2.0f,
    val edgeSnapEnabled: Boolean = true,
    val showCompactControls: Boolean = true
)

@Serializable
data class ReelsModeSettings(
    val active: Boolean = false,
    val swipeUpAction: GestureAction = GestureAction.REELS_NEXT,
    val swipeDownAction: GestureAction = GestureAction.REELS_PREVIOUS,
    val pinchAction: GestureAction = GestureAction.REELS_INTENTIONAL_LIKE,
    val twoFingerAction: GestureAction = GestureAction.REELS_PLAY_PAUSE,
    val thumbsUpAction: GestureAction = GestureAction.REELS_COMMENTS,
    val openPalmAction: GestureAction = GestureAction.PAUSE_RESUME_TRACKING,
    val gazeScrollEnabled: Boolean = false,
    val requireIntentionalPinchForLike: Boolean = true
)

@Serializable
data class VoiceAndSoundSettings(
    val soundEffectsEnabled: Boolean = true,
    val masterVolume: Float = 0.65f,
    val buttonSoundEnabled: Boolean = true,
    val gestureSoundEnabled: Boolean = true,
    val clickSoundEnabled: Boolean = true,
    val cameraSoundEnabled: Boolean = true,
    val modeSwitchSoundEnabled: Boolean = true,
    val voiceControlEnabled: Boolean = false,
    val voiceFeedbackEnabled: Boolean = true,
    val wakeWordExperimental: Boolean = false,
    val customCommandsJson: String = "{}"
)

@Serializable
data class PerformancePreferences(
    val mode: PerformanceMode = PerformanceMode.BALANCED,
    val adaptiveEnabled: Boolean = true,
    val thermalMonitoringEnabled: Boolean = true
)

@Serializable
data class AllAppSettings(
    val camera: CameraSettings = CameraSettings(),
    val mask: MaskSettings = MaskSettings(),
    val gesture: GestureSettings = GestureSettings(),
    val eyeTracking: EyeTrackingSettings = EyeTrackingSettings(),
    val virtualMouse: VirtualMouseSettings = VirtualMouseSettings(),
    val floating: FloatingWindowSettings = FloatingWindowSettings(),
    val reels: ReelsModeSettings = ReelsModeSettings(),
    val voiceSound: VoiceAndSoundSettings = VoiceAndSoundSettings(),
    val performance: PerformancePreferences = PerformancePreferences()
)
