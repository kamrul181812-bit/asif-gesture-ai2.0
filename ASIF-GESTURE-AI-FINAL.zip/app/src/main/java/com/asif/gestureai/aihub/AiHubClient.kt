package com.asif.gestureai.aihub

import com.asif.gestureai.core.AppLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URI
import java.util.concurrent.TimeUnit

class AiHubClient {

    companion object {
        private const val TAG = "AiHubClient"
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
    }

    // No HttpLoggingInterceptor on headers/body to guarantee API keys never touch logs
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(18, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    fun validateUrlSyntax(baseUrl: String): Boolean {
        return try {
            val uri = URI(baseUrl.trim())
            val scheme = uri.scheme?.lowercase()
            (scheme == "https" || scheme == "http") && !uri.host.isNullOrBlank()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun testConnectionAndDiscover(
        adapterType: AiAdapterType,
        baseUrl: String,
        chatPath: String,
        apiKey: String,
        modelName: String,
        customHeadersJson: String
    ): AiSetupValidationResult = withContext(Dispatchers.IO) {
        val cleanBase = baseUrl.trim().trimEnd('/')
        if (!validateUrlSyntax(cleanBase)) {
            return@withContext AiSetupValidationResult(
                success = false,
                endpointValid = false,
                authValid = false,
                detectedFormat = "Invalid URL",
                discoveredModels = emptyList(),
                statusMessage = "Invalid endpoint URL. Provide a valid https:// base URL."
            )
        }

        if (apiKey.isBlank() && !cleanBase.startsWith("http://localhost") && !cleanBase.startsWith("http://127.0.0.1") && !cleanBase.startsWith("http://10.")) {
            return@withContext AiSetupValidationResult(
                success = false,
                endpointValid = true,
                authValid = false,
                detectedFormat = "Missing Credentials",
                discoveredModels = emptyList(),
                statusMessage = "API key is empty. Enter your provider key (stored encrypted via Android Keystore)."
            )
        }

        val customHeaders = parseHeaders(customHeadersJson)

        // 1. Attempt /models discovery for OpenAI-compatible adapters
        val discovered = mutableListOf<String>()
        if (adapterType == AiAdapterType.OPENAI_COMPATIBLE || adapterType == AiAdapterType.GEMINI_COMPAT || adapterType == AiAdapterType.CUSTOM_REST) {
            try {
                val modelsReq = Request.Builder()
                    .url(AiEndpointUtils.modelsUrl(cleanBase))
                    .get()
                    .applyAuthHeaders(adapterType, apiKey, customHeaders)
                    .build()
                httpClient.newCall(modelsReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string().orEmpty()
                        val json = JSONObject(body)
                        val dataArr = json.optJSONArray("data")
                        if (dataArr != null) {
                            for (i in 0 until minOf(dataArr.length(), 40)) {
                                val id = dataArr.optJSONObject(i)?.optString("id").orEmpty()
                                if (id.isNotBlank()) discovered.add(AiEndpointUtils.normalizeModelId(id))
                            }
                        }
                    } else if (resp.code == 401 || resp.code == 403) {
                        return@withContext AiSetupValidationResult(
                            success = false,
                            endpointValid = true,
                            authValid = false,
                            detectedFormat = adapterType.displayName,
                            discoveredModels = emptyList(),
                            statusMessage = "Authentication failed (HTTP ${resp.code}). Verify your API key."
                        )
                    }
                }
            } catch (e: Exception) {
                AppLogger.d(TAG, "Model discovery optional step skipped: ${e.javaClass.simpleName}")
            }
        }

        // 2. Real minimal completion test to verify chat endpoint & response schema
        val cleanPath = "/" + chatPath.trim().trimStart('/')
        val fullChatUrl = AiEndpointUtils.chatUrl(cleanBase, chatPath)
        val testModel = AiEndpointUtils.normalizeModelId(
            modelName.trim().ifBlank { discovered.firstOrNull() ?: adapterType.defaultModel }
        )
        val payload = buildChatPayload(
            adapterType = adapterType,
            model = testModel,
            messages = listOf(AiChatDraftMessage("user", "Reply with OK")),
            temperature = 0.2f,
            stream = false,
            maxTokens = 8
        )

        return@withContext try {
            val req = Request.Builder()
                .url(fullChatUrl)
                .post(payload.toString().toRequestBody(JSON_MEDIA))
                .applyAuthHeaders(adapterType, apiKey, customHeaders)
                .build()

            httpClient.newCall(req).execute().use { resp ->
                val rawBody = resp.body?.string().orEmpty()
                when {
                    resp.isSuccessful -> {
                        val formatDesc = detectResponseFormat(adapterType, rawBody)
                        if (formatDesc == null) {
                            AiSetupValidationResult(
                                success = false,
                                endpointValid = true,
                                authValid = true,
                                detectedFormat = "Unrecognized JSON Schema",
                                discoveredModels = discovered,
                                statusMessage = "Endpoint returned HTTP ${resp.code}, but the JSON schema does not match ${adapterType.displayName}. Verify the endpoint path or adapter type."
                            )
                        } else {
                            AiSetupValidationResult(
                                success = true,
                                endpointValid = true,
                                authValid = true,
                                detectedFormat = formatDesc,
                                discoveredModels = discovered,
                                statusMessage = "Connected & verified ($formatDesc)."
                            )
                        }
                    }
                    resp.code == 401 || resp.code == 403 -> AiSetupValidationResult(
                        success = false,
                        endpointValid = true,
                        authValid = false,
                        detectedFormat = "Auth Rejected",
                        discoveredModels = discovered,
                        statusMessage = "API authentication failed (HTTP ${resp.code}). Check your API key."
                    )
                    resp.code == 404 -> AiSetupValidationResult(
                        success = false,
                        endpointValid = false,
                        authValid = true,
                        detectedFormat = "404 Not Found",
                        discoveredModels = discovered,
                        statusMessage = "Endpoint path '$cleanPath' not found (HTTP 404). Check Base URL and path."
                    )
                    else -> {
                        val errSnippet = AiEndpointUtils.describeHttpError(resp.code, extractErrorMessage(rawBody))
                        AiSetupValidationResult(
                            success = false,
                            endpointValid = true,
                            authValid = true,
                            detectedFormat = "HTTP ${resp.code}",
                            discoveredModels = discovered,
                            statusMessage = "Provider error: $errSnippet"
                        )
                    }
                }
            }
        } catch (e: Exception) {
            AiSetupValidationResult(
                success = false,
                endpointValid = false,
                authValid = false,
                detectedFormat = "Network Error",
                discoveredModels = discovered,
                statusMessage = "Connection failed: ${e.localizedMessage ?: "Network unavailable or timeout"}"
            )
        }
    }

    fun streamChatCompletion(
        adapterType: AiAdapterType,
        baseUrl: String,
        chatPath: String,
        apiKey: String,
        modelName: String,
        customHeadersJson: String,
        messages: List<AiChatDraftMessage>,
        temperature: Float
    ): Flow<Result<String>> = flow {
        val cleanBase = baseUrl.trim().trimEnd('/')
        val fullUrl = AiEndpointUtils.chatUrl(cleanBase, chatPath)
        val customHeaders = parseHeaders(customHeadersJson)
        val useStream = adapterType != AiAdapterType.CUSTOM_REST

        val payload = buildChatPayload(
            adapterType = adapterType,
            model = modelName,
            messages = messages,
            temperature = temperature,
            stream = useStream,
            maxTokens = null
        )

        val request = Request.Builder()
            .url(fullUrl)
            .post(payload.toString().toRequestBody(JSON_MEDIA))
            .applyAuthHeaders(adapterType, apiKey, customHeaders)
            .build()

        val call = httpClient.newCall(request)
        try {
            call.execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string().orEmpty()
                    val msg = AiEndpointUtils.describeHttpError(response.code, extractErrorMessage(errBody))
                    emit(Result.failure(IllegalStateException(msg)))
                    return@flow
                }

                val contentType = response.header("Content-Type").orEmpty().lowercase()
                val body = response.body ?: run {
                    emit(Result.failure(IllegalStateException("Empty response body from provider.")))
                    return@flow
                }

                if (contentType.contains("text/event-stream") || useStream) {
                    val reader = BufferedReader(InputStreamReader(body.byteStream()))
                    val fullText = StringBuilder()
                    var line: String?
                    var sawSseData = false
                    val rawFallback = StringBuilder()

                    while (reader.readLine().also { line = it } != null) {
                        val currentLine = line ?: continue
                        if (!sawSseData && !currentLine.startsWith("data:") && currentLine.isNotBlank()) {
                            rawFallback.append(currentLine)
                        }
                        if (currentLine.startsWith("data:")) {
                            sawSseData = true
                            val data = currentLine.removePrefix("data:").trim()
                            if (data == "[DONE]") break
                            val delta = extractSseDelta(adapterType, data)
                            if (!delta.isNullOrEmpty()) {
                                fullText.append(delta)
                                emit(Result.success(fullText.toString()))
                            }
                        }
                    }

                    if (!sawSseData && rawFallback.isNotEmpty()) {
                        val parsed = extractNonStreamContent(adapterType, rawFallback.toString())
                        if (parsed != null) {
                            emit(Result.success(parsed))
                        } else {
                            emit(Result.failure(IllegalStateException("Provider returned non-streaming unrecognized response format.")))
                        }
                    } else if (fullText.isEmpty()) {
                        emit(Result.failure(IllegalStateException("No assistant text tokens received from stream.")))
                    }
                } else {
                    val raw = body.string()
                    val parsed = extractNonStreamContent(adapterType, raw)
                    if (parsed != null) {
                        emit(Result.success(parsed))
                    } else {
                        emit(Result.failure(IllegalStateException("Could not parse response JSON. Verify adapter configuration.")))
                    }
                }
            }
        } catch (e: Exception) {
            emit(Result.failure(e))
        } finally {
            call.cancel()
        }
    }.flowOn(Dispatchers.IO)

    private fun Request.Builder.applyAuthHeaders(
        adapterType: AiAdapterType,
        apiKey: String,
        customHeaders: Map<String, String>
    ): Request.Builder {
        header("Content-Type", "application/json")
        when (adapterType) {
            AiAdapterType.ANTHROPIC_COMPAT -> {
                if (apiKey.isNotBlank()) header("x-api-key", apiKey.trim())
                header("anthropic-version", "2023-06-01")
            }
            AiAdapterType.OPENAI_COMPATIBLE,
            AiAdapterType.GEMINI_COMPAT,
            AiAdapterType.CUSTOM_REST -> {
                if (apiKey.isNotBlank()) header("Authorization", "Bearer ${apiKey.trim()}")
            }
        }
        customHeaders.forEach { (k, v) ->
            if (k.isNotBlank() && v.isNotBlank()) header(k.trim(), v.trim())
        }
        return this
    }

    private fun buildChatPayload(
        adapterType: AiAdapterType,
        model: String,
        messages: List<AiChatDraftMessage>,
        temperature: Float,
        stream: Boolean,
        maxTokens: Int?
    ): JSONObject {
        val root = JSONObject()
        root.put("model", AiEndpointUtils.normalizeModelId(model))
        root.put("temperature", temperature.toDouble())
        if (stream) root.put("stream", true)
        if (maxTokens != null) root.put("max_tokens", maxTokens)

        val msgArray = JSONArray()
        if (adapterType == AiAdapterType.ANTHROPIC_COMPAT) {
            if (maxTokens == null) root.put("max_tokens", 2048)
            messages.filter { it.role != "system" }.forEach { msg ->
                msgArray.put(JSONObject().apply {
                    put("role", if (msg.role == "assistant") "assistant" else "user")
                    put("content", msg.content)
                })
            }
        } else {
            messages.forEach { msg ->
                msgArray.put(JSONObject().apply {
                    put("role", msg.role)
                    put("content", msg.content)
                })
            }
        }
        root.put("messages", msgArray)
        return root
    }

    private fun detectResponseFormat(adapterType: AiAdapterType, rawBody: String): String? {
        return try {
            val json = JSONObject(rawBody)
            when {
                json.has("choices") -> "OpenAI JSON Chat Format"
                json.has("content") && adapterType == AiAdapterType.ANTHROPIC_COMPAT -> "Anthropic Messages JSON"
                json.has("output") || json.has("response") || json.has("text") -> "Custom REST JSON"
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun extractSseDelta(adapterType: AiAdapterType, jsonStr: String): String? {
        return try {
            val json = JSONObject(jsonStr)
            if (adapterType == AiAdapterType.ANTHROPIC_COMPAT) {
                json.optJSONObject("delta")?.optString("text")
            } else {
                val choices = json.optJSONArray("choices") ?: return null
                val first = choices.optJSONObject(0) ?: return null
                val delta = first.optJSONObject("delta")?.optString("content")
                if (!delta.isNullOrEmpty()) delta else first.optJSONObject("message")?.optString("content")
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun extractNonStreamContent(adapterType: AiAdapterType, raw: String): String? {
        return try {
            val json = JSONObject(raw)
            if (adapterType == AiAdapterType.ANTHROPIC_COMPAT) {
                val contentArr = json.optJSONArray("content")
                contentArr?.optJSONObject(0)?.optString("text")
            } else {
                val choices = json.optJSONArray("choices")
                val msg = choices?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                msg ?: json.optString("text").takeIf { it.isNotBlank() }
                    ?: json.optString("response").takeIf { it.isNotBlank() }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun extractErrorMessage(raw: String): String {
        return try {
            val json = JSONObject(raw)
            json.optJSONObject("error")?.optString("message")
                ?: json.optString("message").takeIf { it.isNotBlank() }
                ?: raw.take(140)
        } catch (_: Exception) {
            raw.take(140)
        }
    }

    fun parseHeaders(headersJson: String): Map<String, String> {
        if (headersJson.isBlank() || headersJson.trim() == "{}") return emptyMap()
        return try {
            val obj = JSONObject(headersJson)
            val map = mutableMapOf<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = obj.optString(k)
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }
}
