package com.asif.gestureai.ui.screens

import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.FaceRetouchingNatural
import androidx.compose.material.icons.rounded.FrontHand
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Mouse
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SmartDisplay
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.asif.gestureai.accessibility.AccessibilityStatus
import com.asif.gestureai.camera.CameraStatus
import com.asif.gestureai.core.DeviceProfile
import com.asif.gestureai.core.PermissionStatusSnapshot
import com.asif.gestureai.eye.EyeTrackingState
import com.asif.gestureai.face.FaceTrackingResult
import com.asif.gestureai.gesture.GestureLiveState
import com.asif.gestureai.gesture.HandTrackingResult
import com.asif.gestureai.performance.PerformanceTelemetry
import com.asif.gestureai.settings.AllAppSettings
import com.asif.gestureai.settings.FloatingVisibilityMode
import com.asif.gestureai.ui.components.CameraViewportSurface
import com.asif.gestureai.ui.components.GlassCard
import com.asif.gestureai.ui.components.HudMetricBar
import com.asif.gestureai.ui.components.StatusPill
import com.asif.gestureai.virtualmouse.VirtualMouseState
import com.example.R
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GlassBorderBlue
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    settings: AllAppSettings,
    cameraStatus: CameraStatus,
    faceResult: FaceTrackingResult,
    handResult: HandTrackingResult,
    gestureState: GestureLiveState,
    eyeState: EyeTrackingState,
    mouseState: VirtualMouseState,
    telemetry: PerformanceTelemetry,
    accessibilityStatus: AccessibilityStatus,
    permissions: PermissionStatusSnapshot,
    onPreviewViewCreated: (PreviewView) -> Unit,
    onStartStopCamera: () -> Unit,
    onSwitchCamera: () -> Unit,
    onToggleMask: () -> Unit,
    onEnterPip: () -> Unit,
    onStartFloatingVisible: () -> Unit,
    onEmergencyStop: () -> Unit,
    onNavigateToCameraStudio: () -> Unit,
    onNavigateToGestures: () -> Unit,
    onNavigateToReels: () -> Unit,
    onNavigateToVirtualMouse: () -> Unit,
    onNavigateToAiHub: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero HUD Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.large)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_neural_banner),
                    contentDescription = "ASIF GESTURE AI neural HUD backdrop",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .matchParentSize()
                        .alpha(0.55f)
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(ObsidianBlack.copy(alpha = 0.85f), ObsidianBlack.copy(alpha = 0.45f))
                            )
                        )
                )
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ASIF GESTURE AI",
                                style = MaterialTheme.typography.headlineSmall,
                                color = NeonEmerald
                            )
                            Text(
                                text = "${DeviceProfile.TARGET_DEVICE_NAME} Optimized • ${DeviceProfile.TARGET_OS_LABEL}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                        FilledTonalButton(
                            onClick = onEmergencyStop,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = AlertCrimson.copy(alpha = 0.22f),
                                contentColor = AlertCrimson
                            ),
                            modifier = Modifier.testTag("emergency_stop_button")
                        ) {
                            Icon(Icons.Rounded.Stop, contentDescription = "Emergency Stop")
                            Spacer(Modifier.width(4.dp))
                            Text("STOP")
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatusPill("Camera: ${if (cameraStatus is CameraStatus.Running) "LIVE" else "OFF"}", cameraStatus is CameraStatus.Running)
                        StatusPill("Face: ${if (faceResult.detected) "LOCKED" else "STANDBY"}", faceResult.detected, ElectricBlue)
                        StatusPill("Hand: ${if (handResult.hands.isNotEmpty()) "${handResult.hands.size} TRACKED" else "STANDBY"}", handResult.hands.isNotEmpty())
                        StatusPill("Eye: ${if (eyeState.detected) eyeState.gazeZone.label else "OFF"}", eyeState.detected, ElectricBlue)
                        StatusPill("Mask: ${if (settings.mask.enabled) settings.mask.style.displayName else "OFF"}", settings.mask.enabled)
                    }
                }
            }

            // Adaptive Performance Warning Banner
            telemetry.warningMessage?.let { warning ->
                GlassCard(borderColor = CyberAmber.copy(alpha = 0.7f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = "Performance Warning",
                            tint = CyberAmber
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = warning,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberAmber
                        )
                    }
                }
            }

            // Live AI Camera Preview Card
            GlassCard(borderColor = GlassBorderBlue) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Live Vision Feed", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = if (cameraStatus is CameraStatus.Running) {
                            "${cameraStatus.resolutionLabel} • ${cameraStatus.fps} FPS"
                        } else {
                            telemetry.mode.displayName
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricBlue
                    )
                }
                Spacer(Modifier.height(10.dp))
                CameraViewportSurface(
                    cameraStatus = cameraStatus,
                    faceResult = faceResult,
                    handResult = handResult,
                    maskSettings = settings.mask,
                    mouseState = mouseState,
                    mouseSettings = settings.virtualMouse,
                    showLandmarks = true,
                    onPreviewViewCreated = onPreviewViewCreated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp)
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onStartStopCamera,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_camera_toggle"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (cameraStatus is CameraStatus.Running) AlertCrimson else NeonEmerald,
                            contentColor = ObsidianBlack
                        )
                    ) {
                        Icon(
                            if (cameraStatus is CameraStatus.Running) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                            contentDescription = null
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(if (cameraStatus is CameraStatus.Running) "Stop" else "Start")
                    }
                    OutlinedButton(
                        onClick = onSwitchCamera,
                        modifier = Modifier.testTag("dashboard_switch_lens")
                    ) {
                        Icon(Icons.Rounded.Cameraswitch, contentDescription = "Switch camera lens")
                    }
                    OutlinedButton(
                        onClick = onToggleMask,
                        modifier = Modifier.testTag("dashboard_mask_toggle")
                    ) {
                        Icon(
                            Icons.Rounded.FaceRetouchingNatural,
                            contentDescription = "Toggle cyber mask",
                            tint = if (settings.mask.enabled) NeonEmerald else TextSecondary
                        )
                    }
                    OutlinedButton(
                        onClick = onEnterPip,
                        modifier = Modifier.testTag("dashboard_pip_button")
                    ) {
                        Icon(Icons.Rounded.PictureInPictureAlt, contentDescription = "Picture in Picture")
                    }
                }
                if (gestureState.detectedGesture != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Detected: ${gestureState.detectedGesture.displayName} (${(gestureState.confidence * 100).toInt()}%)",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonEmerald
                    )
                }
            }

            // Performance Telemetry Snapshot
            GlassCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Adaptive Engine • ${telemetry.mode.displayName}", style = MaterialTheme.typography.titleSmall)
                    Text("Thermal: ${telemetry.thermalState.label}", style = MaterialTheme.typography.labelMedium, color = ElectricBlue)
                }
                Spacer(Modifier.height(10.dp))
                val memProgress = if (telemetry.totalMemoryMb > 0) {
                    1f - (telemetry.availableMemoryMb.toFloat() / telemetry.totalMemoryMb.toFloat())
                } else 0.4f
                HudMetricBar(
                    label = "RAM Free: ${telemetry.availableMemoryMb} MB",
                    valueText = "App: ${telemetry.appUsedMemoryMb} MB",
                    progress = memProgress,
                    color = NeonEmerald
                )
                Spacer(Modifier.height(8.dp))
                HudMetricBar(
                    label = "Inference Latency (Face ${telemetry.faceTrackingTimeMs}ms • Hand ${telemetry.handTrackingTimeMs}ms)",
                    valueText = "CPU ~${telemetry.cpuLoadEstimatePercent}%",
                    progress = telemetry.cpuLoadEstimatePercent / 100f,
                    color = ElectricBlue
                )
            }

            // Quick Modules Grid
            Text("Command Modules", style = MaterialTheme.typography.titleMedium, color = Color.White)
            val modules = listOf(
                ModuleTileData("Camera & Masks", "6 Cyber Masks & Live Feed", Icons.Rounded.FaceRetouchingNatural, NeonEmerald, onNavigateToCameraStudio),
                ModuleTileData("Gesture Controller", "11 Hand Gestures & Mapping", Icons.Rounded.FrontHand, ElectricBlue, onNavigateToGestures),
                ModuleTileData("ASIF Reels Mode", "Finger & Optional Gaze Reels", Icons.Rounded.SmartDisplay, NeonEmerald, onNavigateToReels),
                ModuleTileData("Virtual Mouse", "8 Cursors & Accessibility", Icons.Rounded.Mouse, ElectricBlue, onNavigateToVirtualMouse),
                ModuleTileData("Floating & Hidden", "Overlay HUD / Hidden Panel", Icons.Rounded.Visibility, CyberAmber, onStartFloatingVisible),
                ModuleTileData("ASIF AI Hub", "BYO API Chat & Setup", Icons.Rounded.AutoAwesome, NeonEmerald, onNavigateToAiHub),
                ModuleTileData("Voice & Sound", "Speech Commands & Audio", Icons.Rounded.Mic, ElectricBlue, onNavigateToSettings),
                ModuleTileData(
                    "Permissions & Perf",
                    "${listOf(permissions.cameraGranted, permissions.microphoneGranted, permissions.overlayGranted, accessibilityStatus.connected).count { it }}/4 Active",
                    Icons.Rounded.Security,
                    NeonEmerald,
                    onNavigateToSettings
                )
            )

            modules.chunked(2).forEach { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    pair.forEach { tile ->
                        ModuleActionCard(tile, modifier = Modifier.weight(1f))
                    }
                }
            }

            // Footer Developer Credit
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Developer: ASIF ISLAM • Build 2.0",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onNavigateToSettings() }
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Speed, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = TextSecondary, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

private data class ModuleTileData(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accent: Color,
    val onClick: () -> Unit
)

@Composable
private fun ModuleActionCard(
    data: ModuleTileData,
    modifier: Modifier = Modifier
) {
    GlassCard(
        borderColor = data.accent.copy(alpha = 0.28f),
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = data.onClick)
    ) {
        Icon(
            imageVector = data.icon,
            contentDescription = data.title,
            tint = data.accent,
            modifier = Modifier.size(24.dp)
        )
        Spacer(Modifier.height(8.dp))
        Text(text = data.title, style = MaterialTheme.typography.titleSmall, color = Color.White)
        Spacer(Modifier.height(2.dp))
        Text(text = data.subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}
