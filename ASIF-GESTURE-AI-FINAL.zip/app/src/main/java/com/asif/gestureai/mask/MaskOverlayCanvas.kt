package com.asif.gestureai.mask

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.asif.gestureai.core.FillCenterTransform
import com.asif.gestureai.face.FacePoint
import com.asif.gestureai.face.FaceTrackingResult
import com.asif.gestureai.settings.MaskSettings
import com.asif.gestureai.settings.MaskStyle
import kotlin.math.hypot

/**
 * Renders 6 original futuristic cybernetic masks dynamically aligned to live MediaPipe face landmarks,
 * with temporal smoothing, rotation, scale X/Y, offset X/Y, transparency, glow, and edge thickness.
 */
@Composable
fun MaskOverlayCanvas(
    faceResult: FaceTrackingResult,
    maskSettings: MaskSettings,
    showFaceMeshDebug: Boolean = false,
    modifier: Modifier = Modifier
) {
    var smoothedPoints by remember { mutableStateOf<List<FacePoint>>(emptyList()) }

    if (faceResult.detected && faceResult.landmarks.isNotEmpty()) {
        val alpha = (1f - maskSettings.smoothing.coerceIn(0f, 0.9f)).coerceIn(0.12f, 1f)
        smoothedPoints = if (smoothedPoints.size == faceResult.landmarks.size) {
            smoothedPoints.zip(faceResult.landmarks) { prev, next ->
                FacePoint(
                    x = prev.x + (next.x - prev.x) * alpha,
                    y = prev.y + (next.y - prev.y) * alpha,
                    z = next.z
                )
            }
        } else {
            faceResult.landmarks
        }
    } else if (!faceResult.detected) {
        smoothedPoints = emptyList()
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val points = smoothedPoints
        if (points.size < 468) return@Canvas
        val t = FillCenterTransform(faceResult.imageWidth, faceResult.imageHeight, size.width, size.height)

        if (showFaceMeshDebug) {
            val meshColor = Color(0xFF00D4FF).copy(alpha = 0.35f)
            for (i in points.indices step 3) {
                val p = points[i]
                drawCircle(meshColor, radius = 2.2f, center = Offset(t.x(p.x), t.y(p.y)))
            }
        }

        if (!maskSettings.enabled || maskSettings.style == MaskStyle.NONE) return@Canvas

        val neon = Color(maskSettings.neonColorArgb.toInt()).copy(alpha = maskSettings.transparency)
        val darkFill = Color(0xFF05080F).copy(alpha = (maskSettings.transparency * 0.85f).coerceIn(0.1f, 0.95f))
        val glowColor = neon.copy(alpha = (maskSettings.transparency * maskSettings.glowIntensity * 0.38f).coerceIn(0f, 0.6f))

        // Anchor key facial landmarks (MediaPipe 468-pt indices)
        val noseTip = points[1]
        val forehead = points[10]
        val chin = points[152]
        val leftCheek = points[234]
        val rightCheek = points[454]

        val anchorCenter = if (maskSettings.alignToFace) {
            Offset(t.x(noseTip.x), t.y(noseTip.y))
        } else {
            Offset(size.width * 0.5f, size.height * 0.5f)
        }

        val faceWidthPx = hypot(
            ((rightCheek.x - leftCheek.x) * t.scaledWidth).toDouble(),
            ((rightCheek.y - leftCheek.y) * t.scaledHeight).toDouble()
        ).toFloat().coerceAtLeast(80f)

        val faceHeightPx = hypot(
            ((chin.x - forehead.x) * t.scaledWidth).toDouble(),
            ((chin.y - forehead.y) * t.scaledHeight).toDouble()
        ).toFloat().coerceAtLeast(100f)

        fun mapPt(pt: FacePoint): Offset {
            val rawX = t.x(pt.x)
            val rawY = t.y(pt.y)
            val dx = (rawX - anchorCenter.x) * maskSettings.scale * maskSettings.widthScale
            val dy = (rawY - anchorCenter.y) * maskSettings.scale * maskSettings.heightScale
            return Offset(
                x = anchorCenter.x + dx + maskSettings.offsetX * size.width * 0.25f,
                y = anchorCenter.y + dy + maskSettings.offsetY * size.height * 0.25f
            )
        }

        val totalRotation = (if (maskSettings.alignToFace) faceResult.headRollDeg else 0f) + maskSettings.rotationDeg

        rotate(degrees = totalRotation, pivot = anchorCenter) {
            when (maskSettings.style) {
                MaskStyle.DIGITAL_ANONYMOUS -> drawDigitalAnonymousMask(points, ::mapPt, neon, darkFill, glowColor, maskSettings)
                MaskStyle.CYBERNETIC_ROBOT -> drawCyberneticRobotMask(points, ::mapPt, neon, darkFill, glowColor, maskSettings, faceWidthPx)
                MaskStyle.NEON_VISOR -> drawNeonVisorMask(points, ::mapPt, neon, darkFill, glowColor, maskSettings, faceWidthPx, faceHeightPx)
                MaskStyle.DARK_DIGITAL -> drawDarkDigitalMask(points, ::mapPt, neon, darkFill, glowColor, maskSettings)
                MaskStyle.MINIMAL_CYBER -> drawMinimalCyberMask(points, ::mapPt, neon, glowColor, maskSettings)
                MaskStyle.CUSTOM_DESIGN -> drawCustomDesignerMask(points, ::mapPt, neon, darkFill, glowColor, maskSettings)
                MaskStyle.NONE -> Unit
            }
        }
    }
}

private val FACE_OVAL_INDICES = intArrayOf(
    10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377,
    152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109
)
private val LEFT_EYE_RING = intArrayOf(33, 246, 161, 160, 159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7)
private val RIGHT_EYE_RING = intArrayOf(362, 398, 384, 385, 386, 387, 388, 466, 263, 249, 390, 373, 374, 380, 381, 382)

private fun buildClosedPath(points: List<FacePoint>, indices: IntArray, mapPt: (FacePoint) -> Offset): Path {
    val path = Path()
    indices.forEachIndexed { idx, lmIdx ->
        val pos = mapPt(points[lmIdx])
        if (idx == 0) path.moveTo(pos.x, pos.y) else path.lineTo(pos.x, pos.y)
    }
    path.close()
    return path
}

private fun DrawScope.drawGlowStroke(path: Path, neon: Color, glow: Color, thickness: Float, glowIntensity: Float) {
    if (glowIntensity > 0.05f) {
        drawPath(
            path = path,
            color = glow,
            style = Stroke(width = thickness * (2.6f + glowIntensity * 2.5f), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
    drawPath(
        path = path,
        color = neon,
        style = Stroke(width = thickness, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun DrawScope.drawDigitalAnonymousMask(
    points: List<FacePoint>,
    mapPt: (FacePoint) -> Offset,
    neon: Color,
    darkFill: Color,
    glow: Color,
    settings: MaskSettings
) {
    val facePath = buildClosedPath(points, FACE_OVAL_INDICES, mapPt)
    drawPath(facePath, color = darkFill)
    drawGlowStroke(facePath, neon, glow, settings.edgeThickness, settings.glowIntensity)

    // Cutout-style glowing eye frames
    val leftEye = buildClosedPath(points, LEFT_EYE_RING, mapPt)
    val rightEye = buildClosedPath(points, RIGHT_EYE_RING, mapPt)
    drawGlowStroke(leftEye, neon, glow, settings.edgeThickness * 0.85f, settings.glowIntensity)
    drawGlowStroke(rightEye, neon, glow, settings.edgeThickness * 0.85f, settings.glowIntensity)

    // Stylized sculpted brow & nose ridge & pointed beard contour
    val browL = Path().apply {
        val p1 = mapPt(points[70]); val p2 = mapPt(points[105]); val p3 = mapPt(points[107])
        moveTo(p1.x, p1.y); lineTo(p2.x, p2.y); lineTo(p3.x, p3.y)
    }
    val browR = Path().apply {
        val p1 = mapPt(points[300]); val p2 = mapPt(points[334]); val p3 = mapPt(points[336])
        moveTo(p1.x, p1.y); lineTo(p2.x, p2.y); lineTo(p3.x, p3.y)
    }
    val mustache = Path().apply {
        val l = mapPt(points[61]); val c = mapPt(points[0]); val r = mapPt(points[291])
        moveTo(l.x, l.y - 6f); lineTo(c.x, c.y); lineTo(r.x, r.y - 6f)
    }
    val goatee = Path().apply {
        val l = mapPt(points[17]); val b = mapPt(points[152])
        moveTo(l.x, l.y); lineTo(b.x, b.y)
    }
    drawGlowStroke(browL, neon, glow, settings.edgeThickness * 1.1f, settings.glowIntensity)
    drawGlowStroke(browR, neon, glow, settings.edgeThickness * 1.1f, settings.glowIntensity)
    drawGlowStroke(mustache, neon, glow, settings.edgeThickness * 1.2f, settings.glowIntensity)
    drawGlowStroke(goatee, neon, glow, settings.edgeThickness * 1.2f, settings.glowIntensity)
}

private fun DrawScope.drawCyberneticRobotMask(
    points: List<FacePoint>,
    mapPt: (FacePoint) -> Offset,
    neon: Color,
    darkFill: Color,
    glow: Color,
    settings: MaskSettings,
    faceWidthPx: Float
) {
    // Segmented robotic jaw plate & forehead armor
    val jawIndices = intArrayOf(234, 93, 132, 58, 172, 136, 150, 149, 176, 148, 152, 377, 400, 378, 379, 365, 397, 288, 361, 323, 454, 291, 61)
    val jawPath = buildClosedPath(points, jawIndices, mapPt)
    drawPath(jawPath, color = darkFill)
    drawGlowStroke(jawPath, neon, glow, settings.edgeThickness, settings.glowIntensity)

    // Robotic eye scanner bars
    val lCenter = mapPt(points[468.coerceAtMost(points.lastIndex)])
    val rCenter = mapPt(points[473.coerceAtMost(points.lastIndex)])
    val reticleRadius = faceWidthPx * 0.085f
    drawCircle(neon, radius = reticleRadius, center = lCenter, style = Stroke(settings.edgeThickness))
    drawCircle(neon, radius = reticleRadius, center = rCenter, style = Stroke(settings.edgeThickness))
    drawLine(neon, Offset(lCenter.x - reticleRadius * 1.5f, lCenter.y), Offset(lCenter.x + reticleRadius * 1.5f, lCenter.y), strokeWidth = 2f)
    drawLine(neon, Offset(rCenter.x - reticleRadius * 1.5f, rCenter.y), Offset(rCenter.x + reticleRadius * 1.5f, rCenter.y), strokeWidth = 2f)

    // Hydraulic cheek struts
    val noseBridge = mapPt(points[6])
    val lCheek = mapPt(points[50])
    val rCheek = mapPt(points[280])
    val strutPath = Path().apply {
        moveTo(lCheek.x, lCheek.y); lineTo(noseBridge.x, noseBridge.y); lineTo(rCheek.x, rCheek.y)
    }
    drawGlowStroke(strutPath, neon, glow, settings.edgeThickness * 0.9f, settings.glowIntensity)
}

private fun DrawScope.drawNeonVisorMask(
    points: List<FacePoint>,
    mapPt: (FacePoint) -> Offset,
    neon: Color,
    darkFill: Color,
    glow: Color,
    settings: MaskSettings,
    faceWidthPx: Float,
    faceHeightPx: Float
) {
    val visorPts = intArrayOf(70, 63, 105, 66, 107, 9, 336, 296, 334, 293, 300, 356, 454, 346, 280, 6, 50, 117, 127)
    val visorPath = buildClosedPath(points, visorPts, mapPt)
    drawPath(visorPath, color = darkFill.copy(alpha = (settings.transparency * 0.65f).coerceIn(0.1f, 0.85f)))
    drawGlowStroke(visorPath, neon, glow, settings.edgeThickness * 1.15f, settings.glowIntensity)

    // Horizontal optic scanline across bridge
    val lTemple = mapPt(points[127])
    val rTemple = mapPt(points[356])
    drawLine(neon.copy(alpha = 0.65f), lTemple, rTemple, strokeWidth = (faceHeightPx * 0.012f).coerceAtLeast(2f))
    // Nose bridge tactical chevron
    val nTop = mapPt(points[168])
    val nMid = mapPt(points[4])
    drawLine(neon, nTop, nMid, strokeWidth = settings.edgeThickness)
}

private fun DrawScope.drawDarkDigitalMask(
    points: List<FacePoint>,
    mapPt: (FacePoint) -> Offset,
    neon: Color,
    darkFill: Color,
    glow: Color,
    settings: MaskSettings
) {
    val lowerIndices = intArrayOf(127, 234, 93, 132, 58, 172, 136, 150, 149, 176, 148, 152, 377, 400, 378, 379, 365, 397, 288, 361, 323, 454, 356, 346, 280, 6, 50, 117)
    val platePath = buildClosedPath(points, lowerIndices, mapPt)
    drawPath(platePath, color = darkFill.copy(alpha = 0.9f))
    drawGlowStroke(platePath, neon, glow, settings.edgeThickness, settings.glowIntensity)

    // Digital mouth equalizer bars
    val mouthL = mapPt(points[61])
    val mouthR = mapPt(points[291])
    val bars = 6
    for (i in 0..bars) {
        val t = i.toFloat() / bars
        val bx = mouthL.x + (mouthR.x - mouthL.x) * t
        val by = mouthL.y + (mouthR.y - mouthL.y) * t
        val h = if (i % 2 == 0) 14f else 8f
        drawLine(neon, Offset(bx, by - h), Offset(bx, by + h), strokeWidth = settings.edgeThickness * 0.85f, cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawMinimalCyberMask(
    points: List<FacePoint>,
    mapPt: (FacePoint) -> Offset,
    neon: Color,
    glow: Color,
    settings: MaskSettings
) {
    val contour = Path().apply {
        val l = mapPt(points[234]); val c = mapPt(points[152]); val r = mapPt(points[454])
        moveTo(l.x, l.y); lineTo(c.x, c.y); lineTo(r.x, r.y)
    }
    drawGlowStroke(contour, neon, glow, settings.edgeThickness * 0.9f, settings.glowIntensity)
    val keyNodes = intArrayOf(10, 33, 263, 1, 234, 454, 152)
    keyNodes.forEach { idx ->
        val p = mapPt(points[idx])
        drawCircle(neon, radius = settings.edgeThickness * 1.6f, center = p)
    }
}

private fun DrawScope.drawCustomDesignerMask(
    points: List<FacePoint>,
    mapPt: (FacePoint) -> Offset,
    neon: Color,
    darkFill: Color,
    glow: Color,
    settings: MaskSettings
) {
    val oval = buildClosedPath(points, FACE_OVAL_INDICES, mapPt)
    drawPath(oval, color = darkFill.copy(alpha = settings.transparency * 0.45f))
    drawGlowStroke(oval, neon, glow, settings.edgeThickness, settings.glowIntensity)

    val eyeL = buildClosedPath(points, LEFT_EYE_RING, mapPt)
    val eyeR = buildClosedPath(points, RIGHT_EYE_RING, mapPt)
    drawGlowStroke(eyeL, neon, glow, settings.edgeThickness * 0.9f, settings.glowIntensity)
    drawGlowStroke(eyeR, neon, glow, settings.edgeThickness * 0.9f, settings.glowIntensity)

    val wireTri = Path().apply {
        val f = mapPt(points[10]); val l = mapPt(points[234]); val r = mapPt(points[454]); val c = mapPt(points[152]); val n = mapPt(points[1])
        moveTo(f.x, f.y); lineTo(l.x, l.y); lineTo(c.x, c.y); lineTo(r.x, r.y); lineTo(f.x, f.y)
        moveTo(l.x, l.y); lineTo(n.x, n.y); lineTo(r.x, r.y)
        moveTo(f.x, f.y); lineTo(n.x, n.y); lineTo(c.x, c.y)
    }
    drawGlowStroke(wireTri, neon.copy(alpha = neon.alpha * 0.8f), glow, settings.edgeThickness * 0.7f, settings.glowIntensity)
}
