package com.asif.gestureai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.asif.gestureai.core.AppLogger
import com.asif.gestureai.core.PermissionHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceCommandIntent {
    START_CAMERA,
    STOP_CAMERA,
    ENABLE_MASK,
    DISABLE_MASK,
    ENABLE_GESTURES,
    DISABLE_GESTURES,
    MODE_BATTERY_SAVER,
    MODE_BALANCED,
    MODE_PERFORMANCE,
    OPEN_AI_HUB,
    PAUSE_CONTROLS,
    RESUME_CONTROLS,
    OPEN_APP,
    UNKNOWN
}

data class VoiceParsedCommand(
    val rawTranscript: String,
    val intent: VoiceCommandIntent,
    val appTargetQuery: String? = null
)

data class VoiceStatusState(
    val availableOnDevice: Boolean = false,
    val isListening: Boolean = false,
    val lastTranscript: String = "",
    val lastCommandLabel: String = "Tap Voice Mic to issue a command",
    val errorMessage: String? = null
)

/**
 * Visible-status Android SpeechRecognizer controller.
 * Never records silently in the background; provides immediate stop control.
 */
class VoiceControlManager(private val context: Context) {

    companion object {
        private const val TAG = "VoiceControlManager"
    }

    private val _status = MutableStateFlow(
        VoiceStatusState(availableOnDevice = SpeechRecognizer.isRecognitionAvailable(context))
    )
    val status: StateFlow<VoiceStatusState> = _status.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var onCommandCallback: ((VoiceParsedCommand) -> Unit)? = null

    fun setCommandListener(listener: (VoiceParsedCommand) -> Unit) {
        onCommandCallback = listener
    }

    fun startListening() {
        if (!PermissionHelper.snapshot(context).microphoneGranted) {
            _status.value = _status.value.copy(
                isListening = false,
                errorMessage = "Microphone permission is required for Voice Control."
            )
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _status.value = _status.value.copy(
                availableOnDevice = false,
                isListening = false,
                errorMessage = "On-device or Google Speech Recognition service is not installed."
            )
            return
        }

        stopListening()

        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer = recognizer
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _status.value = _status.value.copy(
                        isListening = true,
                        errorMessage = null,
                        lastCommandLabel = "Listening..."
                    )
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    _status.value = _status.value.copy(isListening = false)
                }

                override fun onError(error: Int) {
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that command. Try again."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Voice timed out."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
                        else -> "Speech service error ($error)."
                    }
                    _status.value = _status.value.copy(isListening = false, errorMessage = msg)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val transcript = matches?.firstOrNull().orEmpty()
                    _status.value = _status.value.copy(
                        isListening = false,
                        lastTranscript = transcript,
                        errorMessage = null
                    )
                    if (transcript.isNotBlank()) {
                        val parsed = parseTranscript(transcript)
                        _status.value = _status.value.copy(lastCommandLabel = "${parsed.intent.name}: \"$transcript\"")
                        onCommandCallback?.invoke(parsed)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!partial.isNullOrBlank()) {
                        _status.value = _status.value.copy(lastTranscript = partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer.startListening(intent)
        } catch (e: Exception) {
            AppLogger.e(TAG, "Unable to start SpeechRecognizer", e)
            _status.value = _status.value.copy(
                isListening = false,
                errorMessage = "Speech recognition unavailable: ${e.localizedMessage ?: "error"}"
            )
        }
    }

    fun stopListening() {
        runCatching {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        }
        speechRecognizer = null
        _status.value = _status.value.copy(isListening = false)
    }

    fun parseTranscript(raw: String): VoiceParsedCommand {
        val t = raw.lowercase(Locale.US).trim()
        return when {
            t.contains("start camera") || t.contains("open camera") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.START_CAMERA)
            t.contains("stop camera") || t.contains("close camera") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.STOP_CAMERA)
            t.contains("enable mask") || t.contains("mask on") || t.contains("show mask") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.ENABLE_MASK)
            t.contains("disable mask") || t.contains("mask off") || t.contains("hide mask") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.DISABLE_MASK)
            t.contains("enable gesture") || t.contains("gestures on") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.ENABLE_GESTURES)
            t.contains("disable gesture") || t.contains("gestures off") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.DISABLE_GESTURES)
            t.contains("battery saver") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.MODE_BATTERY_SAVER)
            t.contains("balanced") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.MODE_BALANCED)
            t.contains("performance") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.MODE_PERFORMANCE)
            t.contains("ai assistant") || t.contains("ai hub") || t.contains("open chat") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.OPEN_AI_HUB)
            t.contains("pause") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.PAUSE_CONTROLS)
            t.contains("resume") ->
                VoiceParsedCommand(raw, VoiceCommandIntent.RESUME_CONTROLS)
            t.startsWith("open ") || t.startsWith("launch ") -> {
                val target = t.removePrefix("open ").removePrefix("launch ").trim()
                VoiceParsedCommand(raw, VoiceCommandIntent.OPEN_APP, appTargetQuery = target)
            }
            else -> VoiceParsedCommand(raw, VoiceCommandIntent.UNKNOWN)
        }
    }

    fun launchInstalledAppByName(query: String): Boolean {
        if (query.isBlank()) return false
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(mainIntent, 0)
        val match = apps.firstOrNull { resolveInfo ->
            resolveInfo.loadLabel(pm).toString().lowercase(Locale.US).contains(query.lowercase(Locale.US))
        } ?: return false

        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
        return true
    }
}
