package com.asif.gestureai.ui.screens

import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cameraswitch
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.asif.gestureai.camera.CameraStatus
import com.asif.gestureai.data.local.CustomMaskEntity
import com.asif.gestureai.face.FaceTrackingResult
import com.asif.gestureai.gesture.HandTrackingResult
import com.asif.gestureai.settings.CameraSettings
import com.asif.gestureai.settings.MaskSettings
import com.asif.gestureai.settings.MaskStyle
import com.asif.gestureai.settings.ResolutionTier
import com.asif.gestureai.settings.VirtualMouseSettings
import com.asif.gestureai.ui.components.CameraViewportSurface
import com.asif.gestureai.ui.components.GlassCard
import com.asif.gestureai.virtualmouse.VirtualMouseState
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CameraStudioScreen(
    cameraStatus: CameraStatus,
    cameraSettings: CameraSettings,
    maskSettings: MaskSettings,
    faceResult: FaceTrackingResult,
    handResult: HandTrackingResult,
    mouseState: VirtualMouseState,
    mouseSettings: VirtualMouseSettings,
    savedMasks: List<CustomMaskEntity>,
    onPreviewViewCreated: (PreviewView) -> Unit,
    onStartStopCamera: () -> Unit,
    onSwitchLens: () -> Unit,
    onUpdateCameraSettings: ((CameraSettings) -> CameraSettings) -> Unit,
    onUpdateMaskSettings: ((MaskSettings) -> MaskSettings) -> Unit,
    onSaveCustomMask: (String) -> Unit,
    onApplySavedMask: (CustomMaskEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var showDebugLandmarks by remember { mutableStateOf(true) }
    var presetName by remember { mutableStateOf("Cyber Custom 1") }

    val neonSwatches = listOf(
        0xFF00FF88L, // Neon Emerald
        0xFF00D4FFL, // Electric Blue
        0xFFFF4D6DL, // Crimson Neon
        0xFFFFB800L, // Cyber Amber
        0xFFA855F7L, // Ultraviolet
        0xFFFFFFFFL  // Pure White
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("AI Camera & Cyber Mask Studio", style = MaterialTheme.typography.headlineSmall, color = NeonEmerald)

            CameraViewportSurface(
                cameraStatus = cameraStatus,
                faceResult = faceResult,
                handResult = handResult,
                maskSettings = maskSettings,
                mouseState = mouseState,
                mouseSettings = mouseSettings,
                showLandmarks = showDebugLandmarks,
                onPreviewViewCreated = onPreviewViewCreated,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp)
            )

            // Camera Controls
            GlassCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onStartStopCamera,
                        modifier = Modifier.weight(1f).testTag("studio_camera_toggle"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (cameraStatus is CameraStatus.Running) AlertCrimson else NeonEmerald,
                            contentColor = ObsidianBlack
                        )
                    ) {
                        Icon(if (cameraStatus is CameraStatus.Running) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (cameraStatus is CameraStatus.Running) "Stop Camera" else "Start Camera")
                    }
                    OutlinedButton(onClick = onSwitchLens, modifier = Modifier.testTag("studio_switch_lens")) {
                        Icon(Icons.Rounded.Cameraswitch, contentDescription = "Switch Lens")
                        Spacer(Modifier.width(4.dp))
                        Text(cameraSettings.lens.label)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Show Face/Hand Landmarks", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = showDebugLandmarks, onCheckedChange = { showDebugLandmarks = it })
                }
                Spacer(Modifier.height(8.dp))
                Text("Resolution Profile", style = MaterialTheme.typography.labelMedium, color = ElectricBlue)
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ResolutionTier.entries.forEach { tier ->
                        FilterChip(
                            selected = cameraSettings.resolutionTier == tier,
                            onClick = { onUpdateCameraSettings { it.copy(resolutionTier = tier) } },
                            label = { Text(tier.label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Target FPS: ${cameraSettings.targetFps} fps", style = MaterialTheme.typography.labelMedium)
                Slider(
                    value = cameraSettings.targetFps.toFloat(),
                    onValueChange = { fps -> onUpdateCameraSettings { it.copy(targetFps = fps.toInt()) } },
                    valueRange = 10f..30f,
                    steps = 3
                )
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("High Preview Resolution", style = MaterialTheme.typography.bodyMedium)
                        Text("720x960 preview while keeping AI analysis lightweight", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Switch(
                        checked = cameraSettings.highPreviewQuality,
                        onCheckedChange = { v -> onUpdateCameraSettings { it.copy(highPreviewQuality = v) } },
                        modifier = Modifier.testTag("studio_high_preview_switch")
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto Camera Recovery", style = MaterialTheme.typography.bodyMedium)
                        Text("Safe recovery prompt on transient hardware conflict", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Switch(
                        checked = cameraSettings.autoRecoveryEnabled,
                        onCheckedChange = { v -> onUpdateCameraSettings { it.copy(autoRecoveryEnabled = v) } },
                        modifier = Modifier.testTag("studio_auto_recovery_switch")
                    )
                }
            }

            // Cyber Mask Designer
            GlassCard(borderColor = NeonEmerald.copy(alpha = 0.35f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Advanced Hacker & Cyber Mask", style = MaterialTheme.typography.titleMedium)
                        Text("Landmark-tracked 468-pt facial fit", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    Switch(
                        checked = maskSettings.enabled,
                        onCheckedChange = { enabled -> onUpdateMaskSettings { it.copy(enabled = enabled) } },
                        modifier = Modifier.testTag("studio_mask_switch")
                    )
                }

                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MaskStyle.entries.forEach { style ->
                        FilterChip(
                            selected = maskSettings.style == style,
                            onClick = { onUpdateMaskSettings { it.copy(style = style, enabled = style != MaskStyle.NONE) } },
                            label = { Text(style.displayName, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text("Neon Color", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    neonSwatches.forEach { hex ->
                        val selected = maskSettings.neonColorArgb == hex
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(hex.toInt()))
                                .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color.Gray, CircleShape)
                                .clickable { onUpdateMaskSettings { it.copy(neonColorArgb = hex) } }
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))
                MaskSliderRow("Mask Scale", maskSettings.scale, 0.6f..1.6f) { v -> onUpdateMaskSettings { it.copy(scale = v) } }
                MaskSliderRow("Width Scale", maskSettings.widthScale, 0.7f..1.4f) { v -> onUpdateMaskSettings { it.copy(widthScale = v) } }
                MaskSliderRow("Height Scale", maskSettings.heightScale, 0.7f..1.4f) { v -> onUpdateMaskSettings { it.copy(heightScale = v) } }
                MaskSliderRow("Offset X", maskSettings.offsetX, -0.5f..0.5f) { v -> onUpdateMaskSettings { it.copy(offsetX = v) } }
                MaskSliderRow("Offset Y", maskSettings.offsetY, -0.5f..0.5f) { v -> onUpdateMaskSettings { it.copy(offsetY = v) } }
                MaskSliderRow("Rotation (°)", maskSettings.rotationDeg, -35f..35f) { v -> onUpdateMaskSettings { it.copy(rotationDeg = v) } }
                MaskSliderRow("Transparency", maskSettings.transparency, 0.2f..1.0f) { v -> onUpdateMaskSettings { it.copy(transparency = v) } }
                MaskSliderRow("Glow Intensity", maskSettings.glowIntensity, 0f..1.0f) { v -> onUpdateMaskSettings { it.copy(glowIntensity = v) } }
                MaskSliderRow("Edge Thickness", maskSettings.edgeThickness, 1f..8f) { v -> onUpdateMaskSettings { it.copy(edgeThickness = v) } }
                MaskSliderRow("Landmark Smoothing", maskSettings.smoothing, 0f..0.85f) { v -> onUpdateMaskSettings { it.copy(smoothing = v) } }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Align & Rotate to Face", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = maskSettings.alignToFace,
                        onCheckedChange = { v -> onUpdateMaskSettings { it.copy(alignToFace = v) } }
                    )
                }

                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = presetName,
                        onValueChange = { presetName = it },
                        label = { Text("Preset Name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = { onSaveCustomMask(presetName) }) {
                        Icon(Icons.Rounded.Save, contentDescription = "Save mask preset")
                        Spacer(Modifier.width(4.dp))
                        Text("Save")
                    }
                }

                if (savedMasks.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("Saved Mask Presets", style = MaterialTheme.typography.labelMedium, color = CyberAmber)
                    Spacer(Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        savedMasks.forEach { preset ->
                            FilterChip(
                                selected = false,
                                onClick = { onApplySavedMask(preset) },
                                label = { Text(preset.name) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MaskSliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text(String.format("%.2f", value), style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
        }
        Slider(value = value.coerceIn(range.start, range.endInclusive), onValueChange = onValueChange, valueRange = range)
    }
}
