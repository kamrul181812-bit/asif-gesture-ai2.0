package com.asif.gestureai.aihub

enum class AiAdapterType(
    val displayName: String,
    val defaultBaseUrl: String,
    val defaultChatPath: String,
    val defaultModel: String,
    val formatNote: String
) {
    OPENAI_COMPATIBLE(
        displayName = "OpenAI-Compatible",
        defaultBaseUrl = "https://api.openai.com/v1",
        defaultChatPath = "/chat/completions",
        defaultModel = "gpt-4o-mini",
        formatNote = "Uses Bearer token auth and standard OpenAI /chat/completions & /models JSON schema (also works with Groq, OpenRouter, DeepSeek, Ollama)."
    ),
    GEMINI_COMPAT(
        displayName = "Gemini (OpenAI-Compat)",
        defaultBaseUrl = "https://generativelanguage.googleapis.com/v1beta/openai",
        defaultChatPath = "/chat/completions",
        defaultModel = "gemini-2.5-flash",
        formatNote = "Uses Bearer Gemini API key against Google's documented OpenAI-compatible REST endpoint."
    ),
    ANTHROPIC_COMPAT(
        displayName = "Anthropic-Compatible",
        defaultBaseUrl = "https://api.anthropic.com/v1",
        defaultChatPath = "/messages",
        defaultModel = "claude-3-5-sonnet-latest",
        formatNote = "Uses x-api-key + anthropic-version headers and /v1/messages JSON schema."
    ),
    CUSTOM_REST(
        displayName = "Custom REST Endpoint",
        defaultBaseUrl = "https://your-endpoint.example.com/v1",
        defaultChatPath = "/chat/completions",
        defaultModel = "custom-model",
        formatNote = "Requires OpenAI-compatible JSON request/response format or custom headers configured below. Arbitrary proprietary schemas cannot be auto-detected without matching JSON fields."
    )
}

data class AiSetupValidationResult(
    val success: Boolean,
    val endpointValid: Boolean,
    val authValid: Boolean,
    val detectedFormat: String,
    val discoveredModels: List<String>,
    val statusMessage: String
)

data class AiChatDraftMessage(
    val role: String,
    val content: String
)
