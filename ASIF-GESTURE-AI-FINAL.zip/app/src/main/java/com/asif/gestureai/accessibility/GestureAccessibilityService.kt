package com.asif.gestureai.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.asif.gestureai.core.AppLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

data class AccessibilityStatus(
    val connected: Boolean = false,
    val paused: Boolean = false,
    val protectedSurfacePaused: Boolean = false,
    val protectedReason: String? = null,
    val lastAction: String = "Idle"
)

object AccessibilityBridge {
    private val _status = MutableStateFlow(AccessibilityStatus())
    val status: StateFlow<AccessibilityStatus> = _status.asStateFlow()

    @Volatile
    private var serviceRef: WeakReference<GestureAccessibilityService>? = null

    internal fun attach(service: GestureAccessibilityService) {
        serviceRef = WeakReference(service)
        _status.value = _status.value.copy(connected = true, lastAction = "Accessibility Ready")
    }

    internal fun detach() {
        serviceRef = null
        _status.value = AccessibilityStatus(connected = false, lastAction = "Disconnected")
    }

    internal fun updateProtectedPause(paused: Boolean, reason: String?) {
        _status.value = _status.value.copy(
            protectedSurfacePaused = paused,
            protectedReason = reason
        )
    }

    fun setPaused(paused: Boolean) {
        _status.value = _status.value.copy(
            paused = paused,
            lastAction = if (paused) "Controls Paused" else "Controls Resumed"
        )
    }

    fun emergencyStop() {
        _status.value = _status.value.copy(
            paused = true,
            lastAction = "EMERGENCY STOP activated"
        )
    }

    private fun canExecute(): GestureAccessibilityService? {
        val s = serviceRef?.get() ?: return null
        val st = _status.value
        if (st.paused || st.protectedSurfacePaused) return null
        return s
    }

    fun performTap(xPx: Float, yPx: Float): Boolean {
        val s = canExecute() ?: return false
        val ok = s.dispatchTap(xPx, yPx)
        if (ok) _status.value = _status.value.copy(lastAction = "Tap (${xPx.toInt()}, ${yPx.toInt()})")
        return ok
    }

    fun performDoubleTap(xPx: Float, yPx: Float): Boolean {
        val s = canExecute() ?: return false
        val ok = s.dispatchDoubleTap(xPx, yPx)
        if (ok) _status.value = _status.value.copy(lastAction = "Double Tap (${xPx.toInt()}, ${yPx.toInt()})")
        return ok
    }

    fun performScroll(scrollDown: Boolean): Boolean {
        val s = canExecute() ?: return false
        val ok = s.dispatchScroll(scrollDown)
        if (ok) _status.value = _status.value.copy(lastAction = if (scrollDown) "Scroll Next" else "Scroll Previous")
        return ok
    }

    fun performGlobalBack(): Boolean {
        val s = canExecute() ?: return false
        val ok = s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        if (ok) _status.value = _status.value.copy(lastAction = "Global Back")
        return ok
    }

    fun performGlobalHome(): Boolean {
        val s = canExecute() ?: return false
        val ok = s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
        if (ok) _status.value = _status.value.copy(lastAction = "Global Home")
        return ok
    }

    fun performGlobalRecents(): Boolean {
        val s = canExecute() ?: return false
        val ok = s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
        if (ok) _status.value = _status.value.copy(lastAction = "Recent Apps")
        return ok
    }
}

/**
 * Legitimate Android AccessibilityService enabling user-authorized Virtual Mouse taps,
 * scrolling, and system navigation while explicitly blocking automation on banking,
 * authentication, lockscreen, or sensitive security dialogs.
 */
class GestureAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "GestureAccessibility"
        private val PROTECTED_KEYWORDS = listOf(
            "bank", "wallet", "pay", "upi", "bkash", "nagad", "rocket",
            "auth", "biometric", "keyguard", "lockscreen", "credential",
            "permissioncontroller", "packageinstaller", "settings.password"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        AccessibilityBridge.attach(this)
        AppLogger.i(TAG, "GestureAccessibilityService connected.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()?.lowercase() ?: return
        val cls = event.className?.toString()?.lowercase() ?: ""
        val isPassword = event.isPassword
        val matchedKeyword = PROTECTED_KEYWORDS.firstOrNull { pkg.contains(it) || cls.contains(it) }

        if (isPassword || matchedKeyword != null) {
            AccessibilityBridge.updateProtectedPause(
                paused = true,
                reason = "Safety pause: protected or authentication interface active."
            )
        } else if (AccessibilityBridge.status.value.protectedSurfacePaused) {
            AccessibilityBridge.updateProtectedPause(paused = false, reason = null)
        }
    }

    override fun onInterrupt() {
        AccessibilityBridge.setPaused(true)
        AppLogger.w(TAG, "Accessibility service interrupted.")
    }

    override fun onDestroy() {
        AccessibilityBridge.detach()
        super.onDestroy()
        AppLogger.i(TAG, "GestureAccessibilityService destroyed.")
    }

    fun dispatchTap(x: Float, y: Float): Boolean {
        val safeX = x.coerceAtLeast(1f)
        val safeY = y.coerceAtLeast(1f)
        val path = Path().apply { moveTo(safeX, safeY) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 65L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    fun dispatchDoubleTap(x: Float, y: Float): Boolean {
        val safeX = x.coerceAtLeast(1f)
        val safeY = y.coerceAtLeast(1f)
        val path1 = Path().apply { moveTo(safeX, safeY) }
        val path2 = Path().apply { moveTo(safeX, safeY) }
        val stroke1 = GestureDescription.StrokeDescription(path1, 0L, 50L)
        val stroke2 = GestureDescription.StrokeDescription(path2, 110L, 50L)
        val gesture = GestureDescription.Builder().addStroke(stroke1).addStroke(stroke2).build()
        return dispatchGesture(gesture, null, null)
    }

    fun dispatchScroll(scrollDown: Boolean): Boolean {
        val metrics = resources.displayMetrics
        val cx = metrics.widthPixels * 0.5f
        val startY = if (scrollDown) metrics.heightPixels * 0.72f else metrics.heightPixels * 0.30f
        val endY = if (scrollDown) metrics.heightPixels * 0.25f else metrics.heightPixels * 0.75f
        val path = Path().apply {
            moveTo(cx, startY)
            lineTo(cx, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 260L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }
}
