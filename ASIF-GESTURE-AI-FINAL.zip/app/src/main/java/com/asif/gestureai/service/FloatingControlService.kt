package com.asif.gestureai.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.asif.gestureai.accessibility.AccessibilityBridge
import com.asif.gestureai.core.AppLogger
import com.asif.gestureai.settings.FloatingSizePreset
import com.asif.gestureai.settings.FloatingVisibilityMode
import com.asif.gestureai.settings.FloatingWindowSettings
import com.asif.gestureai.settings.VirtualMouseSettings
import com.asif.gestureai.virtualmouse.VirtualMouseState
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.abs

data class FloatingOverlayState(
    val running: Boolean = false,
    val visibilityMode: FloatingVisibilityMode = FloatingVisibilityMode.VISIBLE,
    val overlayPermissionGranted: Boolean = false,
    val statusText: String = "Stopped"
)

/**
 * Foreground Service managing:
 * 1. The customizable Floating Control Window (Visible / Mini / Hidden Panel Mode)
 * 2. System-level non-touchable Virtual Pointer Overlay when Virtual Mouse & Overlay Permission are active
 *
 * Platform Honesty & Privacy:
 * - Visible & Mini modes show a draggable, edge-snapping WindowManager overlay when SYSTEM_ALERT_WINDOW is granted.
 * - Hidden Panel Mode hides the floating control panel while keeping authorized accessibility/virtual mouse
 *   controls available and maintaining a persistent notification with Restore & Emergency STOP actions.
 * - System pointer automatically hides on protected banking/authentication surfaces.
 * - Never hides Android system camera/mic privacy indicators.
 */
class FloatingControlService : Service() {

    companion object {
        private const val TAG = "FloatingControlService"
        private const val CHANNEL_ID = "asif_floating_control_channel"
        private const val NOTIFICATION_ID = 2048

        const val ACTION_START = "com.asif.gestureai.ACTION_START_FLOATING"
        const val ACTION_RESTORE_PANEL = "com.asif.gestureai.ACTION_RESTORE_PANEL"
        const val ACTION_HIDE_PANEL = "com.asif.gestureai.ACTION_HIDE_PANEL"
        const val ACTION_MINI_MODE = "com.asif.gestureai.ACTION_MINI_MODE"
        const val ACTION_EMERGENCY_STOP = "com.asif.gestureai.ACTION_EMERGENCY_STOP"
        const val ACTION_APPLY_SETTINGS = "com.asif.gestureai.ACTION_APPLY_SETTINGS"

        private val _state = MutableStateFlow(FloatingOverlayState())
        val state: StateFlow<FloatingOverlayState> = _state.asStateFlow()

        private val _pointerState = MutableStateFlow(VirtualMouseState())
        private val _pointerSettings = MutableStateFlow(VirtualMouseSettings())

        @Volatile
        var currentSettings: FloatingWindowSettings = FloatingWindowSettings()

        fun updatePointerState(state: VirtualMouseState, settings: VirtualMouseSettings) {
            _pointerState.value = state
            _pointerSettings.value = settings
        }

        fun start(context: Context, settings: FloatingWindowSettings) {
            currentSettings = settings
            val intent = Intent(context, FloatingControlService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun updateMode(context: Context, mode: FloatingVisibilityMode, settings: FloatingWindowSettings) {
            currentSettings = settings.copy(visibilityMode = mode)
            val action = when (mode) {
                FloatingVisibilityMode.VISIBLE -> ACTION_RESTORE_PANEL
                FloatingVisibilityMode.MINI -> ACTION_MINI_MODE
                FloatingVisibilityMode.HIDDEN_PANEL -> ACTION_HIDE_PANEL
            }
            val intent = Intent(context, FloatingControlService::class.java).apply { this.action = action }
            context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingControlService::class.java))
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var pointerView: View? = null
    private var pointerParams: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as? WindowManager
        createNotificationChannel()
        observeVirtualPointer()
    }

    private fun observeVirtualPointer() {
        serviceScope.launch {
            combine(_pointerState, _pointerSettings, AccessibilityBridge.status) { pState, pSettings, acc ->
                Triple(pState, pSettings, acc)
            }.collect { (pState, pSettings, acc) ->
                val shouldShow = pSettings.enabled &&
                    pState.active &&
                    Settings.canDrawOverlays(this@FloatingControlService) &&
                    !acc.paused &&
                    !acc.protectedSurfacePaused
                if (shouldShow) {
                    showOrMovePointer(pState, pSettings)
                } else {
                    removePointerView()
                }
            }
        }
    }

    private fun showOrMovePointer(state: VirtualMouseState, settings: VirtualMouseSettings) {
        val dm = resources.displayMetrics
        val sizePx = (settings.cursorSizeDp * dm.density).toInt().coerceIn(24, 120)
        val xPx = (state.normX * dm.widthPixels - sizePx / 2f).toInt().coerceIn(0, (dm.widthPixels - sizePx).coerceAtLeast(0))
        val yPx = (state.normY * dm.heightPixels - sizePx / 2f).toInt().coerceIn(0, (dm.heightPixels - sizePx).coerceAtLeast(0))

        val existing = pointerView
        val params = pointerParams
        if (existing != null && params != null) {
            params.x = xPx
            params.y = yPx
            params.width = sizePx
            params.height = sizePx
            (existing.background as? GradientDrawable)?.apply {
                setColor(if (state.isClicking) settings.cursorColorArgb.toInt() else Color.argb(90, 0, 212, 255))
                setStroke(5, settings.cursorColorArgb.toInt())
            }
            runCatching { windowManager?.updateViewLayout(existing, params) }
            return
        }

        val dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(90, 0, 212, 255))
                setStroke(5, settings.cursorColorArgb.toInt())
            }
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val lp = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = xPx
            y = yPx
        }

        runCatching {
            windowManager?.addView(dot, lp)
            pointerView = dot
            pointerParams = lp
        }
    }

    private fun removePointerView() {
        pointerView?.let { v ->
            runCatching { windowManager?.removeViewImmediate(v) }
        }
        pointerView = null
        pointerParams = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), fgsType)

        when (intent?.action) {
            ACTION_EMERGENCY_STOP -> {
                AccessibilityBridge.emergencyStop()
                removeOverlayView()
                removePointerView()
                _state.value = FloatingOverlayState(
                    running = false,
                    visibilityMode = currentSettings.visibilityMode,
                    overlayPermissionGranted = Settings.canDrawOverlays(this),
                    statusText = "Emergency Stopped"
                )
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_HIDE_PANEL -> {
                currentSettings = currentSettings.copy(visibilityMode = FloatingVisibilityMode.HIDDEN_PANEL)
                removeOverlayView()
                updateNotification()
            }
            ACTION_MINI_MODE -> {
                currentSettings = currentSettings.copy(visibilityMode = FloatingVisibilityMode.MINI)
                showOrUpdateOverlay()
                updateNotification()
            }
            ACTION_RESTORE_PANEL, ACTION_START, ACTION_APPLY_SETTINGS, null -> {
                if (intent?.action == ACTION_RESTORE_PANEL) {
                    currentSettings = currentSettings.copy(visibilityMode = FloatingVisibilityMode.VISIBLE)
                }
                if (currentSettings.visibilityMode == FloatingVisibilityMode.HIDDEN_PANEL) {
                    removeOverlayView()
                } else {
                    showOrUpdateOverlay()
                }
                updateNotification()
            }
        }

        _state.value = FloatingOverlayState(
            running = true,
            visibilityMode = currentSettings.visibilityMode,
            overlayPermissionGranted = Settings.canDrawOverlays(this),
            statusText = when (currentSettings.visibilityMode) {
                FloatingVisibilityMode.VISIBLE -> "Floating Panel Active"
                FloatingVisibilityMode.MINI -> "Mini HUD Active"
                FloatingVisibilityMode.HIDDEN_PANEL -> "Hidden Panel Mode (Notification Active)"
            }
        )
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showOrUpdateOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            removeOverlayView()
            AppLogger.w(TAG, "Overlay permission not granted; running with notification controls only.")
            return
        }

        removeOverlayView()

        val density = resources.displayMetrics.density
        val settings = currentSettings
        val isMini = settings.visibilityMode == FloatingVisibilityMode.MINI
        val basePreset = if (isMini) FloatingSizePreset.SMALL else settings.sizePreset
        val widthPx = (basePreset.widthDp * density).toInt()
        val heightPx = ((basePreset.widthDp * (settings.aspectRatioH / settings.aspectRatioW.coerceAtLeast(1f))) * density)
            .toInt()
            .coerceIn((96 * density).toInt(), (360 * density).toInt())

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (10 * density).toInt()
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(Color.argb(228, 8, 14, 24))
                cornerRadius = settings.cornerRadiusDp * density
                setStroke((settings.borderThicknessDp * density).toInt().coerceAtLeast(2), settings.borderColorArgb.toInt())
            }
        }

        val title = TextView(this).apply {
            text = if (isMini) "ASIF AI • MINI" else "ASIF GESTURE HUD"
            setTextColor(Color.rgb(0, 255, 136))
            textSize = if (isMini) 10.5f else 12f
        }
        container.addView(title)

        val status = TextView(this).apply {
            val accState = AccessibilityBridge.status.value
            text = if (accState.connected) {
                if (accState.paused) "Controls Paused" else "Accessibility Ready"
            } else {
                "Enable Accessibility for taps"
            }
            setTextColor(Color.rgb(180, 210, 230))
            textSize = 10f
        }
        container.addView(status)

        if (!isMini && settings.showCompactControls) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, (8 * density).toInt(), 0, 0)
            }
            val hideBtn = Button(this).apply {
                text = "Hide"
                textSize = 10f
                setOnClickListener {
                    updateMode(this@FloatingControlService, FloatingVisibilityMode.HIDDEN_PANEL, currentSettings)
                }
            }
            val stopBtn = Button(this).apply {
                text = "STOP"
                textSize = 10f
                setTextColor(Color.rgb(255, 90, 110))
                setOnClickListener {
                    startService(Intent(this@FloatingControlService, FloatingControlService::class.java).apply {
                        action = ACTION_EMERGENCY_STOP
                    })
                }
            }
            row.addView(hideBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(stopBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            container.addView(row)
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            widthPx,
            if (isMini) WindowManager.LayoutParams.WRAP_CONTENT else heightPx,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    runCatching { windowManager?.updateViewLayout(container, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (currentSettings.edgeSnapEnabled) {
                        val screenW = resources.displayMetrics.widthPixels
                        params.x = if (params.x + widthPx / 2 < screenW / 2) 16 else (screenW - widthPx - 16).coerceAtLeast(16)
                        runCatching { windowManager?.updateViewLayout(container, params) }
                    }
                    if (abs(event.rawX - initialTouchX) < 10f && abs(event.rawY - initialTouchY) < 10f && isMini) {
                        updateMode(this@FloatingControlService, FloatingVisibilityMode.VISIBLE, currentSettings)
                    }
                    true
                }
                else -> false
            }
        }

        try {
            windowManager?.addView(container, params)
            overlayView = container
            layoutParams = params
        } catch (e: Exception) {
            AppLogger.e(TAG, "Failed to attach floating overlay view", e)
        }
    }

    private fun removeOverlayView() {
        overlayView?.let { view ->
            runCatching { windowManager?.removeViewImmediate(view) }
        }
        overlayView = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_floating),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_floating_desc)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm?.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val restoreIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingControlService::class.java).apply { action = ACTION_RESTORE_PANEL },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 2,
            Intent(this, FloatingControlService::class.java).apply { action = ACTION_EMERGENCY_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val modeText = when (currentSettings.visibilityMode) {
            FloatingVisibilityMode.VISIBLE -> "Floating panel visible"
            FloatingVisibilityMode.MINI -> "Mini floating HUD active"
            FloatingVisibilityMode.HIDDEN_PANEL -> "Hidden Panel Mode — controls active where permitted"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("ASIF GESTURE AI")
            .setContentText(modeText)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(0, "Restore Panel", restoreIntent)
            .addAction(0, "STOP", stopIntent)
            .build()
    }

    override fun onDestroy() {
        serviceScope.cancel()
        removeOverlayView()
        removePointerView()
        _state.value = FloatingOverlayState(running = false, statusText = "Stopped")
        super.onDestroy()
    }
}
