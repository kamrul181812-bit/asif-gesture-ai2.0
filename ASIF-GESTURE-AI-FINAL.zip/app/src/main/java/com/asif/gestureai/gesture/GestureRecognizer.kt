package com.asif.gestureai.gesture

import com.asif.gestureai.face.FacePoint
import com.asif.gestureai.settings.GestureSettings
import com.asif.gestureai.settings.GestureType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.hypot

data class RecognizedGestureEvent(
    val gesture: GestureType,
    val confidence: Float,
    val timestampMs: Long
)

data class GestureLiveState(
    val detectedGesture: GestureType? = null,
    val confidence: Float = 0f,
    val pointerX: Float = 0.5f,
    val pointerY: Float = 0.5f,
    val isPinching: Boolean = false,
    val handPresent: Boolean = false,
    val twoHandsPresent: Boolean = false,
    val triggeredEvent: RecognizedGestureEvent? = null
)

/**
 * Classifies 11 hand gestures from 21-landmark MediaPipe hand coordinates with
 * temporal stability, activation delay, confidence threshold, and per-gesture cooldown.
 */
class GestureRecognizer {

    private val _liveState = MutableStateFlow(GestureLiveState())
    val liveState: StateFlow<GestureLiveState> = _liveState.asStateFlow()

    private val recentSamples = ArrayDeque<Pair<Long, FacePoint>>(16)
    private var prevPinchDist: Float? = null
    private var lastLateralDirection = 0
    private var lateralFlipCount = 0
    private var lastWaveWindowStart = 0L

    private var candidateGesture: GestureType? = null
    private var candidateStartMs: Long = 0L
    private val lastTriggeredMap = mutableMapOf<GestureType, Long>()

    private var smoothPointerX = 0.5f
    private var smoothPointerY = 0.5f

    fun process(
        trackingResult: HandTrackingResult,
        settings: GestureSettings,
        nowMs: Long
    ): GestureLiveState {
        val hands = trackingResult.hands
        if (hands.isEmpty()) {
            prevPinchDist = null
            candidateGesture = null
            val empty = GestureLiveState(
                pointerX = smoothPointerX,
                pointerY = smoothPointerY,
                handPresent = false
            )
            _liveState.value = empty
            return empty
        }

        val primary = hands.first()
        val pts = primary.landmarks
        if (pts.size < 21) return _liveState.value

        // Smooth pointer from index fingertip (#8)
        val indexTip = pts[8]
        val pointerAlpha = 0.35f
        smoothPointerX += (indexTip.x - smoothPointerX) * pointerAlpha
        smoothPointerY += (indexTip.y - smoothPointerY) * pointerAlpha

        // Record trajectory of wrist (#0) for swipe/wave kinematics
        val wrist = pts[0]
        recentSamples.addLast(nowMs to wrist)
        while (recentSamples.size > 12 || (recentSamples.isNotEmpty() && nowMs - recentSamples.first().first > 550L)) {
            recentSamples.removeFirst()
        }

        val classified = classifySingleOrDual(hands, settings, nowMs)
        val rawGesture = classified?.first
        val rawConf = classified?.second ?: 0f

        var triggered: RecognizedGestureEvent? = null
        if (rawGesture != null &&
            rawConf >= settings.confidenceThreshold &&
            (settings.enabledGestures[rawGesture.name] ?: true) &&
            settings.enabled
        ) {
            if (candidateGesture != rawGesture) {
                candidateGesture = rawGesture
                candidateStartMs = nowMs
            } else if (nowMs - candidateStartMs >= settings.activationDelayMs) {
                val lastTrig = lastTriggeredMap[rawGesture] ?: 0L
                // Swipe and wave are instantaneous kinematic events; static poses obey cooldown
                if (nowMs - lastTrig >= settings.cooldownMs) {
                    lastTriggeredMap[rawGesture] = nowMs
                    triggered = RecognizedGestureEvent(rawGesture, rawConf, nowMs)
                }
            }
        } else {
            candidateGesture = null
        }

        val pinchDist = dist(pts[4], pts[8])
        val isPinching = pinchDist < (0.045f + (1f - settings.sensitivity) * 0.025f)

        val state = GestureLiveState(
            detectedGesture = rawGesture,
            confidence = rawConf,
            pointerX = smoothPointerX,
            pointerY = smoothPointerY,
            isPinching = isPinching,
            handPresent = true,
            twoHandsPresent = hands.size >= 2,
            triggeredEvent = triggered
        )
        _liveState.value = state
        return state
    }

    private fun classifySingleOrDual(
        hands: List<TrackedHand>,
        settings: GestureSettings,
        nowMs: Long
    ): Pair<GestureType, Float>? {
        val hand = hands.first()
        val pts = hand.landmarks
        val handScale = dist(pts[0], pts[9]).coerceAtLeast(0.06f)

        // Two-hand check
        if (hands.size >= 2) {
            val h2 = hands[1]
            if (h2.landmarks.size >= 21) {
                val twoHandConf = ((hand.confidence + h2.confidence) * 0.5f).coerceIn(0f, 0.98f)
                return GestureType.TWO_HAND to twoHandConf
            }
        }

        val thumbTip = pts[4]
        val thumbIp = pts[3]
        val indexUp = pts[8].y < pts[6].y - handScale * 0.12f
        val middleUp = pts[12].y < pts[10].y - handScale * 0.12f
        val ringUp = pts[16].y < pts[14].y - handScale * 0.10f
        val pinkyUp = pts[20].y < pts[18].y - handScale * 0.10f
        val thumbUp = thumbTip.y < thumbIp.y - handScale * 0.15f && thumbTip.y < pts[5].y

        val pinchNorm = dist(thumbTip, pts[8]) / handScale
        val prevPinch = prevPinchDist
        prevPinchDist = pinchNorm

        // 1. Pinch Spread (rapid expansion from pinch)
        if (prevPinch != null && prevPinch < 0.35f && pinchNorm - prevPinch > 0.25f) {
            return GestureType.PINCH_SPREAD to 0.88f
        }

        // 2. Kinematic Swipe Up / Swipe Down
        if (recentSamples.size >= 4) {
            val oldest = recentSamples.first()
            val newest = recentSamples.last()
            val dt = (newest.first - oldest.first).coerceAtLeast(1L)
            val dy = newest.second.y - oldest.second.y
            val dx = newest.second.x - oldest.second.x
            val swipeThreshold = 0.22f - settings.sensitivity * 0.08f
            if (dt in 80L..520L && abs(dy) > swipeThreshold && abs(dy) > abs(dx) * 1.4f) {
                return if (dy < 0f) {
                    GestureType.SWIPE_UP to 0.90f
                } else {
                    GestureType.SWIPE_DOWN to 0.90f
                }
            }

            // 3. Hand Wave (lateral oscillation when palm open)
            if (indexUp && middleUp && ringUp && pinkyUp && recentSamples.size >= 2) {
                val prevSample = recentSamples[recentSamples.size - 2]
                val stepDx = newest.second.x - prevSample.second.x
                val dir = when {
                    stepDx > 0.025f -> 1
                    stepDx < -0.025f -> -1
                    else -> 0
                }
                if (dir != 0 && dir != lastLateralDirection) {
                    if (nowMs - lastWaveWindowStart > 1100L) {
                        lastWaveWindowStart = nowMs
                        lateralFlipCount = 0
                    }
                    lastLateralDirection = dir
                    lateralFlipCount++
                    if (lateralFlipCount >= 3) {
                        lateralFlipCount = 0
                        return GestureType.HAND_WAVE to 0.87f
                    }
                }
            }
        }

        // 4. Pinch
        if (pinchNorm < 0.34f + (settings.sensitivity * 0.08f)) {
            return GestureType.PINCH to (0.93f * hand.confidence).coerceIn(0.6f, 0.98f)
        }

        // 5. Open Palm (4+ fingers extended)
        if (indexUp && middleUp && ringUp && pinkyUp) {
            return GestureType.OPEN_PALM to (0.92f * hand.confidence).coerceIn(0.6f, 0.98f)
        }

        // 6. Two-Finger (Peace)
        if (indexUp && middleUp && !ringUp && !pinkyUp) {
            return GestureType.TWO_FINGER to (0.90f * hand.confidence).coerceIn(0.6f, 0.97f)
        }

        // 7. Index Finger Pointing
        if (indexUp && !middleUp && !ringUp && !pinkyUp) {
            return GestureType.INDEX_POINT to (0.91f * hand.confidence).coerceIn(0.6f, 0.97f)
        }

        // 8. Thumbs Up
        if (thumbUp && !indexUp && !middleUp && !ringUp && !pinkyUp) {
            return GestureType.THUMBS_UP to (0.89f * hand.confidence).coerceIn(0.6f, 0.96f)
        }

        // 9. Closed Fist
        if (!indexUp && !middleUp && !ringUp && !pinkyUp && !thumbUp) {
            return GestureType.CLOSED_FIST to (0.88f * hand.confidence).coerceIn(0.6f, 0.95f)
        }

        return null
    }

    private fun dist(a: FacePoint, b: FacePoint): Float {
        return hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat()
    }

    fun reset() {
        recentSamples.clear()
        prevPinchDist = null
        candidateGesture = null
        _liveState.value = GestureLiveState()
    }
}
