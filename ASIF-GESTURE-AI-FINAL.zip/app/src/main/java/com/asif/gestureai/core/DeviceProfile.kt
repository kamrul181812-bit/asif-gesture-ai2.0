package com.asif.gestureai.core

import android.os.Build

/**
 * Hardware optimization profile tuned specifically for Symphony Inova 30:
 * - Android 13 (API 33)
 * - 6 GB RAM
 * - 2.0 GHz Octa-Core CPU
 * - ARM Mali-G57 @ 750 MHz GPU
 * - Standard smartphone front camera
 */
object DeviceProfile {
    const val TARGET_DEVICE_NAME = "Symphony Inova 30"
    const val TARGET_OS_LABEL = "Android 13 (API 33)"
    const val TARGET_RAM_GB = 6
    const val TARGET_SOC_LABEL = "2.0 GHz Octa-Core • Mali-G57"

    // Safe memory & frame defaults for 6GB RAM mid-range SoC
    const val LOW_AVAILABLE_RAM_MB = 650L
    const val CRITICAL_AVAILABLE_RAM_MB = 350L
    const val DEFAULT_MAX_WIDTH = 480
    const val DEFAULT_MAX_HEIGHT = 360

    fun currentDeviceLabel(): String = "${Build.MANUFACTURER.uppercase()} ${Build.MODEL} (API ${Build.VERSION.SDK_INT})"

    fun supportsThermalApi(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    fun requiresNotificationRuntimePermission(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    fun supportsPip(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
}
