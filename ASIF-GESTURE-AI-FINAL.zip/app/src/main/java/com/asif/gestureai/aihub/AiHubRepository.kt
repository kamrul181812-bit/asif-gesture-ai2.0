package com.asif.gestureai.aihub

import com.asif.gestureai.data.local.AiProviderDao
import com.asif.gestureai.data.local.AiProviderEntity
import com.asif.gestureai.data.local.ChatDao
import com.asif.gestureai.data.local.ChatMessageEntity
import com.asif.gestureai.data.local.ChatSessionEntity
import com.asif.gestureai.security.CredentialCipher
import kotlinx.coroutines.flow.Flow

class AiHubRepository(
    private val providerDao: AiProviderDao,
    private val chatDao: ChatDao,
    private val cipher: CredentialCipher,
    val client: AiHubClient
) {
    val providers: Flow<List<AiProviderEntity>> = providerDao.observeProviders()
    val sessions: Flow<List<ChatSessionEntity>> = chatDao.observeSessions()

    fun observeMessages(sessionId: Long): Flow<List<ChatMessageEntity>> =
        chatDao.observeMessages(sessionId)

    suspend fun saveVerifiedProvider(
        existingId: Long,
        name: String,
        adapterType: AiAdapterType,
        baseUrl: String,
        chatEndpointPath: String,
        modelName: String,
        plainApiKey: String,
        customHeadersJson: String,
        temperature: Float,
        maxContextMessages: Int,
        isVerified: Boolean,
        statusMessage: String
    ): Long {
        val encrypted = if (plainApiKey.isNotBlank()) {
            cipher.encrypt(plainApiKey.trim())
        } else if (existingId > 0L) {
            providerDao.getById(existingId)?.encryptedApiKey.orEmpty()
        } else {
            ""
        }

        val entity = AiProviderEntity(
            id = existingId,
            name = name.trim().ifBlank { adapterType.displayName },
            adapterType = adapterType.name,
            baseUrl = baseUrl.trim().trimEnd('/'),
            chatEndpointPath = chatEndpointPath.trim().ifBlank { adapterType.defaultChatPath },
            modelName = modelName.trim().ifBlank { adapterType.defaultModel },
            encryptedApiKey = encrypted,
            customHeadersJson = customHeadersJson.trim().ifBlank { "{}" },
            temperature = temperature,
            maxContextMessages = maxContextMessages,
            isVerified = isVerified,
            lastStatusMessage = statusMessage,
            updatedAt = System.currentTimeMillis()
        )
        return providerDao.upsert(entity)
    }

    suspend fun deleteProvider(id: Long) = providerDao.deleteById(id)

    suspend fun deleteProviderKeyOnly(id: Long) {
        val current = providerDao.getById(id) ?: return
        providerDao.upsert(
            current.copy(
                encryptedApiKey = "",
                isVerified = false,
                lastStatusMessage = "API key deleted by user",
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    fun decryptApiKey(provider: AiProviderEntity): String =
        cipher.decrypt(provider.encryptedApiKey)

    suspend fun createSession(title: String, provider: AiProviderEntity): Long {
        return chatDao.insertSession(
            ChatSessionEntity(
                title = title,
                providerId = provider.id,
                modelName = provider.modelName
            )
        )
    }

    suspend fun renameSession(sessionId: Long, newTitle: String) {
        chatDao.renameSession(sessionId, newTitle.trim().ifBlank { "AI Chat" })
    }

    suspend fun deleteSession(sessionId: Long) {
        chatDao.clearMessagesForSession(sessionId)
        chatDao.deleteSession(sessionId)
    }

    suspend fun clearSessionMessages(sessionId: Long) {
        chatDao.clearMessagesForSession(sessionId)
    }

    suspend fun appendMessage(sessionId: Long, role: String, content: String): Long {
        return chatDao.insertMessage(
            ChatMessageEntity(
                sessionId = sessionId,
                role = role,
                content = content
            )
        )
    }

    suspend fun deleteMessage(messageId: Long) = chatDao.deleteMessage(messageId)

    suspend fun getContextDrafts(sessionId: Long, maxMessages: Int): List<AiChatDraftMessage> {
        val history = chatDao.getMessagesOnce(sessionId)
        return history.takeLast(maxMessages.coerceIn(2, 30))
            .map { AiChatDraftMessage(role = it.role, content = it.content) }
    }

    suspend fun wipeAllCredentialsAndChats() {
        providerDao.deleteAll()
        chatDao.deleteAllMessages()
        chatDao.deleteAllSessions()
        cipher.clearKey()
    }
}
