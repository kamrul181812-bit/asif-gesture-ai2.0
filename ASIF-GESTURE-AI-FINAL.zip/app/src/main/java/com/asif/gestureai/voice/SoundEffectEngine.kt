package com.asif.gestureai.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import com.asif.gestureai.core.AppLogger
import com.asif.gestureai.settings.VoiceAndSoundSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class SoundCue(val freqHz: Double, val durationMs: Int, val secondaryFreqHz: Double = 0.0) {
    BUTTON(720.0, 45),
    GESTURE(880.0, 75, 1180.0),
    CLICK(1050.0, 35),
    CAMERA_ON(520.0, 120, 780.0),
    MODE_SWITCH(640.0, 90, 960.0),
    NOTIFICATION(760.0, 110, 1020.0),
    EMERGENCY_STOP(340.0, 180, 220.0)
}

/**
 * Original synthesized cyber-UI tone generator using AudioTrack + optional Android TextToSpeech feedback.
 * Zero external copyrighted sound files required; rate-limited to prevent audio spam.
 */
class SoundEffectEngine(context: Context) {

    companion object {
        private const val TAG = "SoundEffectEngine"
        private const val SAMPLE_RATE = 22050
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var lastCueTimestamp = 0L

    init {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                ttsReady = (status == TextToSpeech.SUCCESS)
                if (ttsReady) {
                    tts?.language = Locale.US
                }
            }
        } catch (e: Exception) {
            AppLogger.w(TAG, "TextToSpeech unavailable", e)
        }
    }

    fun playCue(cue: SoundCue, settings: VoiceAndSoundSettings) {
        if (!settings.soundEffectsEnabled) return
        val allowed = when (cue) {
            SoundCue.BUTTON -> settings.buttonSoundEnabled
            SoundCue.GESTURE -> settings.gestureSoundEnabled
            SoundCue.CLICK -> settings.clickSoundEnabled
            SoundCue.CAMERA_ON -> settings.cameraSoundEnabled
            SoundCue.MODE_SWITCH -> settings.modeSwitchSoundEnabled
            SoundCue.NOTIFICATION, SoundCue.EMERGENCY_STOP -> true
        }
        if (!allowed) return

        val now = System.currentTimeMillis()
        if (cue != SoundCue.EMERGENCY_STOP && now - lastCueTimestamp < 85L) return
        lastCueTimestamp = now

        val volume = settings.masterVolume.coerceIn(0.05f, 1.0f)
        scope.launch {
            playSynthesizedTone(cue, volume)
        }
    }

    fun speakFeedback(message: String, settings: VoiceAndSoundSettings) {
        if (!settings.voiceFeedbackEnabled || !ttsReady) return
        runCatching {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "asif_cue_${System.currentTimeMillis()}")
        }
    }

    private fun playSynthesizedTone(cue: SoundCue, volume: Float) {
        val sampleCount = (SAMPLE_RATE * (cue.durationMs / 1000.0)).toInt().coerceAtLeast(256)
        val pcm = ShortArray(sampleCount)
        val half = sampleCount / 2

        for (i in 0 until sampleCount) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = if (cue.secondaryFreqHz > 0.0 && i > half) cue.secondaryFreqHz else cue.freqHz
            val envelope = exp(-4.5 * (i.toDouble() / sampleCount))
            val wave = sin(2.0 * PI * freq * t) * envelope * volume * Short.MAX_VALUE * 0.45
            pcm[i] = wave.toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }

        var track: AudioTrack? = null
        try {
            val minBuf = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(minBuf, pcm.size * 2))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(pcm, 0, pcm.size)
            track.play()
            Thread.sleep(cue.durationMs.toLong() + 25L)
        } catch (t: Throwable) {
            AppLogger.w(TAG, "AudioTrack playback skipped", t)
        } finally {
            runCatching { track?.release() }
        }
    }

    fun release() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
    }
}
