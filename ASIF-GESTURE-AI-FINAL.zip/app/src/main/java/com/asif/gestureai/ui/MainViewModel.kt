package com.asif.gestureai.ui

import android.app.Application
import android.graphics.Bitmap
import android.os.SystemClock
import androidx.camera.view.PreviewView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewModelScope
import com.asif.gestureai.accessibility.AccessibilityBridge
import com.asif.gestureai.accessibility.AccessibilityStatus
import com.asif.gestureai.aihub.AiAdapterType
import com.asif.gestureai.aihub.AiHubClient
import com.asif.gestureai.aihub.AiHubRepository
import com.asif.gestureai.aihub.AiSetupValidationResult
import com.asif.gestureai.camera.CameraController
import com.asif.gestureai.camera.CameraStatus
import com.asif.gestureai.core.PermissionHelper
import com.asif.gestureai.core.PermissionStatusSnapshot
import com.asif.gestureai.data.AppPreferencesDataStore
import com.asif.gestureai.data.local.AiProviderEntity
import com.asif.gestureai.data.local.AppDatabase
import com.asif.gestureai.data.local.ChatMessageEntity
import com.asif.gestureai.data.local.ChatSessionEntity
import com.asif.gestureai.data.local.CustomMaskEntity
import com.asif.gestureai.data.local.GestureHistoryEntity
import com.asif.gestureai.eye.EyeTrackingEngine
import com.asif.gestureai.eye.EyeTrackingState
import com.asif.gestureai.face.FaceLandmarkerEngine
import com.asif.gestureai.face.FaceTrackingResult
import com.asif.gestureai.gesture.GestureLiveState
import com.asif.gestureai.gesture.GestureRecognizer
import com.asif.gestureai.gesture.HandLandmarkerEngine
import com.asif.gestureai.gesture.HandTrackingResult
import com.asif.gestureai.performance.AdaptivePerformanceEngine
import com.asif.gestureai.performance.PerformanceMode
import com.asif.gestureai.performance.PerformanceTelemetry
import com.asif.gestureai.reels.ReelsModeController
import com.asif.gestureai.reels.ReelsRuntimeState
import com.asif.gestureai.security.KeystoreCryptoManager
import com.asif.gestureai.service.FloatingControlService
import com.asif.gestureai.service.FloatingOverlayState
import com.asif.gestureai.settings.AllAppSettings
import com.asif.gestureai.settings.CameraLensOption
import com.asif.gestureai.settings.FloatingVisibilityMode
import com.asif.gestureai.settings.GestureAction
import com.asif.gestureai.settings.GestureType
import com.asif.gestureai.virtualmouse.VirtualMouseController
import com.asif.gestureai.virtualmouse.VirtualMouseState
import com.asif.gestureai.voice.SoundCue
import com.asif.gestureai.voice.SoundEffectEngine
import com.asif.gestureai.voice.VoiceCommandIntent
import com.asif.gestureai.voice.VoiceControlManager
import com.asif.gestureai.voice.VoiceStatusState
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

sealed interface AppEvent {
    data class ToastMessage(val text: String) : AppEvent
    data object NavigateToAiHub : AppEvent
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    val preferences = AppPreferencesDataStore(context)
    private val database = AppDatabase.getInstance(context)
    private val cipher = KeystoreCryptoManager()
    val aiRepository = AiHubRepository(
        providerDao = database.aiProviderDao(),
        chatDao = database.chatDao(),
        cipher = cipher,
        client = AiHubClient()
    )

    val performanceEngine = AdaptivePerformanceEngine(context)
    val cameraController = CameraController(context, performanceEngine)
    val faceEngine = FaceLandmarkerEngine(context)
    val handEngine = HandLandmarkerEngine(context)
    val gestureRecognizer = GestureRecognizer()
    val eyeEngine = EyeTrackingEngine()
    val virtualMouseController = VirtualMouseController()
    val reelsController = ReelsModeController()
    val soundEngine = SoundEffectEngine(context)
    val voiceManager = VoiceControlManager(context)

    val settings: StateFlow<AllAppSettings> = preferences.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AllAppSettings())

    val performanceTelemetry: StateFlow<PerformanceTelemetry> = performanceEngine.telemetry
    val cameraStatus: StateFlow<CameraStatus> = cameraController.status
    val faceResult: StateFlow<FaceTrackingResult> = faceEngine.latestResult
    val handResult: StateFlow<HandTrackingResult> = handEngine.latestResult
    val gestureLiveState: StateFlow<GestureLiveState> = gestureRecognizer.liveState
    val eyeState: StateFlow<EyeTrackingState> = eyeEngine.state
    val mouseState: StateFlow<VirtualMouseState> = virtualMouseController.mouseState
    val reelsState: StateFlow<ReelsRuntimeState> = reelsController.state
    val accessibilityStatus: StateFlow<AccessibilityStatus> = AccessibilityBridge.status
    val floatingState: StateFlow<FloatingOverlayState> = FloatingControlService.state
    val voiceStatus: StateFlow<VoiceStatusState> = voiceManager.status

    val providers: StateFlow<List<AiProviderEntity>> = aiRepository.providers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatSessions: StateFlow<List<ChatSessionEntity>> = aiRepository.sessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val gestureHistory: StateFlow<List<GestureHistoryEntity>> = database.gestureHistoryDao().observeRecent()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customMasks: StateFlow<List<CustomMaskEntity>> = database.customMaskDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedSessionId = MutableStateFlow<Long?>(null)
    val selectedSessionId: StateFlow<Long?> = _selectedSessionId.asStateFlow()

    @Suppress("OPT_IN_USAGE")
    val activeMessages: StateFlow<List<ChatMessageEntity>> = _selectedSessionId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else aiRepository.observeMessages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _permissions = MutableStateFlow(PermissionHelper.snapshot(context))
    val permissions: StateFlow<PermissionStatusSnapshot> = _permissions.asStateFlow()

    private val _streamingAssistantText = MutableStateFlow<String?>(null)
    val streamingAssistantText: StateFlow<String?> = _streamingAssistantText.asStateFlow()

    private val _isGeneratingChat = MutableStateFlow(false)
    val isGeneratingChat: StateFlow<Boolean> = _isGeneratingChat.asStateFlow()

    private val _setupValidation = MutableStateFlow<AiSetupValidationResult?>(null)
    val setupValidation: StateFlow<AiSetupValidationResult?> = _setupValidation.asStateFlow()

    private val _isTestingApi = MutableStateFlow(false)
    val isTestingApi: StateFlow<Boolean> = _isTestingApi.asStateFlow()

    private val _events = MutableSharedFlow<AppEvent>(extraBufferCapacity = 8)
    val events = _events.asSharedFlow()

    private var lastFaceInferMs = 0L
    private var lastHandInferMs = 0L
    private var activeChatJob: Job? = null

    init {
        performanceEngine.startMonitoring()
        setupCameraPipeline()
        setupVoiceHandler()
        viewModelScope.launch {
            preferences.settingsFlow.collect { s ->
                performanceEngine.setMode(s.performance.mode)
                performanceEngine.setAdaptiveEnabled(s.performance.adaptiveEnabled)
                performanceEngine.setThermalMonitoringEnabled(s.performance.thermalMonitoringEnabled)
                cameraController.updateRuntimeSettings(s.camera)
                reelsController.setActive(s.reels.active)
                if (floatingState.value.running) {
                    FloatingControlService.currentSettings = s.floating
                }
            }
        }
    }

    fun refreshPermissions() {
        _permissions.value = PermissionHelper.snapshot(context)
    }

    private fun setupCameraPipeline() {
        cameraController.setFrameCallback { bitmap, rotationDegrees, isFrontCamera, timestampMs, avgLuminance ->
            analyzeCameraFrame(bitmap, rotationDegrees, isFrontCamera, timestampMs, avgLuminance)
        }
    }

    private fun analyzeCameraFrame(
        bitmap: Bitmap,
        rotationDegrees: Int,
        isFrontCamera: Boolean,
        timestampMs: Long,
        avgLuminance: Float
    ) {
        val s = settings.value
        val needsFace = s.mask.enabled || s.eyeTracking.enabled
        val needsHand = s.gesture.enabled || s.virtualMouse.enabled || s.reels.active

        if (needsFace && timestampMs - lastFaceInferMs >= performanceEngine.effectiveFaceIntervalMs()) {
            lastFaceInferMs = timestampMs
            val face = faceEngine.processFrame(bitmap, rotationDegrees, isFrontCamera, timestampMs)
            performanceEngine.recordFaceLatency(face.inferenceTimeMs)

            if (s.eyeTracking.enabled) {
                val eye = eyeEngine.update(face, avgLuminance, s.eyeTracking, timestampMs)
                if (s.reels.active) {
                    val actionMsg = reelsController.handleEyeGaze(eye, s.reels, timestampMs)
                    if (actionMsg != null) {
                        soundEngine.playCue(SoundCue.GESTURE, s.voiceSound)
                    }
                }
            }
        } else if (!needsFace) {
            faceEngine.clearResult()
            eyeEngine.reset()
        }

        val pauseHandsForThermal = performanceEngine.telemetry.value.pauseOptionalAi && !s.reels.active
        if (needsHand && !pauseHandsForThermal && timestampMs - lastHandInferMs >= performanceEngine.effectiveHandIntervalMs()) {
            lastHandInferMs = timestampMs
            val hand = handEngine.processFrame(
                bitmap = bitmap,
                rotationDegrees = rotationDegrees,
                isFrontCamera = isFrontCamera,
                timestampMs = timestampMs,
                maxHandsLimit = s.performance.mode.maxHands
            )
            performanceEngine.recordHandLatency(hand.inferenceTimeMs)

            val gestureState = gestureRecognizer.process(hand, s.gesture, timestampMs)
            val dm = context.resources.displayMetrics
            virtualMouseController.updateFromGesture(
                gestureState = gestureState,
                settings = s.virtualMouse,
                screenWidthPx = dm.widthPixels,
                screenHeightPx = dm.heightPixels,
                nowMs = timestampMs
            )
            FloatingControlService.updatePointerState(virtualMouseController.mouseState.value, s.virtualMouse)

            gestureState.triggeredEvent?.let { evt ->
                soundEngine.playCue(SoundCue.GESTURE, s.voiceSound)
                if (s.reels.active) {
                    reelsController.handleGesture(evt, s.reels, dm.widthPixels, dm.heightPixels)
                } else {
                    dispatchConfiguredGestureAction(evt.gesture, evt.confidence)
                }
            }
        } else if (!needsHand) {
            handEngine.clearResult()
            gestureRecognizer.reset()
        }
    }

    private fun dispatchConfiguredGestureAction(gesture: GestureType, confidence: Float) {
        val s = settings.value
        val actionName = s.gesture.actionMappings[gesture.name] ?: GestureAction.NONE.name
        val action = runCatching { GestureAction.valueOf(actionName) }.getOrDefault(GestureAction.NONE)

        viewModelScope.launch {
            database.gestureHistoryDao().insert(
                GestureHistoryEntity(
                    gestureName = gesture.displayName,
                    actionName = action.displayName,
                    confidence = confidence
                )
            )
        }

        when (action) {
            GestureAction.NONE -> Unit
            GestureAction.VIRTUAL_CLICK -> {
                val dm = context.resources.displayMetrics
                val ms = mouseState.value
                AccessibilityBridge.performTap(ms.normX * dm.widthPixels, ms.normY * dm.heightPixels)
            }
            GestureAction.VIRTUAL_DOUBLE_CLICK -> {
                val dm = context.resources.displayMetrics
                val ms = mouseState.value
                AccessibilityBridge.performDoubleTap(ms.normX * dm.widthPixels, ms.normY * dm.heightPixels)
            }
            GestureAction.SCROLL_UP -> AccessibilityBridge.performScroll(scrollDown = false)
            GestureAction.SCROLL_DOWN -> AccessibilityBridge.performScroll(scrollDown = true)
            GestureAction.GLOBAL_BACK -> AccessibilityBridge.performGlobalBack()
            GestureAction.GLOBAL_HOME -> AccessibilityBridge.performGlobalHome()
            GestureAction.GLOBAL_RECENTS -> AccessibilityBridge.performGlobalRecents()
            GestureAction.PAUSE_RESUME_TRACKING -> AccessibilityBridge.setPaused(!accessibilityStatus.value.paused)
            GestureAction.TOGGLE_MASK -> toggleMask(!s.mask.enabled)
            GestureAction.OPEN_AI_HUB -> _events.tryEmit(AppEvent.NavigateToAiHub)
            else -> Unit
        }
    }

    fun startCamera(lifecycleOwner: LifecycleOwner, previewView: PreviewView?) {
        refreshPermissions()
        cameraController.startCamera(lifecycleOwner, previewView, settings.value.camera)
        soundEngine.playCue(SoundCue.CAMERA_ON, settings.value.voiceSound)
    }

    fun reattachCameraPreview(lifecycleOwner: LifecycleOwner, previewView: PreviewView?) {
        cameraController.reattachPreviewIfRunning(lifecycleOwner, previewView)
    }

    fun stopCamera() {
        cameraController.stopCamera()
    }

    fun switchCameraLens(lifecycleOwner: LifecycleOwner, previewView: PreviewView?) {
        viewModelScope.launch {
            val nextLens = if (settings.value.camera.lens == CameraLensOption.FRONT) {
                CameraLensOption.REAR
            } else {
                CameraLensOption.FRONT
            }
            preferences.updateCamera { it.copy(lens = nextLens) }
            soundEngine.playCue(SoundCue.MODE_SWITCH, settings.value.voiceSound)
            cameraController.startCamera(lifecycleOwner, previewView, settings.value.camera.copy(lens = nextLens))
        }
    }

    fun toggleMask(enabled: Boolean) {
        viewModelScope.launch {
            preferences.updateMask { it.copy(enabled = enabled) }
            soundEngine.playCue(SoundCue.MODE_SWITCH, settings.value.voiceSound)
        }
    }

    fun saveCustomMaskPreset(name: String) {
        viewModelScope.launch {
            val encoded = json.encodeToString(
                com.asif.gestureai.settings.MaskSettings.serializer(),
                settings.value.mask
            )
            database.customMaskDao().insert(
                CustomMaskEntity(
                    name = name.trim().ifBlank { "Custom Cyber Mask" },
                    maskJson = encoded
                )
            )
            _events.tryEmit(AppEvent.ToastMessage("Mask preset saved locally."))
        }
    }

    fun applySavedMask(entity: CustomMaskEntity) {
        viewModelScope.launch {
            runCatching {
                json.decodeFromString(com.asif.gestureai.settings.MaskSettings.serializer(), entity.maskJson)
            }.onSuccess { loaded ->
                preferences.updateMask { loaded.copy(enabled = true) }
            }
        }
    }

    fun setPerformanceMode(mode: PerformanceMode) {
        viewModelScope.launch {
            preferences.updatePerformance { it.copy(mode = mode) }
            preferences.updateCamera {
                it.copy(
                    targetFps = mode.targetFps,
                    resolutionTier = when (mode) {
                        PerformanceMode.BATTERY_SAVER -> com.asif.gestureai.settings.ResolutionTier.LOW_320
                        PerformanceMode.BALANCED -> com.asif.gestureai.settings.ResolutionTier.MID_480
                        PerformanceMode.PERFORMANCE -> com.asif.gestureai.settings.ResolutionTier.HIGH_640
                    }
                )
            }
            soundEngine.playCue(SoundCue.MODE_SWITCH, settings.value.voiceSound)
        }
    }

    fun calibrateEyeCenter() {
        val current = eyeState.value
        if (!current.detected) {
            _events.tryEmit(AppEvent.ToastMessage("Look at the camera first so iris landmarks are detected."))
            return
        }
        viewModelScope.launch {
            preferences.updateEyeTracking {
                it.copy(
                    centerOffsetX = current.gazeX,
                    centerOffsetY = current.gazeY,
                    isCalibrated = true
                )
            }
            soundEngine.playCue(SoundCue.BUTTON, settings.value.voiceSound)
            _events.tryEmit(AppEvent.ToastMessage("Eye center calibrated successfully."))
        }
    }

    fun calibrateGestureBaseline() {
        val hands = handResult.value.hands
        if (hands.isEmpty()) {
            _events.tryEmit(AppEvent.ToastMessage("Show your open hand to the camera to calibrate gesture sensitivity."))
            return
        }
        val avgConf = hands.first().confidence.coerceIn(0.45f, 0.9f)
        viewModelScope.launch {
            preferences.updateGesture {
                it.copy(
                    confidenceThreshold = (avgConf - 0.12f).coerceIn(0.50f, 0.80f),
                    sensitivity = 0.72f
                )
            }
            soundEngine.playCue(SoundCue.BUTTON, settings.value.voiceSound)
            _events.tryEmit(AppEvent.ToastMessage("Gesture baseline calibrated for current lighting & distance."))
        }
    }

    fun toggleReelsMode(active: Boolean) {
        viewModelScope.launch {
            preferences.updateReels { it.copy(active = active) }
            soundEngine.playCue(SoundCue.MODE_SWITCH, settings.value.voiceSound)
            soundEngine.speakFeedback(
                if (active) "Asif Reels Mode activated" else "Reels Mode stopped",
                settings.value.voiceSound
            )
        }
    }

    fun startFloatingMode(mode: FloatingVisibilityMode) {
        viewModelScope.launch {
            preferences.updateFloating { it.copy(visibilityMode = mode) }
            FloatingControlService.start(context, settings.value.floating.copy(visibilityMode = mode))
            soundEngine.playCue(SoundCue.MODE_SWITCH, settings.value.voiceSound)
        }
    }

    fun emergencyStopAll() {
        cameraController.stopCamera()
        AccessibilityBridge.emergencyStop()
        FloatingControlService.stop(context)
        voiceManager.stopListening()
        viewModelScope.launch {
            preferences.updateReels { it.copy(active = false) }
            preferences.updateVirtualMouse { it.copy(enabled = false) }
        }
        soundEngine.playCue(SoundCue.EMERGENCY_STOP, settings.value.voiceSound)
        _events.tryEmit(AppEvent.ToastMessage("All active services & controls stopped."))
    }

    private fun setupVoiceHandler() {
        voiceManager.setCommandListener { cmd ->
            val vs = settings.value.voiceSound
            when (cmd.intent) {
                VoiceCommandIntent.STOP_CAMERA -> {
                    stopCamera()
                    soundEngine.speakFeedback("Camera stopped", vs)
                }
                VoiceCommandIntent.ENABLE_MASK -> {
                    toggleMask(true)
                    soundEngine.speakFeedback("Mask enabled", vs)
                }
                VoiceCommandIntent.DISABLE_MASK -> {
                    toggleMask(false)
                    soundEngine.speakFeedback("Mask disabled", vs)
                }
                VoiceCommandIntent.ENABLE_GESTURES -> viewModelScope.launch {
                    preferences.updateGesture { it.copy(enabled = true) }
                    soundEngine.speakFeedback("Gestures enabled", vs)
                }
                VoiceCommandIntent.DISABLE_GESTURES -> viewModelScope.launch {
                    preferences.updateGesture { it.copy(enabled = false) }
                    soundEngine.speakFeedback("Gestures disabled", vs)
                }
                VoiceCommandIntent.MODE_BATTERY_SAVER -> setPerformanceMode(PerformanceMode.BATTERY_SAVER)
                VoiceCommandIntent.MODE_BALANCED -> setPerformanceMode(PerformanceMode.BALANCED)
                VoiceCommandIntent.MODE_PERFORMANCE -> setPerformanceMode(PerformanceMode.PERFORMANCE)
                VoiceCommandIntent.OPEN_AI_HUB -> _events.tryEmit(AppEvent.NavigateToAiHub)
                VoiceCommandIntent.PAUSE_CONTROLS -> AccessibilityBridge.setPaused(true)
                VoiceCommandIntent.RESUME_CONTROLS -> AccessibilityBridge.setPaused(false)
                VoiceCommandIntent.OPEN_APP -> {
                    val launched = cmd.appTargetQuery?.let { voiceManager.launchInstalledAppByName(it) } == true
                    _events.tryEmit(
                        AppEvent.ToastMessage(
                            if (launched) "Opening ${cmd.appTargetQuery}" else "App '${cmd.appTargetQuery}' not found"
                        )
                    )
                }
                VoiceCommandIntent.START_CAMERA -> _events.tryEmit(AppEvent.ToastMessage("Open Camera Studio to grant/start live preview."))
                VoiceCommandIntent.UNKNOWN -> _events.tryEmit(AppEvent.ToastMessage("Unrecognized command: ${cmd.rawTranscript}"))
            }
        }
    }

    // --- AI HUB ACTIONS ---

    fun testAndSaveProvider(
        existingId: Long,
        name: String,
        adapterType: AiAdapterType,
        baseUrl: String,
        chatPath: String,
        apiKey: String,
        modelName: String,
        customHeadersJson: String,
        temperature: Float,
        maxContextMessages: Int
    ) {
        viewModelScope.launch {
            _isTestingApi.value = true
            _setupValidation.value = null
            val result = aiRepository.client.testConnectionAndDiscover(
                adapterType = adapterType,
                baseUrl = baseUrl,
                chatPath = chatPath,
                apiKey = apiKey,
                modelName = modelName,
                customHeadersJson = customHeadersJson
            )
            _setupValidation.value = result
            if (result.success) {
                val chosenModel = modelName.trim().ifBlank { result.discoveredModels.firstOrNull() ?: adapterType.defaultModel }
                aiRepository.saveVerifiedProvider(
                    existingId = existingId,
                    name = name,
                    adapterType = adapterType,
                    baseUrl = baseUrl,
                    chatEndpointPath = chatPath,
                    modelName = chosenModel,
                    plainApiKey = apiKey,
                    customHeadersJson = customHeadersJson,
                    temperature = temperature,
                    maxContextMessages = maxContextMessages,
                    isVerified = true,
                    statusMessage = result.statusMessage
                )
                soundEngine.playCue(SoundCue.NOTIFICATION, settings.value.voiceSound)
                _events.tryEmit(AppEvent.ToastMessage("Provider verified & saved with Keystore encryption."))
            }
            _isTestingApi.value = false
        }
    }

    fun selectSession(sessionId: Long?) {
        _selectedSessionId.value = sessionId
    }

    fun startNewChat(provider: AiProviderEntity) {
        viewModelScope.launch {
            val id = aiRepository.createSession("Chat • ${provider.modelName}", provider)
            _selectedSessionId.value = id
        }
    }

    fun sendChatMessage(prompt: String, provider: AiProviderEntity) {
        val clean = prompt.trim()
        if (clean.isBlank() || _isGeneratingChat.value) return

        activeChatJob?.cancel()
        activeChatJob = viewModelScope.launch {
            _isGeneratingChat.value = true
            _streamingAssistantText.value = ""

            val sessionId = _selectedSessionId.value ?: aiRepository.createSession(
                title = clean.take(28),
                provider = provider
            ).also { _selectedSessionId.value = it }

            aiRepository.appendMessage(sessionId, "user", clean)
            streamAssistantReply(sessionId, provider)
        }
    }

    fun regenerateLastResponse(provider: AiProviderEntity) {
        val sessionId = _selectedSessionId.value ?: return
        if (_isGeneratingChat.value) return

        activeChatJob?.cancel()
        activeChatJob = viewModelScope.launch {
            val currentMsgs = activeMessages.value
            val lastMsg = currentMsgs.lastOrNull()
            if (lastMsg?.role == "assistant") {
                aiRepository.deleteMessage(lastMsg.id)
            }
            _isGeneratingChat.value = true
            _streamingAssistantText.value = ""
            streamAssistantReply(sessionId, provider)
        }
    }

    private suspend fun streamAssistantReply(sessionId: Long, provider: AiProviderEntity) {
        val apiKey = aiRepository.decryptApiKey(provider)
        val adapter = runCatching { AiAdapterType.valueOf(provider.adapterType) }
            .getOrDefault(AiAdapterType.OPENAI_COMPATIBLE)
        val drafts = aiRepository.getContextDrafts(sessionId, provider.maxContextMessages)

        var latestText = ""
        var failureMessage: String? = null

        aiRepository.client.streamChatCompletion(
            adapterType = adapter,
            baseUrl = provider.baseUrl,
            chatPath = provider.chatEndpointPath,
            apiKey = apiKey,
            modelName = provider.modelName,
            customHeadersJson = provider.customHeadersJson,
            messages = drafts,
            temperature = provider.temperature
        ).collect { result ->
            result.onSuccess { partial ->
                latestText = partial
                _streamingAssistantText.value = partial
            }.onFailure { err ->
                failureMessage = err.localizedMessage ?: "Request failed."
            }
        }

        if (latestText.isNotBlank()) {
            aiRepository.appendMessage(sessionId, "assistant", latestText)
        } else if (failureMessage != null) {
            aiRepository.appendMessage(sessionId, "assistant", "Error: $failureMessage")
        }

        _streamingAssistantText.value = null
        _isGeneratingChat.value = false
    }

    fun stopGeneration() {
        val partial = _streamingAssistantText.value
        val sessionId = _selectedSessionId.value
        activeChatJob?.cancel()
        activeChatJob = null
        _isGeneratingChat.value = false
        _streamingAssistantText.value = null
        if (!partial.isNullOrBlank() && sessionId != null) {
            viewModelScope.launch {
                aiRepository.appendMessage(sessionId, "assistant", partial)
            }
        }
    }

    fun clearLocalConfiguration() {
        emergencyStopAll()
        viewModelScope.launch {
            preferences.clearAll()
            aiRepository.wipeAllCredentialsAndChats()
            database.gestureHistoryDao().clearAll()
            database.customMaskDao().clearAll()
            _selectedSessionId.value = null
            _events.tryEmit(AppEvent.ToastMessage("All local settings, chat history, and encrypted API keys cleared."))
        }
    }

    override fun onCleared() {
        performanceEngine.stopMonitoring()
        cameraController.shutdown()
        faceEngine.close()
        handEngine.close()
        voiceManager.stopListening()
        soundEngine.release()
        super.onCleared()
    }

    fun updateNowTickMs(): Long = SystemClock.elapsedRealtime()
}
