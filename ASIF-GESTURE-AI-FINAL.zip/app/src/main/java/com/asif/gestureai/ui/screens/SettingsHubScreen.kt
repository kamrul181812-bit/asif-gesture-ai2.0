package com.asif.gestureai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.asif.gestureai.accessibility.AccessibilityStatus
import com.asif.gestureai.camera.CameraStatus
import com.asif.gestureai.core.DeviceProfile
import com.asif.gestureai.core.PermissionHelper
import com.asif.gestureai.core.PermissionStatusSnapshot
import com.asif.gestureai.performance.PerformanceMode
import com.asif.gestureai.performance.PerformanceTelemetry
import com.asif.gestureai.service.FloatingOverlayState
import com.asif.gestureai.settings.AllAppSettings
import com.asif.gestureai.settings.FloatingSizePreset
import com.asif.gestureai.settings.FloatingVisibilityMode
import com.asif.gestureai.settings.FloatingWindowSettings
import com.asif.gestureai.settings.PerformancePreferences
import com.asif.gestureai.settings.VoiceAndSoundSettings
import com.asif.gestureai.ui.components.GlassCard
import com.asif.gestureai.ui.components.HudMetricBar
import com.asif.gestureai.ui.components.StatusPill
import com.asif.gestureai.voice.VoiceStatusState
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GlassBorderBlue
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsHubScreen(
    settings: AllAppSettings,
    telemetry: PerformanceTelemetry,
    cameraStatus: CameraStatus,
    permissions: PermissionStatusSnapshot,
    accessibilityStatus: AccessibilityStatus,
    floatingState: FloatingOverlayState,
    voiceStatus: VoiceStatusState,
    savedProvidersCount: Int = 0,
    onSelectPerformanceMode: (PerformanceMode) -> Unit,
    onUpdatePerformancePrefs: ((PerformancePreferences) -> PerformancePreferences) -> Unit,
    onUpdateFloating: ((FloatingWindowSettings) -> FloatingWindowSettings) -> Unit,
    onStartFloatingMode: (FloatingVisibilityMode) -> Unit,
    onStopFloating: () -> Unit,
    onEnterPip: () -> Unit,
    onToggleVoiceListening: () -> Unit,
    onUpdateVoiceSound: ((VoiceAndSoundSettings) -> VoiceAndSoundSettings) -> Unit,
    onTestSoundCue: () -> Unit,
    onRequestRuntimePermissions: () -> Unit,
    onOpenOverlaySettings: () -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onOpenAppInfo: () -> Unit = {},
    restrictedSettingsLikely: Boolean = false,
    onEmergencyStopAll: () -> Unit,
    onClearAllLocalData: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderSwatches = listOf(0xFF00FF88L, 0xFF00D4FFL, 0xFFFFB800L, 0xFFFF4D6DL)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Control Hub & Settings", style = MaterialTheme.typography.headlineSmall, color = NeonEmerald)

            // 1. PERFORMANCE MONITOR & PROFILES
            GlassCard(borderColor = NeonEmerald.copy(alpha = 0.35f)) {
                Text("Performance Profile (Symphony Inova 30)", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text("${DeviceProfile.TARGET_SOC_LABEL} • ${DeviceProfile.TARGET_RAM_GB} GB RAM", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PerformanceMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.performance.mode == mode,
                            onClick = { onSelectPerformanceMode(mode) },
                            label = { Text(mode.displayName) }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(settings.performance.mode.description, style = MaterialTheme.typography.bodySmall, color = ElectricBlue)
                Spacer(Modifier.height(10.dp))
                HudMetricBar(
                    label = "Memory Free: ${telemetry.availableMemoryMb} MB / ${telemetry.totalMemoryMb} MB",
                    valueText = "Used: ${telemetry.appUsedMemoryMb} MB",
                    progress = if (telemetry.totalMemoryMb > 0) 1f - (telemetry.availableMemoryMb.toFloat() / telemetry.totalMemoryMb.toFloat()) else 0.3f,
                    color = NeonEmerald
                )
                Spacer(Modifier.height(6.dp))
                HudMetricBar(
                    label = "Thermal: ${telemetry.thermalState.label} • Throttle ${String.format("%.2fx", telemetry.throttleFactor)}",
                    valueText = "Frame ${telemetry.cameraFrameTimeMs}ms",
                    progress = (telemetry.cpuLoadEstimatePercent / 100f),
                    color = if (telemetry.thermalState.isWarning) CyberAmber else ElectricBlue
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Adaptive Frequency Scaling", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = settings.performance.adaptiveEnabled,
                        onCheckedChange = { v -> onUpdatePerformancePrefs { it.copy(adaptiveEnabled = v) } }
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Thermal Guard Monitoring", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = settings.performance.thermalMonitoringEnabled,
                        onCheckedChange = { v -> onUpdatePerformancePrefs { it.copy(thermalMonitoringEnabled = v) } }
                    )
                }
            }

            // 2. FLOATING CAMERA, HIDDEN PANEL MODE & PiP
            GlassCard(borderColor = GlassBorderBlue) {
                Text("Floating Overlay & Hidden Panel Mode", style = MaterialTheme.typography.titleMedium, color = ElectricBlue)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Visible & Mini modes render a draggable overlay panel (requires Overlay permission). Hidden Panel Mode hides the floating visual panel while keeping persistent Restore/STOP notification controls and authorized Accessibility actions. Android system privacy dots are never hidden.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                StatusPill(floatingState.statusText, floatingState.running, ElectricBlue)
                Spacer(Modifier.height(10.dp))

                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    FloatingVisibilityMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.floating.visibilityMode == mode && floatingState.running,
                            onClick = { onStartFloatingMode(mode) },
                            label = { Text(mode.displayName, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onStartFloatingMode(settings.floating.visibilityMode) },
                        modifier = Modifier.weight(1f).testTag("launch_floating_button")
                    ) {
                        Icon(Icons.Rounded.Visibility, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Start Overlay")
                    }
                    OutlinedButton(onClick = onEnterPip, modifier = Modifier.weight(1f).testTag("settings_pip_button")) {
                        Icon(Icons.Rounded.PictureInPictureAlt, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Android PiP")
                    }
                }
                if (floatingState.running) {
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = onStopFloating, modifier = Modifier.fillMaxWidth()) {
                        Text("Close Floating Service", color = AlertCrimson)
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text("Window Size Preset", style = MaterialTheme.typography.labelSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FloatingSizePreset.entries.forEach { preset ->
                        FilterChip(
                            selected = settings.floating.sizePreset == preset,
                            onClick = { onUpdateFloating { it.copy(sizePreset = preset) } },
                            label = { Text(preset.displayName) }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Aspect Ratio", style = MaterialTheme.typography.labelSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val ratios = listOf(Triple("3:4", 3f, 4f), Triple("1:1", 1f, 1f), Triple("16:9", 16f, 9f))
                    ratios.forEach { (label, w, h) ->
                        val selected = settings.floating.aspectRatioW == w && settings.floating.aspectRatioH == h
                        FilterChip(
                            selected = selected,
                            onClick = { onUpdateFloating { it.copy(aspectRatioW = w, aspectRatioH = h) } },
                            label = { Text(label) }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Corner Radius: ${settings.floating.cornerRadiusDp.toInt()} dp", style = MaterialTheme.typography.labelSmall)
                Slider(value = settings.floating.cornerRadiusDp, onValueChange = { v -> onUpdateFloating { it.copy(cornerRadiusDp = v) } }, valueRange = 4f..32f)
                Text("Border Thickness: ${String.format("%.1f", settings.floating.borderThicknessDp)} dp", style = MaterialTheme.typography.labelSmall)
                Slider(value = settings.floating.borderThicknessDp, onValueChange = { v -> onUpdateFloating { it.copy(borderThicknessDp = v) } }, valueRange = 1f..6f)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    borderSwatches.forEach { hex ->
                        val selected = settings.floating.borderColorArgb == hex
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(hex.toInt()))
                                .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color.Gray, CircleShape)
                                .clickable { onUpdateFloating { it.copy(borderColorArgb = hex) } }
                        )
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Edge Snapping", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = settings.floating.edgeSnapEnabled, onCheckedChange = { v -> onUpdateFloating { it.copy(edgeSnapEnabled = v) } })
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Show Compact Floating Controls", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = settings.floating.showCompactControls, onCheckedChange = { v -> onUpdateFloating { it.copy(showCompactControls = v) } })
                }
            }

            // 3. VOICE CONTROL & SOUND EFFECTS
            GlassCard {
                Text("Voice Control & Sound System", style = MaterialTheme.typography.titleMedium, color = NeonEmerald)
                Spacer(Modifier.height(6.dp))
                StatusPill(
                    label = if (voiceStatus.isListening) "Listening (Mic Active)..." else voiceStatus.lastCommandLabel,
                    active = voiceStatus.isListening,
                    accentColor = if (voiceStatus.isListening) AlertCrimson else ElectricBlue
                )
                voiceStatus.errorMessage?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, style = MaterialTheme.typography.bodySmall, color = CyberAmber)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onToggleVoiceListening,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (voiceStatus.isListening) AlertCrimson else ElectricBlue,
                            contentColor = ObsidianBlack
                        ),
                        modifier = Modifier.weight(1f).testTag("voice_listen_button")
                    ) {
                        Icon(if (voiceStatus.isListening) Icons.Rounded.MicOff else Icons.Rounded.Mic, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (voiceStatus.isListening) "Stop Listening" else "Voice Command")
                    }
                    OutlinedButton(onClick = onTestSoundCue) {
                        Text("Test Cue")
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Sound Effects", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = settings.voiceSound.soundEffectsEnabled, onCheckedChange = { v -> onUpdateVoiceSound { it.copy(soundEffectsEnabled = v) } })
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Voice Feedback (TTS)", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = settings.voiceSound.voiceFeedbackEnabled, onCheckedChange = { v -> onUpdateVoiceSound { it.copy(voiceFeedbackEnabled = v) } })
                }
                Text("Sound Volume: ${(settings.voiceSound.masterVolume * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                Slider(value = settings.voiceSound.masterVolume, onValueChange = { v -> onUpdateVoiceSound { it.copy(masterVolume = v) } }, valueRange = 0.05f..1.0f)
                Text("Active Sound Cue Categories", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = settings.voiceSound.buttonSoundEnabled,
                        onClick = { onUpdateVoiceSound { it.copy(buttonSoundEnabled = !it.buttonSoundEnabled) } },
                        label = { Text("Button") }
                    )
                    FilterChip(
                        selected = settings.voiceSound.gestureSoundEnabled,
                        onClick = { onUpdateVoiceSound { it.copy(gestureSoundEnabled = !it.gestureSoundEnabled) } },
                        label = { Text("Gesture") }
                    )
                    FilterChip(
                        selected = settings.voiceSound.clickSoundEnabled,
                        onClick = { onUpdateVoiceSound { it.copy(clickSoundEnabled = !it.clickSoundEnabled) } },
                        label = { Text("Click") }
                    )
                    FilterChip(
                        selected = settings.voiceSound.cameraSoundEnabled,
                        onClick = { onUpdateVoiceSound { it.copy(cameraSoundEnabled = !it.cameraSoundEnabled) } },
                        label = { Text("Camera") }
                    )
                    FilterChip(
                        selected = settings.voiceSound.modeSwitchSoundEnabled,
                        onClick = { onUpdateVoiceSound { it.copy(modeSwitchSoundEnabled = !it.modeSwitchSoundEnabled) } },
                        label = { Text("Mode Switch") }
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Voice commands: \"Start camera\", \"Stop camera\", \"Enable mask\", \"Disable mask\", \"Battery saver\", \"Balanced\", \"Performance\", \"Open AI Hub\", \"Pause\", \"Resume\", \"Open <App Name>\".",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            // 4. PERMISSION MANAGER & PRIVACY
            GlassCard(borderColor = CyberAmber.copy(alpha = 0.4f)) {
                Text("Permission Manager & Privacy Audit", style = MaterialTheme.typography.titleMedium, color = CyberAmber)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusPill("Camera: ${if (permissions.cameraGranted) "Granted" else "Denied"}", permissions.cameraGranted)
                    StatusPill("Mic: ${if (permissions.microphoneGranted) "Granted" else "Denied"}", permissions.microphoneGranted)
                    StatusPill("Notifications: ${if (permissions.notificationsGranted) "Granted" else "Denied"}", permissions.notificationsGranted)
                    StatusPill("Overlay: ${if (permissions.overlayGranted) "Granted" else "Off"}", permissions.overlayGranted, ElectricBlue)
                    StatusPill("Accessibility: ${if (accessibilityStatus.connected) "Enabled" else "Off"}", accessibilityStatus.connected, ElectricBlue)
                    StatusPill("Camera State: ${if (cameraStatus is CameraStatus.Running) "Active" else "Stopped"}", cameraStatus is CameraStatus.Running)
                    StatusPill("Encrypted AI Providers: $savedProvidersCount", savedProvidersCount > 0, NeonEmerald)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onRequestRuntimePermissions, modifier = Modifier.weight(1f)) {
                        Text("Runtime Perms", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(onClick = onOpenOverlaySettings, modifier = Modifier.weight(1f)) {
                        Text("Overlay", style = MaterialTheme.typography.labelSmall)
                    }
                    OutlinedButton(onClick = onOpenAccessibilitySettings, modifier = Modifier.weight(1f)) {
                        Text("Accessibility", style = MaterialTheme.typography.labelSmall)
                    }
                }
                if (!accessibilityStatus.connected) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        if (restrictedSettingsLikely) "Accessibility is OFF \u2014 Android may block it for apps installed outside Google Play:" else "Accessibility is OFF \u2014 enable it to use Virtual Mouse and Reels gestures:",
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberAmber
                    )
                    Text(
                        PermissionHelper.RESTRICTED_SETTINGS_STEPS,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = onOpenAppInfo, modifier = Modifier.fillMaxWidth()) {
                        Text("App Info (Allow restricted settings)", style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onEmergencyStopAll,
                        colors = ButtonDefaults.buttonColors(containerColor = AlertCrimson, contentColor = Color.White),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Rounded.Stop, null)
                        Spacer(Modifier.width(4.dp))
                        Text("Stop All")
                    }
                    OutlinedButton(
                        onClick = onClearAllLocalData,
                        modifier = Modifier.weight(1f).testTag("clear_all_data_button")
                    ) {
                        Icon(Icons.Rounded.DeleteForever, null, tint = AlertCrimson)
                        Spacer(Modifier.width(4.dp))
                        Text("Clear Data", color = AlertCrimson)
                    }
                }
            }

            GlassCard {
                Text("ASIF GESTURE AI", style = MaterialTheme.typography.titleSmall, color = NeonEmerald)
                Text("Developer: ASIF ISLAM", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "All camera frames, facial landmarks, and hand tracking run 100% locally on-device. User AI API keys are stored encrypted via Android Keystore.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}
