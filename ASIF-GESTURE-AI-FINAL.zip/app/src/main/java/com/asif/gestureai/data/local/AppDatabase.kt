package com.asif.gestureai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        AiProviderEntity::class,
        ChatSessionEntity::class,
        ChatMessageEntity::class,
        GestureHistoryEntity::class,
        CustomMaskEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun aiProviderDao(): AiProviderDao
    abstract fun chatDao(): ChatDao
    abstract fun gestureHistoryDao(): GestureHistoryDao
    abstract fun customMaskDao(): CustomMaskDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "asif_gesture_ai_db"
                ).fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
