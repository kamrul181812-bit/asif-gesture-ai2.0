package com.asif.gestureai.core

import kotlin.math.max

/**
 * Single coordinate pipeline for every overlay (face mask, hand skeleton, eye debug, PiP).
 *
 * Pipeline:
 *  1. CameraX ImageAnalysis delivers a sensor-oriented RGBA frame (w x h) + rotationDegrees.
 *  2. MediaPipe is told the rotation (ImageProcessingOptions) and returns landmarks normalized to the
 *     UPRIGHT image, whose size is [uprightWidth] x [uprightHeight].
 *  3. For the front camera the engines mirror X (1 - x) so the overlay matches the mirrored PreviewView.
 *     Mirroring is applied exactly once, in the engines (see [mirrorX]); the transform below never mirrors.
 *  4. PreviewView uses FILL_CENTER: the upright image is scaled uniformly by max(cw/iw, ch/ih) and centered,
 *     cropping the overflow. [FillCenterTransform] reproduces that exactly, so a landmark lands on the same
 *     pixel the preview shows. Preview and analysis both use the same 4:3 aspect ratio, so FOV is identical.
 */
object CoordinateMapper {

    fun uprightWidth(frameWidth: Int, frameHeight: Int, rotationDegrees: Int): Int =
        if (isQuarterTurn(rotationDegrees)) frameHeight else frameWidth

    fun uprightHeight(frameWidth: Int, frameHeight: Int, rotationDegrees: Int): Int =
        if (isQuarterTurn(rotationDegrees)) frameWidth else frameHeight

    fun isQuarterTurn(rotationDegrees: Int): Boolean {
        val r = ((rotationDegrees % 360) + 360) % 360
        return r == 90 || r == 270
    }

    /** Selfie mirroring of a normalized X coordinate. */
    fun mirrorX(normX: Float, isFrontCamera: Boolean): Float =
        if (isFrontCamera) 1f - normX else normX
}

/**
 * Immutable FILL_CENTER transform. Create once per draw pass, then call [x]/[y] for every point
 * (no per-point allocation). If the image size is unknown (<= 0) it falls back to a plain stretch so
 * nothing crashes, but callers should always provide the real upright image size.
 */
class FillCenterTransform(
    imageWidth: Int,
    imageHeight: Int,
    canvasWidth: Float,
    canvasHeight: Float
) {
    val scaledWidth: Float
    val scaledHeight: Float
    val offsetX: Float
    val offsetY: Float

    init {
        if (imageWidth <= 0 || imageHeight <= 0 || canvasWidth <= 0f || canvasHeight <= 0f) {
            scaledWidth = canvasWidth
            scaledHeight = canvasHeight
            offsetX = 0f
            offsetY = 0f
        } else {
            val scale = max(canvasWidth / imageWidth, canvasHeight / imageHeight)
            scaledWidth = imageWidth * scale
            scaledHeight = imageHeight * scale
            offsetX = (canvasWidth - scaledWidth) * 0.5f
            offsetY = (canvasHeight - scaledHeight) * 0.5f
        }
    }

    fun x(normX: Float): Float = normX * scaledWidth + offsetX
    fun y(normY: Float): Float = normY * scaledHeight + offsetY

    /** Inverse mapping: canvas pixel -> normalized upright-image coordinate (for touch / pointer tests). */
    fun normX(canvasX: Float): Float = if (scaledWidth > 0f) (canvasX - offsetX) / scaledWidth else 0f
    fun normY(canvasY: Float): Float = if (scaledHeight > 0f) (canvasY - offsetY) / scaledHeight else 0f
}
