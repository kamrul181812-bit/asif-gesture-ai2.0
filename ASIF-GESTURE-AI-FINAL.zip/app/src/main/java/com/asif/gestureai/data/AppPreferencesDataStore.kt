package com.asif.gestureai.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.asif.gestureai.core.AppLogger
import com.asif.gestureai.settings.AllAppSettings
import com.asif.gestureai.settings.CameraSettings
import com.asif.gestureai.settings.EyeTrackingSettings
import com.asif.gestureai.settings.FloatingWindowSettings
import com.asif.gestureai.settings.GestureSettings
import com.asif.gestureai.settings.MaskSettings
import com.asif.gestureai.settings.PerformancePreferences
import com.asif.gestureai.settings.ReelsModeSettings
import com.asif.gestureai.settings.VirtualMouseSettings
import com.asif.gestureai.settings.VoiceAndSoundSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.appSettingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "asif_gesture_ai_prefs"
)

class AppPreferencesDataStore(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private object Keys {
        val ALL_SETTINGS = stringPreferencesKey("all_app_settings_json")
    }

    val settingsFlow: Flow<AllAppSettings> = context.appSettingsDataStore.data
        .catch { e ->
            AppLogger.e("DataStore", "Failed reading preferences", e)
            emit(androidx.datastore.preferences.core.emptyPreferences())
        }
        .map { prefs ->
            val raw = prefs[Keys.ALL_SETTINGS]
            if (raw.isNullOrBlank()) {
                AllAppSettings()
            } else {
                runCatching { json.decodeFromString(AllAppSettings.serializer(), raw) }
                    .getOrElse {
                        AppLogger.w("DataStore", "Falling back to default settings after parse error", it)
                        AllAppSettings()
                    }
            }
        }

    suspend fun updateAll(transform: (AllAppSettings) -> AllAppSettings) {
        context.appSettingsDataStore.edit { prefs ->
            val current = prefs[Keys.ALL_SETTINGS]?.let { raw ->
                runCatching { json.decodeFromString(AllAppSettings.serializer(), raw) }.getOrNull()
            } ?: AllAppSettings()
            val updated = transform(current)
            prefs[Keys.ALL_SETTINGS] = json.encodeToString(AllAppSettings.serializer(), updated)
        }
    }

    suspend fun updateCamera(block: (CameraSettings) -> CameraSettings) =
        updateAll { it.copy(camera = block(it.camera)) }

    suspend fun updateMask(block: (MaskSettings) -> MaskSettings) =
        updateAll { it.copy(mask = block(it.mask)) }

    suspend fun updateGesture(block: (GestureSettings) -> GestureSettings) =
        updateAll { it.copy(gesture = block(it.gesture)) }

    suspend fun updateEyeTracking(block: (EyeTrackingSettings) -> EyeTrackingSettings) =
        updateAll { it.copy(eyeTracking = block(it.eyeTracking)) }

    suspend fun updateVirtualMouse(block: (VirtualMouseSettings) -> VirtualMouseSettings) =
        updateAll { it.copy(virtualMouse = block(it.virtualMouse)) }

    suspend fun updateFloating(block: (FloatingWindowSettings) -> FloatingWindowSettings) =
        updateAll { it.copy(floating = block(it.floating)) }

    suspend fun updateReels(block: (ReelsModeSettings) -> ReelsModeSettings) =
        updateAll { it.copy(reels = block(it.reels)) }

    suspend fun updateVoiceSound(block: (VoiceAndSoundSettings) -> VoiceAndSoundSettings) =
        updateAll { it.copy(voiceSound = block(it.voiceSound)) }

    suspend fun updatePerformance(block: (PerformancePreferences) -> PerformancePreferences) =
        updateAll { it.copy(performance = block(it.performance)) }

    suspend fun clearAll() {
        context.appSettingsDataStore.edit { it.clear() }
    }
}
