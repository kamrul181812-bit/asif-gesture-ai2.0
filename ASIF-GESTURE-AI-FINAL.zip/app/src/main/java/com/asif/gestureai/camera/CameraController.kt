package com.asif.gestureai.camera

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.CameraState
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.asif.gestureai.core.AppLogger
import com.asif.gestureai.core.PermissionHelper
import com.asif.gestureai.performance.AdaptivePerformanceEngine
import com.asif.gestureai.settings.CameraLensOption
import com.asif.gestureai.settings.CameraSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference
import java.nio.ByteBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

sealed interface CameraStatus {
    data object Stopped : CameraStatus
    data object Starting : CameraStatus
    data class Running(
        val lens: CameraLensOption,
        val resolutionLabel: String,
        val fps: Float
    ) : CameraStatus
    data class Error(val message: String, val recoverable: Boolean = true) : CameraStatus
}

fun interface FrameAnalyzerCallback {
    fun onFrameAvailable(
        bitmap: Bitmap,
        rotationDegrees: Int,
        isFrontCamera: Boolean,
        timestampMs: Long,
        avgLuminance: Float
    )
}

/**
 * Crash-resistant CameraX manager engineered for long-duration sessions on Symphony Inova 30.
 *
 * Guarantees:
 * - ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST (no unbounded frame queue)
 * - Every ImageProxy closed unconditionally in finally {}
 * - Synchronized reusable Bitmap + row-stride-safe buffer copy (prevents race/OOM)
 * - WeakReference<PreviewView> prevents Activity/View memory leaks across tab switches
 * - CameraState error observer catches camera eviction/conflicts cleanly
 * - Duplicate initialization lock & single-frame inference guard
 */
class CameraController(
    private val context: Context,
    private val performanceEngine: AdaptivePerformanceEngine
) {
    companion object {
        private const val TAG = "CameraController"
    }

    private val _status = MutableStateFlow<CameraStatus>(CameraStatus.Stopped)
    val status: StateFlow<CameraStatus> = _status.asStateFlow()

    private val isInitializing = AtomicBoolean(false)
    private val isAnalyzing = AtomicBoolean(false)
    private val isActive = AtomicBoolean(false)
    private val lastFrameTimestamp = AtomicLong(0L)
    private val bitmapLock = Any()

    @Volatile
    private var cameraProvider: ProcessCameraProvider? = null
    @Volatile
    private var analysisExecutor: ExecutorService? = null
    @Volatile
    private var reusableBitmap: Bitmap? = null
    @Volatile
    private var rowScratchBuffer: ByteArray? = null
    @Volatile
    private var previewRef: WeakReference<PreviewView>? = null
    @Volatile
    private var lastLifecycleOwnerRef: WeakReference<LifecycleOwner>? = null

    @Volatile
    private var currentSettings: CameraSettings = CameraSettings()
    private var frameCallback: FrameAnalyzerCallback? = null

    fun setFrameCallback(callback: FrameAnalyzerCallback?) {
        this.frameCallback = callback
    }

    fun updateRuntimeSettings(settings: CameraSettings) {
        val oldResolution = currentSettings.resolutionTier
        val oldPreviewQuality = currentSettings.highPreviewQuality
        currentSettings = settings
        if (isActive.get() && (oldResolution != settings.resolutionTier || oldPreviewQuality != settings.highPreviewQuality)) {
            val owner = lastLifecycleOwnerRef?.get()
            if (owner != null) {
                startCamera(owner, previewRef?.get(), settings)
            }
        }
    }

    fun reattachPreviewIfRunning(lifecycleOwner: LifecycleOwner, previewView: PreviewView?) {
        previewRef = previewView?.let { WeakReference(it) }
        lastLifecycleOwnerRef = WeakReference(lifecycleOwner)
        if (isActive.get() && previewView != null && !isInitializing.get()) {
            val provider = cameraProvider ?: return
            ContextCompat.getMainExecutor(context).execute {
                if (isActive.get()) {
                    bindUseCases(provider, lifecycleOwner, previewView, currentSettings)
                }
            }
        }
    }

    fun startCamera(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView?,
        settings: CameraSettings
    ) {
        currentSettings = settings
        previewRef = previewView?.let { WeakReference(it) }
        lastLifecycleOwnerRef = WeakReference(lifecycleOwner)

        if (!PermissionHelper.snapshot(context).cameraGranted) {
            isActive.set(false)
            _status.value = CameraStatus.Error(
                "Camera permission is required. Grant Camera permission to start live vision.",
                recoverable = true
            )
            return
        }

        if (!isInitializing.compareAndSet(false, true)) {
            AppLogger.d(TAG, "Ignoring duplicate camera start while initialization is in progress.")
            return
        }

        _status.value = CameraStatus.Starting
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                bindUseCases(provider, lifecycleOwner, previewRef?.get(), currentSettings)
            } catch (oom: OutOfMemoryError) {
                AppLogger.e(TAG, "OutOfMemoryError initializing camera", oom)
                releaseReusableBuffers()
                _status.value = CameraStatus.Error(
                    "Memory pressure prevented camera startup. Try Battery Saver mode.",
                    recoverable = true
                )
            } catch (e: Exception) {
                AppLogger.e(TAG, "Camera initialization failed", e)
                _status.value = CameraStatus.Error(
                    "Camera unavailable or in use by another app (${e.localizedMessage ?: "error"}).",
                    recoverable = true
                )
            } finally {
                isInitializing.set(false)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun bindUseCases(
        provider: ProcessCameraProvider,
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView?,
        settings: CameraSettings
    ) {
        try {
            provider.unbindAll()

            val executor = analysisExecutor?.takeIf { !it.isShutdown }
                ?: Executors.newSingleThreadExecutor { runnable ->
                    Thread(runnable, "AsifCameraAnalysis").apply { isDaemon = true }
                }.also { analysisExecutor = it }

            val targetSize = if (performanceEngine.telemetry.value.throttleFactor > 1.5f) {
                Size(320, 240)
            } else {
                Size(settings.resolutionTier.width, settings.resolutionTier.height)
            }

            val analysisSelector = ResolutionSelector.Builder()
                // Same 4:3 aspect as the preview => identical field of view, so FILL_CENTER overlay math is exact.
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        targetSize,
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                    )
                )
                .build()

            val previewTarget = if (settings.highPreviewQuality) Size(720, 960) else targetSize
            val previewSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        previewTarget,
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                    )
                )
                .build()

            val lensFacing = if (settings.lens == CameraLensOption.FRONT) {
                CameraSelector.LENS_FACING_FRONT
            } else {
                CameraSelector.LENS_FACING_BACK
            }

            val selector = CameraSelector.Builder()
                .requireLensFacing(lensFacing)
                .build()

            val preview = Preview.Builder()
                .setResolutionSelector(previewSelector)
                .build()
                .apply {
                    if (previewView != null) {
                        surfaceProvider = previewView.surfaceProvider
                    }
                }

            val imageAnalysis = ImageAnalysis.Builder()
                .setResolutionSelector(analysisSelector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            imageAnalysis.setAnalyzer(executor) { imageProxy ->
                processImageProxy(imageProxy, settings.lens == CameraLensOption.FRONT)
            }

            val boundCamera = if (previewView != null) {
                provider.bindToLifecycle(lifecycleOwner, selector, preview, imageAnalysis)
            } else {
                provider.bindToLifecycle(lifecycleOwner, selector, imageAnalysis)
            }

            boundCamera.cameraInfo.cameraState.observe(lifecycleOwner) { camState ->
                camState.error?.let { err ->
                    val errText = when (err.code) {
                        CameraState.ERROR_CAMERA_IN_USE -> "Camera is currently in use by another app."
                        CameraState.ERROR_MAX_CAMERAS_IN_USE -> "Maximum concurrent camera limit reached."
                        CameraState.ERROR_CAMERA_DISABLED -> "Camera disabled by device policy."
                        CameraState.ERROR_DO_NOT_DISTURB_MODE_ENABLED -> "Camera interrupted by Do Not Disturb mode."
                        else -> "Camera interrupted (code ${err.code})."
                    }
                    AppLogger.w(TAG, "CameraState error observed: $errText")
                    if (err.type == CameraState.ErrorType.CRITICAL) {
                        isActive.set(false)
                        _status.value = CameraStatus.Error(errText, recoverable = true)
                    }
                }
            }

            isActive.set(true)
            _status.value = CameraStatus.Running(
                lens = settings.lens,
                resolutionLabel = "${targetSize.width}x${targetSize.height}",
                fps = performanceEngine.telemetry.value.effectiveFps
            )
            AppLogger.i(TAG, "Camera bound: ${settings.lens.label} @ ${targetSize.width}x${targetSize.height}")
        } catch (e: Exception) {
            isActive.set(false)
            AppLogger.e(TAG, "Camera bind failed", e)
            _status.value = CameraStatus.Error(
                "Camera conflict or hardware error: ${e.localizedMessage ?: "Unable to bind camera"}",
                recoverable = true
            )
        }
    }

    private fun processImageProxy(imageProxy: ImageProxy, isFrontCamera: Boolean) {
        val frameStart = SystemClock.elapsedRealtime()
        try {
            if (!isActive.get()) return

            // Enforce FPS pacing from user settings & AdaptivePerformanceEngine
            val targetFps = currentSettings.targetFps.coerceIn(8, 30)
            val minFrameIntervalMs = (1000L / targetFps)
            val now = SystemClock.elapsedRealtime()
            if (now - lastFrameTimestamp.get() < minFrameIntervalMs) {
                return
            }

            // Never stack concurrent inference loops
            if (!isAnalyzing.compareAndSet(false, true)) {
                return
            }

            try {
                lastFrameTimestamp.set(now)
                synchronized(bitmapLock) {
                    if (!isActive.get()) return
                    val bitmap = copyRgbaToReusableBitmap(imageProxy)
                    if (bitmap.isRecycled) return
                    val luminance = estimateCenterLuminance(bitmap)
                    val rotation = imageProxy.imageInfo.rotationDegrees

                    frameCallback?.onFrameAvailable(
                        bitmap = bitmap,
                        rotationDegrees = rotation,
                        isFrontCamera = isFrontCamera,
                        timestampMs = now,
                        avgLuminance = luminance
                    )
                }

                val duration = SystemClock.elapsedRealtime() - frameStart
                performanceEngine.recordCameraFrame(duration)

                val current = _status.value
                if (current is CameraStatus.Running) {
                    _status.value = current.copy(fps = performanceEngine.telemetry.value.effectiveFps)
                }
            } finally {
                isAnalyzing.set(false)
            }
        } catch (oom: OutOfMemoryError) {
            AppLogger.e(TAG, "OutOfMemoryError during frame processing", oom)
            releaseReusableBuffers()
            _status.value = CameraStatus.Error(
                "Memory warning during frame analysis. Buffers cleared — switch to Battery Saver.",
                recoverable = true
            )
        } catch (t: Throwable) {
            AppLogger.w(TAG, "Non-fatal frame processing error", t)
        } finally {
            imageProxy.close()
        }
    }

    private fun copyRgbaToReusableBitmap(imageProxy: ImageProxy): Bitmap {
        val width = imageProxy.width
        val height = imageProxy.height
        val plane = imageProxy.planes[0]
        val buffer: ByteBuffer = plane.buffer
        buffer.rewind()

        val bitmap = reusableBitmap?.takeIf {
            !it.isRecycled && it.width == width && it.height == height
        } ?: run {
            reusableBitmap?.recycle()
            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also {
                reusableBitmap = it
            }
        }

        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width

        if (rowPadding == 0) {
            bitmap.copyPixelsFromBuffer(buffer)
        } else {
            val tightSize = width * height * 4
            val tightBytes = rowScratchBuffer?.takeIf { it.size == tightSize }
                ?: ByteArray(tightSize).also { rowScratchBuffer = it }

            var dstOffset = 0
            val rowLength = width * 4
            for (y in 0 until height) {
                buffer.position(y * rowStride)
                buffer.get(tightBytes, dstOffset, rowLength)
                dstOffset += rowLength
            }
            bitmap.copyPixelsFromBuffer(ByteBuffer.wrap(tightBytes))
        }
        return bitmap
    }

    private fun estimateCenterLuminance(bitmap: Bitmap): Float {
        if (bitmap.isRecycled || bitmap.width < 16 || bitmap.height < 16) return 0.5f
        var sum = 0f
        var count = 0
        val stepX = (bitmap.width / 8).coerceAtLeast(1)
        val stepY = (bitmap.height / 8).coerceAtLeast(1)
        var y = stepY
        while (y < bitmap.height - stepY) {
            var x = stepX
            while (x < bitmap.width - stepX) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                sum += (0.299f * r + 0.587f * g + 0.114f * b) / 255f
                count++
                x += stepX
            }
            y += stepY
        }
        return if (count > 0) sum / count else 0.5f
    }

    fun stopCamera() {
        isActive.set(false)
        try {
            cameraProvider?.unbindAll()
        } catch (e: Exception) {
            AppLogger.w(TAG, "Error unbinding camera provider", e)
        }
        _status.value = CameraStatus.Stopped
        AppLogger.i(TAG, "Camera stopped cleanly.")
    }

    private fun releaseReusableBuffers() {
        synchronized(bitmapLock) {
            reusableBitmap?.let {
                if (!it.isRecycled) it.recycle()
            }
            reusableBitmap = null
            rowScratchBuffer = null
        }
    }

    fun shutdown() {
        stopCamera()
        previewRef?.clear()
        previewRef = null
        lastLifecycleOwnerRef?.clear()
        lastLifecycleOwnerRef = null
        analysisExecutor?.shutdownNow()
        analysisExecutor = null
        releaseReusableBuffers()
    }
}
