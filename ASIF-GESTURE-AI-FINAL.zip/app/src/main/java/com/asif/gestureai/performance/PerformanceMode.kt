package com.asif.gestureai.performance

import android.util.Size

enum class PerformanceMode(
    val displayName: String,
    val description: String,
    val analysisSize: Size,
    val targetFps: Int,
    val faceIntervalMs: Long,
    val handIntervalMs: Long,
    val enableGlowEffects: Boolean,
    val maxHands: Int
) {
    BATTERY_SAVER(
        displayName = "Battery Saver",
        description = "Low inference rate (320x240), reduced effects, maximum session stamina.",
        analysisSize = Size(320, 240),
        targetFps = 12,
        faceIntervalMs = 110L,
        handIntervalMs = 100L,
        enableGlowEffects = false,
        maxHands = 1
    ),
    BALANCED(
        displayName = "Balanced",
        description = "Tuned for Symphony Inova 30: stable preview (480x360) & adaptive AI tracking.",
        analysisSize = Size(480, 360),
        targetFps = 20,
        faceIntervalMs = 66L,
        handIntervalMs = 55L,
        enableGlowEffects = true,
        maxHands = 2
    ),
    PERFORMANCE(
        displayName = "Performance",
        description = "Higher resolution (640x480) & rapid tracking with active thermal guard.",
        analysisSize = Size(640, 480),
        targetFps = 30,
        faceIntervalMs = 38L,
        handIntervalMs = 34L,
        enableGlowEffects = true,
        maxHands = 2
    )
}
