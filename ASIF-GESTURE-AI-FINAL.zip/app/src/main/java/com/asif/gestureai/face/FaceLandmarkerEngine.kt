package com.asif.gestureai.face

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.asif.gestureai.core.AppLogger
import com.asif.gestureai.core.CoordinateMapper
import com.asif.gestureai.core.UiState
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.atan2
import kotlin.math.max

data class FacePoint(val x: Float, val y: Float, val z: Float = 0f)

data class FaceTrackingResult(
    val detected: Boolean = false,
    val landmarks: List<FacePoint> = emptyList(),
    val headRollDeg: Float = 0f,
    val confidence: Float = 0f,
    val inferenceTimeMs: Long = 0L,
    /** Size of the UPRIGHT analysis image the normalized landmarks refer to (needed for FILL_CENTER mapping). */
    val imageWidth: Int = 0,
    val imageHeight: Int = 0
)

/**
 * Lifecycle-safe MediaPipe Face Landmarker wrapper.
 * Verifies asset integrity, loads face_landmarker.task once lazily, closes MPImage per frame,
 * and keeps timestamps strictly monotonic.
 */
class FaceLandmarkerEngine(private val context: Context) {

    companion object {
        private const val TAG = "FaceLandmarkerEngine"
        private const val MODEL_ASSET = "face_landmarker.task"
    }

    private val _engineState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val engineState: StateFlow<UiState<String>> = _engineState.asStateFlow()

    private val _latestResult = MutableStateFlow(FaceTrackingResult())
    val latestResult: StateFlow<FaceTrackingResult> = _latestResult.asStateFlow()

    private val initAttempted = AtomicBoolean(false)
    @Volatile
    private var landmarker: FaceLandmarker? = null
    private var lastMonotonicTimestampMs: Long = 0L

    @Synchronized
    fun ensureInitialized(): Boolean {
        if (landmarker != null) return true
        if (initAttempted.get() && _engineState.value is UiState.Error) return false
        initAttempted.set(true)
        _engineState.value = UiState.Loading

        return try {
            // Verify bundled model asset exists cleanly before JNI load
            context.assets.open(MODEL_ASSET).close()

            val baseOptions = BaseOptions.builder()
                .setModelAssetPath(MODEL_ASSET)
                .setDelegate(Delegate.CPU) // Predictable & stable on Mali-G57 without GL context churn
                .build()

            val options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.VIDEO)
                .setNumFaces(1)
                .setMinFaceDetectionConfidence(0.5f)
                .setMinFacePresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setOutputFaceBlendshapes(false)
                .build()

            landmarker = FaceLandmarker.createFromOptions(context, options)
            _engineState.value = UiState.Success("Face Landmarker Ready")
            AppLogger.i(TAG, "FaceLandmarker initialized successfully.")
            true
        } catch (t: Throwable) {
            AppLogger.e(TAG, "FaceLandmarker initialization failed", t)
            _engineState.value = UiState.Error(
                "Face model unavailable (${t.localizedMessage ?: "missing or unsupported"}).",
                recoverable = true
            )
            false
        }
    }

    fun retryInitialization() {
        initAttempted.set(false)
        ensureInitialized()
    }

    @Synchronized
    fun processFrame(
        bitmap: Bitmap,
        rotationDegrees: Int,
        isFrontCamera: Boolean,
        timestampMs: Long
    ): FaceTrackingResult {
        if (bitmap.isRecycled) return FaceTrackingResult(detected = false)
        val instance = landmarker ?: if (ensureInitialized()) landmarker else null
        if (instance == null) {
            return FaceTrackingResult(detected = false)
        }

        val start = SystemClock.elapsedRealtime()
        var mpImage: MPImage? = null
        return try {
            mpImage = BitmapImageBuilder(bitmap).build()
            val imageOptions = ImageProcessingOptions.builder()
                .setRotationDegrees(rotationDegrees)
                .build()

            val monotonicTs = max(timestampMs, lastMonotonicTimestampMs + 1L)
            lastMonotonicTimestampMs = monotonicTs

            val result = instance.detectForVideo(mpImage, imageOptions, monotonicTs)
            val faceLandmarks = result.faceLandmarks().firstOrNull()
            val elapsed = SystemClock.elapsedRealtime() - start

            if (faceLandmarks.isNullOrEmpty()) {
                val empty = FaceTrackingResult(detected = false, inferenceTimeMs = elapsed)
                _latestResult.value = empty
                empty
            } else {
                val upW = CoordinateMapper.uprightWidth(bitmap.width, bitmap.height, rotationDegrees)
                val upH = CoordinateMapper.uprightHeight(bitmap.width, bitmap.height, rotationDegrees)
                val mapped = faceLandmarks.map { lm ->
                    val mx = CoordinateMapper.mirrorX(lm.x(), isFrontCamera)
                    FacePoint(x = mx.coerceIn(0f, 1f), y = lm.y().coerceIn(0f, 1f), z = lm.z())
                }
                val roll = FaceGeometry.computeRollDegrees(mapped, upW, upH)
                val tracked = FaceTrackingResult(
                    detected = true,
                    landmarks = mapped,
                    headRollDeg = roll,
                    confidence = 0.92f,
                    inferenceTimeMs = elapsed,
                    imageWidth = upW,
                    imageHeight = upH
                )
                _latestResult.value = tracked
                tracked
            }
        } catch (t: Throwable) {
            AppLogger.w(TAG, "Face inference frame skipped", t)
            FaceTrackingResult(detected = false)
        } finally {
            runCatching { mpImage?.close() }
        }
    }

    fun clearResult() {
        _latestResult.value = FaceTrackingResult()
    }

    @Synchronized
    fun close() {
        try {
            landmarker?.close()
        } catch (e: Exception) {
            AppLogger.w(TAG, "Error closing FaceLandmarker", e)
        } finally {
            landmarker = null
            initAttempted.set(false)
            _engineState.value = UiState.Idle
            _latestResult.value = FaceTrackingResult()
        }
    }
}

/** Pure geometry helpers (JVM-testable). */
object FaceGeometry {
    /**
     * Head roll in degrees (clockwise positive, screen space). Computed in PIXEL units of the upright image
     * (normalized axes have different scales when the image is not square) and made independent of
     * front-camera mirroring: the vector always points from the left-most to the right-most eye corner,
     * so a mirrored frame no longer yields a ~180 degree roll.
     */
    fun computeRollDegrees(points: List<FacePoint>, imageWidth: Int, imageHeight: Int): Float {
        if (points.size <= 263) return 0f
        val w = if (imageWidth > 0) imageWidth.toFloat() else 1f
        val h = if (imageHeight > 0) imageHeight.toFloat() else 1f
        var dx = (points[263].x - points[33].x) * w
        var dy = (points[263].y - points[33].y) * h
        if (dx < 0f) {
            dx = -dx
            dy = -dy
        }
        return Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
    }
}
