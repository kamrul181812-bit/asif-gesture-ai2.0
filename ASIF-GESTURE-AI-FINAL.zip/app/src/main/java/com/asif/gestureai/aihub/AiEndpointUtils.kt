package com.asif.gestureai.aihub

/** Pure helpers (no Android dependencies) so URL / model-id handling is unit-testable on the JVM. */
object AiEndpointUtils {

    /**
     * Gemini's /models endpoint returns ids like "models/gemini-2.5-flash", but chat/completions expects
     * "gemini-2.5-flash". Strips a leading "models/" (case-insensitive) and surrounding whitespace.
     */
    fun normalizeModelId(raw: String): String {
        val trimmed = raw.trim()
        return if (trimmed.startsWith("models/", ignoreCase = true)) trimmed.substring("models/".length).trim() else trimmed
    }

    /** base + path with exactly one slash between, tolerant of trailing/leading slashes on either part. */
    fun joinUrl(baseUrl: String, path: String): String {
        val base = baseUrl.trim().trimEnd('/')
        val cleanPath = path.trim().trimStart('/')
        return if (cleanPath.isEmpty()) base else "$base/$cleanPath"
    }

    fun chatUrl(baseUrl: String, chatPath: String): String = joinUrl(baseUrl, chatPath)

    fun modelsUrl(baseUrl: String): String = joinUrl(baseUrl, "models")

    /** Human-readable explanation for an HTTP failure; never includes the API key. */
    fun describeHttpError(code: Int, providerMessage: String): String {
        val detail = providerMessage.trim().take(220)
        val suffix = if (detail.isBlank()) "" else " — $detail"
        return when (code) {
            400 -> "Bad request (HTTP 400): the provider rejected the request body or model name$suffix"
            401 -> "Unauthorized (HTTP 401): the API key is missing or invalid$suffix"
            403 -> "Forbidden (HTTP 403): the key has no access to this model or API$suffix"
            404 -> "Not found (HTTP 404): check the Base URL, chat path and model name$suffix"
            429 -> "Rate limited (HTTP 429): quota exceeded or too many requests, retry later$suffix"
            in 500..599 -> "Provider server error (HTTP $code): try again shortly$suffix"
            else -> "HTTP $code$suffix"
        }
    }
}
