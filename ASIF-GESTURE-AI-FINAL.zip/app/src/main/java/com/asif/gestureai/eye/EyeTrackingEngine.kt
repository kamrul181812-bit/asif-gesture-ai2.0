package com.asif.gestureai.eye

import com.asif.gestureai.face.FacePoint
import com.asif.gestureai.face.FaceTrackingResult
import com.asif.gestureai.settings.EyeTrackingSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.hypot

enum class GazeZone(val label: String) {
    CENTER("Center"),
    LEFT("Looking Left"),
    RIGHT("Looking Right"),
    UP("Looking Up"),
    DOWN("Looking Down"),
    UNAVAILABLE("Tracking Lost")
}

enum class LightingQuality(val label: String, val isAdequate: Boolean) {
    GOOD("Good Lighting", true),
    LOW("Low Light (Reduce Glare)", false),
    OVEREXPOSED("Too Bright", false)
}

data class EyeTrackingState(
    val detected: Boolean = false,
    val gazeX: Float = 0.5f, // 0..1 normalized within eye box
    val gazeY: Float = 0.5f,
    val gazeZone: GazeZone = GazeZone.UNAVAILABLE,
    val confidence: Float = 0f,
    val blinkDetected: Boolean = false,
    val lightingQuality: LightingQuality = LightingQuality.GOOD,
    val dwellProgress: Float = 0f
)

/**
 * Estimates gaze direction and blink events from MediaPipe Face Landmarker + Iris landmarks (468..477).
 * Includes smoothing for glasses tolerance, lighting quality check, and calibration offsets.
 */
class EyeTrackingEngine {

    private val _state = MutableStateFlow(EyeTrackingState())
    val state: StateFlow<EyeTrackingState> = _state.asStateFlow()

    private var smoothX = 0.5f
    private var smoothY = 0.5f
    private var lastBlinkTs = 0L
    private var zoneEnterTs = 0L
    private var lastZone = GazeZone.CENTER

    fun update(
        face: FaceTrackingResult,
        avgLuminance: Float,
        settings: EyeTrackingSettings,
        nowMs: Long
    ): EyeTrackingState {
        val lighting = when {
            avgLuminance < 0.18f -> LightingQuality.LOW
            avgLuminance > 0.88f -> LightingQuality.OVEREXPOSED
            else -> LightingQuality.GOOD
        }

        if (!settings.enabled || !face.detected || face.landmarks.size < 478) {
            val lost = EyeTrackingState(
                detected = false,
                gazeZone = GazeZone.UNAVAILABLE,
                confidence = 0f,
                lightingQuality = lighting
            )
            _state.value = lost
            return lost
        }

        val pts = face.landmarks
        // Left eye corners (33, 133), eyelids (159, 145), iris center (468)
        // Right eye corners (362, 263), eyelids (386, 374), iris center (473)
        val lOuter = pts[33]
        val lInner = pts[133]
        val lTop = pts[159]
        val lBottom = pts[145]
        val lIris = pts[468]

        val rInner = pts[362]
        val rOuter = pts[263]
        val rTop = pts[386]
        val rBottom = pts[374]
        val rIris = pts[473]

        val lWidth = abs(lInner.x - lOuter.x).coerceAtLeast(0.005f)
        val rWidth = abs(rOuter.x - rInner.x).coerceAtLeast(0.005f)
        val lHeight = abs(lBottom.y - lTop.y).coerceAtLeast(0.003f)
        val rHeight = abs(rBottom.y - rTop.y).coerceAtLeast(0.003f)

        val lNormX = ((lIris.x - minOf(lOuter.x, lInner.x)) / lWidth).coerceIn(0f, 1f)
        val rNormX = ((rIris.x - minOf(rInner.x, rOuter.x)) / rWidth).coerceIn(0f, 1f)
        val rawX = (lNormX + rNormX) * 0.5f

        val lNormY = ((lIris.y - minOf(lTop.y, lBottom.y)) / lHeight).coerceIn(0f, 1f)
        val rNormY = ((rIris.y - minOf(rTop.y, rBottom.y)) / rHeight).coerceIn(0f, 1f)
        val rawY = (lNormY + rNormY) * 0.5f

        // Smooth to handle glasses reflections & micro-jitter
        val alpha = (0.22f + settings.sensitivity * 0.25f).coerceIn(0.15f, 0.55f)
        smoothX += (rawX - smoothX) * alpha
        smoothY += (rawY - smoothY) * alpha

        // Eye Aspect Ratio for blink detection
        val lEar = distance(lTop, lBottom) / lWidth
        val rEar = distance(rTop, rBottom) / rWidth
        val avgEar = (lEar + rEar) * 0.5f
        val isBlink = avgEar < 0.16f && (nowMs - lastBlinkTs > 450L)
        if (isBlink) lastBlinkTs = nowMs

        val dx = smoothX - settings.centerOffsetX
        val dy = smoothY - settings.centerOffsetY
        val threshX = (settings.horizontalRange * (1.3f - settings.sensitivity * 0.6f)).coerceIn(0.04f, 0.25f)
        val threshY = (settings.verticalRange * (1.3f - settings.sensitivity * 0.6f)).coerceIn(0.04f, 0.25f)

        val zone = when {
            abs(dx) > abs(dy) && dx < -threshX -> GazeZone.LEFT
            abs(dx) > abs(dy) && dx > threshX -> GazeZone.RIGHT
            abs(dy) >= abs(dx) && dy < -threshY -> GazeZone.UP
            abs(dy) >= abs(dx) && dy > threshY -> GazeZone.DOWN
            else -> GazeZone.CENTER
        }

        if (zone != lastZone) {
            lastZone = zone
            zoneEnterTs = nowMs
        }
        val dwell = if (zone == GazeZone.UP || zone == GazeZone.DOWN) {
            ((nowMs - zoneEnterTs).toFloat() / 900f).coerceIn(0f, 1f)
        } else {
            0f
        }

        val confidence = ((if (lighting.isAdequate) 0.9f else 0.55f) *
            ((lWidth + rWidth) * 12f).coerceIn(0.4f, 1.0f)).coerceIn(0f, 0.99f)

        val newState = EyeTrackingState(
            detected = true,
            gazeX = smoothX,
            gazeY = smoothY,
            gazeZone = zone,
            confidence = confidence,
            blinkDetected = isBlink,
            lightingQuality = lighting,
            dwellProgress = dwell
        )
        _state.value = newState
        return newState
    }

    private fun distance(a: FacePoint, b: FacePoint): Float {
        return hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat()
    }

    fun reset() {
        smoothX = 0.5f
        smoothY = 0.5f
        _state.value = EyeTrackingState()
    }
}
