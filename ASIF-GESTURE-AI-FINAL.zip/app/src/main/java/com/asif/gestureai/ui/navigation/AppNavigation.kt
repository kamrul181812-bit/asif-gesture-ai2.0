package com.asif.gestureai.ui.navigation

import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.FaceRetouchingNatural
import androidx.compose.material.icons.outlined.FrontHand
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.FaceRetouchingNatural
import androidx.compose.material.icons.rounded.FrontHand
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.asif.gestureai.camera.CameraStatus
import com.asif.gestureai.core.PermissionHelper
import com.asif.gestureai.settings.FloatingVisibilityMode
import com.asif.gestureai.ui.AppEvent
import com.asif.gestureai.ui.MainViewModel
import com.asif.gestureai.ui.screens.AiHubScreen
import com.asif.gestureai.ui.screens.CameraStudioScreen
import com.asif.gestureai.ui.screens.DashboardScreen
import com.asif.gestureai.ui.screens.GestureMouseScreen
import com.asif.gestureai.ui.screens.SettingsHubScreen
import com.asif.gestureai.voice.SoundCue
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

@Serializable
sealed interface AppRoute {
    @Serializable data object Dashboard : AppRoute
    @Serializable data object CameraStudio : AppRoute
    @Serializable data class GestureControl(val initialTab: Int = 0) : AppRoute
    @Serializable data object AiHub : AppRoute
    @Serializable data object SettingsHub : AppRoute
}

private data class NavTabItem(
    val label: String,
    val route: AppRoute,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@Composable
fun AsifGestureAiRoot(
    viewModel: MainViewModel,
    lifecycleOwner: LifecycleOwner,
    isInPipMode: Boolean,
    previewViewHolder: (PreviewView?) -> Unit,
    currentPreviewView: () -> PreviewView?,
    onRequestPermissions: () -> Unit,
    onEnterPip: () -> Unit
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val telemetry by viewModel.performanceTelemetry.collectAsStateWithLifecycle()
    val cameraStatus by viewModel.cameraStatus.collectAsStateWithLifecycle()
    val faceResult by viewModel.faceResult.collectAsStateWithLifecycle()
    val handResult by viewModel.handResult.collectAsStateWithLifecycle()
    val gestureState by viewModel.gestureLiveState.collectAsStateWithLifecycle()
    val eyeState by viewModel.eyeState.collectAsStateWithLifecycle()
    val mouseState by viewModel.mouseState.collectAsStateWithLifecycle()
    val reelsState by viewModel.reelsState.collectAsStateWithLifecycle()
    val accessibilityStatus by viewModel.accessibilityStatus.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()
    val floatingState by viewModel.floatingState.collectAsStateWithLifecycle()
    val voiceStatus by viewModel.voiceStatus.collectAsStateWithLifecycle()
    val providers by viewModel.providers.collectAsStateWithLifecycle()
    val sessions by viewModel.chatSessions.collectAsStateWithLifecycle()
    val selectedSessionId by viewModel.selectedSessionId.collectAsStateWithLifecycle()
    val messages by viewModel.activeMessages.collectAsStateWithLifecycle()
    val streamingText by viewModel.streamingAssistantText.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGeneratingChat.collectAsStateWithLifecycle()
    val isTestingApi by viewModel.isTestingApi.collectAsStateWithLifecycle()
    val setupValidation by viewModel.setupValidation.collectAsStateWithLifecycle()
    val gestureHistory by viewModel.gestureHistory.collectAsStateWithLifecycle()
    val savedMasks by viewModel.customMasks.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.events.collect { evt ->
            when (evt) {
                is AppEvent.ToastMessage -> snackbarHostState.showSnackbar(evt.text)
                AppEvent.NavigateToAiHub -> navController.navigate(AppRoute.AiHub) {
                    launchSingleTop = true
                }
            }
        }
    }

    val navItems = listOf(
        NavTabItem("HUD", AppRoute.Dashboard, Icons.Rounded.Dashboard, Icons.Outlined.Dashboard),
        NavTabItem("Camera", AppRoute.CameraStudio, Icons.Rounded.FaceRetouchingNatural, Icons.Outlined.FaceRetouchingNatural),
        NavTabItem("Control", AppRoute.GestureControl(0), Icons.Rounded.FrontHand, Icons.Outlined.FrontHand),
        NavTabItem("AI Hub", AppRoute.AiHub, Icons.Rounded.AutoAwesome, Icons.Outlined.AutoAwesome),
        NavTabItem("Settings", AppRoute.SettingsHub, Icons.Rounded.Settings, Icons.Outlined.Settings)
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = navBackStackEntry?.destination

    fun navigateTop(route: AppRoute) {
        viewModel.soundEngine.playCue(SoundCue.BUTTON, settings.voiceSound)
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun toggleCameraAction() {
        if (cameraStatus is CameraStatus.Running) {
            viewModel.stopCamera()
        } else {
            viewModel.refreshPermissions()
            if (!PermissionHelper.snapshot(context).cameraGranted) {
                onRequestPermissions()
            } else {
                viewModel.startCamera(lifecycleOwner, currentPreviewView())
            }
        }
    }

    if (isInPipMode) {
        // Minimal clean PiP window showing Live Camera + Mask/Hand overlay
        com.asif.gestureai.ui.components.CameraViewportSurface(
            cameraStatus = cameraStatus,
            faceResult = faceResult,
            handResult = handResult,
            maskSettings = settings.mask,
            mouseState = mouseState,
            mouseSettings = settings.virtualMouse,
            showLandmarks = true,
            onPreviewViewCreated = { pv ->
                previewViewHolder(pv)
                viewModel.reattachCameraPreview(lifecycleOwner, pv)
            },
            modifier = Modifier.fillMaxSize()
        )
        return
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 680.dp

        Scaffold(
            containerColor = ObsidianBlack,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = DeepSlate,
                        modifier = Modifier.navigationBarsPadding()
                    ) {
                        navItems.forEach { item ->
                            val selected = when (item.route) {
                                AppRoute.Dashboard -> currentDest?.hasRoute<AppRoute.Dashboard>() == true
                                AppRoute.CameraStudio -> currentDest?.hasRoute<AppRoute.CameraStudio>() == true
                                is AppRoute.GestureControl -> currentDest?.hasRoute<AppRoute.GestureControl>() == true
                                AppRoute.AiHub -> currentDest?.hasRoute<AppRoute.AiHub>() == true
                                AppRoute.SettingsHub -> currentDest?.hasRoute<AppRoute.SettingsHub>() == true
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTop(item.route) },
                                icon = {
                                    Icon(
                                        if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ObsidianBlack,
                                    selectedTextColor = NeonEmerald,
                                    indicatorColor = NeonEmerald,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(containerColor = DeepSlate) {
                        navItems.forEach { item ->
                            val selected = when (item.route) {
                                AppRoute.Dashboard -> currentDest?.hasRoute<AppRoute.Dashboard>() == true
                                AppRoute.CameraStudio -> currentDest?.hasRoute<AppRoute.CameraStudio>() == true
                                is AppRoute.GestureControl -> currentDest?.hasRoute<AppRoute.GestureControl>() == true
                                AppRoute.AiHub -> currentDest?.hasRoute<AppRoute.AiHub>() == true
                                AppRoute.SettingsHub -> currentDest?.hasRoute<AppRoute.SettingsHub>() == true
                            }
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTop(item.route) },
                                icon = {
                                    Icon(
                                        if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = ObsidianBlack,
                                    selectedTextColor = ElectricBlue,
                                    indicatorColor = ElectricBlue,
                                    unselectedIconColor = TextSecondary
                                )
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = AppRoute.Dashboard,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<AppRoute.Dashboard> {
                        DashboardScreen(
                            settings = settings,
                            cameraStatus = cameraStatus,
                            faceResult = faceResult,
                            handResult = handResult,
                            gestureState = gestureState,
                            eyeState = eyeState,
                            mouseState = mouseState,
                            telemetry = telemetry,
                            accessibilityStatus = accessibilityStatus,
                            permissions = permissions,
                            onPreviewViewCreated = { pv ->
                                previewViewHolder(pv)
                                viewModel.reattachCameraPreview(lifecycleOwner, pv)
                            },
                            onStartStopCamera = ::toggleCameraAction,
                            onSwitchCamera = { viewModel.switchCameraLens(lifecycleOwner, currentPreviewView()) },
                            onToggleMask = { viewModel.toggleMask(!settings.mask.enabled) },
                            onEnterPip = onEnterPip,
                            onStartFloatingVisible = {
                                if (!PermissionHelper.snapshot(context).overlayGranted) {
                                    PermissionHelper.openOverlaySettings(context)
                                } else {
                                    viewModel.startFloatingMode(FloatingVisibilityMode.VISIBLE)
                                }
                            },
                            onEmergencyStop = viewModel::emergencyStopAll,
                            onNavigateToCameraStudio = { navigateTop(AppRoute.CameraStudio) },
                            onNavigateToGestures = { navigateTop(AppRoute.GestureControl(0)) },
                            onNavigateToReels = { navController.navigate(AppRoute.GestureControl(2)) },
                            onNavigateToVirtualMouse = { navController.navigate(AppRoute.GestureControl(1)) },
                            onNavigateToAiHub = { navigateTop(AppRoute.AiHub) },
                            onNavigateToSettings = { navigateTop(AppRoute.SettingsHub) }
                        )
                    }

                    composable<AppRoute.CameraStudio> {
                        CameraStudioScreen(
                            cameraStatus = cameraStatus,
                            cameraSettings = settings.camera,
                            maskSettings = settings.mask,
                            faceResult = faceResult,
                            handResult = handResult,
                            mouseState = mouseState,
                            mouseSettings = settings.virtualMouse,
                            savedMasks = savedMasks,
                            onPreviewViewCreated = { pv ->
                                previewViewHolder(pv)
                                viewModel.reattachCameraPreview(lifecycleOwner, pv)
                            },
                            onStartStopCamera = ::toggleCameraAction,
                            onSwitchLens = { viewModel.switchCameraLens(lifecycleOwner, currentPreviewView()) },
                            onUpdateCameraSettings = { block ->
                                coroutineScope.launch { viewModel.preferences.updateCamera(block) }
                            },
                            onUpdateMaskSettings = { block ->
                                coroutineScope.launch { viewModel.preferences.updateMask(block) }
                            },
                            onSaveCustomMask = viewModel::saveCustomMaskPreset,
                            onApplySavedMask = viewModel::applySavedMask
                        )
                    }

                    composable<AppRoute.GestureControl> { backStack ->
                        val args = backStack.toRoute<AppRoute.GestureControl>()
                        GestureMouseScreen(
                            initialTab = args.initialTab,
                            settings = settings,
                            gestureLiveState = gestureState,
                            gestureHistory = gestureHistory,
                            eyeState = eyeState,
                            mouseState = mouseState,
                            reelsState = reelsState,
                            accessibilityStatus = accessibilityStatus,
                            onUpdateGesture = { b -> coroutineScope.launch { viewModel.preferences.updateGesture(b) } },
                            onUpdateMouse = { b -> coroutineScope.launch { viewModel.preferences.updateVirtualMouse(b) } },
                            onUpdateReels = { b -> coroutineScope.launch { viewModel.preferences.updateReels(b) } },
                            onUpdateEye = { b -> coroutineScope.launch { viewModel.preferences.updateEyeTracking(b) } },
                            onCalibrateEyeCenter = viewModel::calibrateEyeCenter,
                            onCalibrateGesture = viewModel::calibrateGestureBaseline,
                            onToggleReelsMode = viewModel::toggleReelsMode,
                            onOpenAccessibilitySettings = { PermissionHelper.openAccessibilitySettings(context) },
                            onEmergencyStop = viewModel::emergencyStopAll
                        )
                    }

                    composable<AppRoute.AiHub> {
                        AiHubScreen(
                            providers = providers,
                            sessions = sessions,
                            selectedSessionId = selectedSessionId,
                            messages = messages,
                            streamingText = streamingText,
                            isGenerating = isGenerating,
                            isTestingApi = isTestingApi,
                            setupValidation = setupValidation,
                            onSelectSession = viewModel::selectSession,
                            onNewChat = viewModel::startNewChat,
                            onRenameSession = { id, title ->
                                coroutineScope.launch { viewModel.aiRepository.renameSession(id, title) }
                            },
                            onClearSession = { id ->
                                coroutineScope.launch { viewModel.aiRepository.clearSessionMessages(id) }
                            },
                            onDeleteSession = { id ->
                                coroutineScope.launch {
                                    viewModel.aiRepository.deleteSession(id)
                                    viewModel.selectSession(null)
                                }
                            },
                            onSendPrompt = viewModel::sendChatMessage,
                            onRegenerate = viewModel::regenerateLastResponse,
                            onStopGeneration = viewModel::stopGeneration,
                            onTestAndSaveProvider = viewModel::testAndSaveProvider,
                            onDeleteProviderKey = { id ->
                                coroutineScope.launch { viewModel.aiRepository.deleteProviderKeyOnly(id) }
                            },
                            onDeleteProvider = { id ->
                                coroutineScope.launch { viewModel.aiRepository.deleteProvider(id) }
                            }
                        )
                    }

                    composable<AppRoute.SettingsHub> {
                        SettingsHubScreen(
                            settings = settings,
                            telemetry = telemetry,
                            cameraStatus = cameraStatus,
                            permissions = permissions,
                            accessibilityStatus = accessibilityStatus,
                            floatingState = floatingState,
                            voiceStatus = voiceStatus,
                            savedProvidersCount = providers.size,
                            onSelectPerformanceMode = viewModel::setPerformanceMode,
                            onUpdatePerformancePrefs = { b -> coroutineScope.launch { viewModel.preferences.updatePerformance(b) } },
                            onUpdateFloating = { b -> coroutineScope.launch { viewModel.preferences.updateFloating(b) } },
                            onStartFloatingMode = { mode ->
                                if (mode != FloatingVisibilityMode.HIDDEN_PANEL && !PermissionHelper.snapshot(context).overlayGranted) {
                                    PermissionHelper.openOverlaySettings(context)
                                } else {
                                    viewModel.startFloatingMode(mode)
                                }
                            },
                            onStopFloating = { com.asif.gestureai.service.FloatingControlService.stop(context) },
                            onEnterPip = onEnterPip,
                            onToggleVoiceListening = {
                                if (voiceStatus.isListening) {
                                    viewModel.voiceManager.stopListening()
                                } else if (!PermissionHelper.snapshot(context).microphoneGranted) {
                                    onRequestPermissions()
                                } else {
                                    viewModel.voiceManager.startListening()
                                }
                            },
                            onUpdateVoiceSound = { b -> coroutineScope.launch { viewModel.preferences.updateVoiceSound(b) } },
                            onTestSoundCue = { viewModel.soundEngine.playCue(SoundCue.GESTURE, settings.voiceSound) },
                            onRequestRuntimePermissions = onRequestPermissions,
                            onOpenOverlaySettings = { PermissionHelper.openOverlaySettings(context) },
                            onOpenAccessibilitySettings = { PermissionHelper.openAccessibilitySettings(context) },
                            onOpenAppInfo = { PermissionHelper.openAppSettings(context) },
                            restrictedSettingsLikely = PermissionHelper.restrictedSettingsLikely(context),
                            onEmergencyStopAll = viewModel::emergencyStopAll,
                            onClearAllLocalData = viewModel::clearLocalConfiguration
                        )
                    }
                }
            }
        }
    }
}
