package com.asif.gestureai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.KeyOff
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.asif.gestureai.aihub.AiAdapterType
import com.asif.gestureai.aihub.AiSetupValidationResult
import com.asif.gestureai.data.local.AiProviderEntity
import com.asif.gestureai.data.local.ChatMessageEntity
import com.asif.gestureai.data.local.ChatSessionEntity
import com.asif.gestureai.ui.components.GlassCard
import com.asif.gestureai.ui.components.StatusPill
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextSecondary

@Composable
fun AiHubScreen(
    providers: List<AiProviderEntity>,
    sessions: List<ChatSessionEntity>,
    selectedSessionId: Long?,
    messages: List<ChatMessageEntity>,
    streamingText: String?,
    isGenerating: Boolean,
    isTestingApi: Boolean,
    setupValidation: AiSetupValidationResult?,
    onSelectSession: (Long?) -> Unit,
    onNewChat: (AiProviderEntity) -> Unit,
    onRenameSession: (Long, String) -> Unit,
    onClearSession: (Long) -> Unit,
    onDeleteSession: (Long) -> Unit,
    onSendPrompt: (String, AiProviderEntity) -> Unit,
    onRegenerate: (AiProviderEntity) -> Unit,
    onStopGeneration: () -> Unit,
    onTestAndSaveProvider: (
        existingId: Long,
        name: String,
        adapterType: AiAdapterType,
        baseUrl: String,
        chatPath: String,
        apiKey: String,
        modelName: String,
        customHeadersJson: String,
        temperature: Float,
        maxContextMessages: Int
    ) -> Unit,
    onDeleteProviderKey: (Long) -> Unit,
    onDeleteProvider: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember(providers.isEmpty()) { mutableIntStateOf(if (providers.isEmpty()) 1 else 0) }
    var selectedProviderId by remember(providers) { mutableLongStateOf(providers.firstOrNull()?.id ?: 0L) }
    val activeProvider = providers.firstOrNull { it.id == selectedProviderId } ?: providers.firstOrNull()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DeepSlate,
                contentColor = NeonEmerald
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("AI Chat", style = MaterialTheme.typography.labelLarge) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("API Setup Hub", style = MaterialTheme.typography.labelLarge) }
                )
            }

            if (selectedTab == 0) {
                AiChatTab(
                    providers = providers,
                    activeProvider = activeProvider,
                    onSelectProvider = { selectedProviderId = it.id },
                    sessions = sessions,
                    selectedSessionId = selectedSessionId,
                    messages = messages,
                    streamingText = streamingText,
                    isGenerating = isGenerating,
                    onSelectSession = onSelectSession,
                    onNewChat = onNewChat,
                    onRenameSession = onRenameSession,
                    onClearSession = onClearSession,
                    onDeleteSession = onDeleteSession,
                    onSendPrompt = onSendPrompt,
                    onRegenerate = onRegenerate,
                    onStopGeneration = onStopGeneration,
                    onOpenSetup = { selectedTab = 1 }
                )
            } else {
                ApiSetupTab(
                    providers = providers,
                    isTesting = isTestingApi,
                    validationResult = setupValidation,
                    onTestAndSave = onTestAndSaveProvider,
                    onDeleteKey = onDeleteProviderKey,
                    onDeleteProvider = onDeleteProvider
                )
            }
        }
    }
}

@Composable
private fun AiChatTab(
    providers: List<AiProviderEntity>,
    activeProvider: AiProviderEntity?,
    onSelectProvider: (AiProviderEntity) -> Unit,
    sessions: List<ChatSessionEntity>,
    selectedSessionId: Long?,
    messages: List<ChatMessageEntity>,
    streamingText: String?,
    isGenerating: Boolean,
    onSelectSession: (Long?) -> Unit,
    onNewChat: (AiProviderEntity) -> Unit,
    onRenameSession: (Long, String) -> Unit,
    onClearSession: (Long) -> Unit,
    onDeleteSession: (Long) -> Unit,
    onSendPrompt: (String, AiProviderEntity) -> Unit,
    onRegenerate: (AiProviderEntity) -> Unit,
    onStopGeneration: () -> Unit,
    onOpenSetup: () -> Unit
) {
    var promptText by remember { mutableStateOf("") }
    var renameText by remember { mutableStateOf("") }
    var showRenameRow by remember { mutableStateOf(false) }

    if (activeProvider == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GlassCard {
                Text("No AI API Provider Connected", style = MaterialTheme.typography.titleLarge, color = NeonEmerald)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Connect your own OpenAI, Gemini OpenAI-compat, Anthropic, or custom REST API credential in API Setup Hub. Camera and gesture features work independently without any AI API.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                Spacer(Modifier.height(14.dp))
                Button(onClick = onOpenSetup, modifier = Modifier.fillMaxWidth()) {
                    Text("Launch API Setup Assistant")
                }
            }
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Provider & Session Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(providers) { p ->
                    FilterChip(
                        selected = p.id == activeProvider.id,
                        onClick = { onSelectProvider(p) },
                        label = { Text("${p.name} (${p.modelName})", style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            IconButton(onClick = { onNewChat(activeProvider) }) {
                Icon(Icons.Rounded.Add, contentDescription = "New chat", tint = NeonEmerald)
            }
        }

        // Session Selector Row
        if (sessions.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(sessions) { s ->
                    FilterChip(
                        selected = s.id == selectedSessionId,
                        onClick = { onSelectSession(s.id) },
                        label = { Text(s.title, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
        }

        if (selectedSessionId != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = { showRenameRow = !showRenameRow }) {
                    Text("Rename", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = { onClearSession(selectedSessionId) }) {
                    Text("Clear", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(onClick = { onDeleteSession(selectedSessionId) }) {
                    Text("Delete", style = MaterialTheme.typography.labelSmall, color = AlertCrimson)
                }
            }
        }

        if (showRenameRow && selectedSessionId != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    label = { Text("Conversation Title") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(onClick = {
                    onRenameSession(selectedSessionId, renameText)
                    showRenameRow = false
                }) { Text("Save") }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
            Icon(Icons.Rounded.Lock, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text(
                "Only messages you submit are sent to ${activeProvider.name}. Camera & screen data stay local.",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }

        // Messages List
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                ChatMessageBubble(role = msg.role, content = msg.content)
            }
            if (streamingText != null) {
                item(key = "streaming_bubble") {
                    ChatMessageBubble(
                        role = "assistant",
                        content = streamingText.ifBlank { "Generating response..." }
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Prompt Input & Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = promptText,
                onValueChange = { promptText = it },
                placeholder = { Text("Ask ${activeProvider.modelName}...") },
                maxLines = 4,
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_chat_input")
            )
            if (isGenerating) {
                IconButton(
                    onClick = onStopGeneration,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(AlertCrimson.copy(alpha = 0.2f))
                        .testTag("ai_stop_button")
                ) {
                    Icon(Icons.Rounded.Stop, contentDescription = "Stop generation", tint = AlertCrimson)
                }
            } else {
                IconButton(
                    onClick = {
                        if (promptText.isNotBlank()) {
                            onSendPrompt(promptText, activeProvider)
                            promptText = ""
                        }
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(NeonEmerald.copy(alpha = 0.2f))
                        .testTag("ai_send_button")
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = "Send prompt", tint = NeonEmerald)
                }
            }
        }

        if (messages.isNotEmpty() && !isGenerating) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(onClick = { onRegenerate(activeProvider) }) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Regenerate", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(role: String, content: String) {
    val isUser = role == "user"
    val clipboard = LocalClipboardManager.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(if (isUser) ElectricBlue.copy(alpha = 0.14f) else DeepSlate)
            .border(
                1.dp,
                if (isUser) ElectricBlue.copy(alpha = 0.35f) else NeonEmerald.copy(alpha = 0.22f),
                MaterialTheme.shapes.medium
            )
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isUser) "YOU" else "ASSISTANT",
                style = MaterialTheme.typography.labelSmall,
                color = if (isUser) ElectricBlue else NeonEmerald
            )
            IconButton(
                onClick = { clipboard.setText(AnnotatedString(content)) },
                modifier = Modifier.size(28.dp)
            ) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy response", tint = TextSecondary, modifier = Modifier.size(16.dp))
            }
        }
        Spacer(Modifier.height(4.dp))

        // Render Markdown-style fenced code blocks distinctly from prose
        val segments = remember(content) { content.split("```") }
        segments.forEachIndexed { idx, segment ->
            if (idx % 2 == 1) {
                val lines = segment.lines()
                val codeBody = if (lines.size > 1 && lines.first().length < 20) {
                    lines.drop(1).joinToString("\n")
                } else segment
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(ObsidianBlack)
                        .padding(10.dp)
                ) {
                    Text(
                        text = codeBody.trim(),
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = NeonEmerald
                    )
                }
            } else if (segment.isNotBlank()) {
                Text(
                    text = segment.trim(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ApiSetupTab(
    providers: List<AiProviderEntity>,
    isTesting: Boolean,
    validationResult: AiSetupValidationResult?,
    onTestAndSave: (Long, String, AiAdapterType, String, String, String, String, String, Float, Int) -> Unit,
    onDeleteKey: (Long) -> Unit,
    onDeleteProvider: (Long) -> Unit
) {
    var editingId by remember { mutableLongStateOf(0L) }
    var adapter by remember { mutableStateOf(AiAdapterType.OPENAI_COMPATIBLE) }
    var name by remember { mutableStateOf("My AI Provider") }
    var baseUrl by remember { mutableStateOf(adapter.defaultBaseUrl) }
    var chatPath by remember { mutableStateOf(adapter.defaultChatPath) }
    var modelName by remember { mutableStateOf(adapter.defaultModel) }
    var apiKey by remember { mutableStateOf("") }
    var customHeaders by remember { mutableStateOf("{}") }
    var temperature by remember { mutableFloatStateOf(0.7f) }
    var maxContext by remember { mutableIntStateOf(12) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        GlassCard(borderColor = NeonEmerald.copy(alpha = 0.4f)) {
            Text("Automatic API Setup Assistant", style = MaterialTheme.typography.titleMedium, color = NeonEmerald)
            Spacer(Modifier.height(4.dp))
            Text(
                "Select a compatible adapter, enter your endpoint and key, and run a real live test. Keys are encrypted via Android Keystore and never logged.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
            Spacer(Modifier.height(10.dp))

            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                AiAdapterType.entries.forEach { type ->
                    FilterChip(
                        selected = adapter == type,
                        onClick = {
                            adapter = type
                            baseUrl = type.defaultBaseUrl
                            chatPath = type.defaultChatPath
                            modelName = type.defaultModel
                        },
                        label = { Text(type.displayName, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(adapter.formatNote, style = MaterialTheme.typography.bodySmall, color = ElectricBlue)

            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Display Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = chatPath, onValueChange = { chatPath = it }, label = { Text("Chat Endpoint Path") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = modelName, onValueChange = { modelName = it }, label = { Text("Model Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API Key (Keystore Encrypted)") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("api_key_input")
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = customHeaders,
                onValueChange = { customHeaders = it },
                label = { Text("Optional Custom Headers (JSON)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Text("Temperature: ${String.format("%.2f", temperature)}", style = MaterialTheme.typography.labelSmall)
            Slider(value = temperature, onValueChange = { temperature = it }, valueRange = 0.0f..1.5f)
            Text("Context History Window: $maxContext messages", style = MaterialTheme.typography.labelSmall)
            Slider(value = maxContext.toFloat(), onValueChange = { maxContext = it.toInt() }, valueRange = 2f..24f)

            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    onTestAndSave(editingId, name, adapter, baseUrl, chatPath, apiKey, modelName, customHeaders, temperature, maxContext)
                },
                enabled = !isTesting,
                modifier = Modifier.fillMaxWidth().testTag("test_save_api_button")
            ) {
                if (isTesting) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = ObsidianBlack)
                    Spacer(Modifier.width(8.dp))
                    Text("Validating Endpoint & Auth...")
                } else {
                    Text("Validate, Test & Save Provider")
                }
            }

            validationResult?.let { res ->
                Spacer(Modifier.height(10.dp))
                GlassCard(
                    borderColor = if (res.success) NeonEmerald else AlertCrimson
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            tint = if (res.success) NeonEmerald else AlertCrimson
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            res.statusMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (res.success) NeonEmerald else AlertCrimson
                        )
                    }
                    if (res.discoveredModels.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Detected Models (tap to select):", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            res.discoveredModels.take(10).forEach { m ->
                                FilterChip(
                                    selected = modelName == m,
                                    onClick = { modelName = m },
                                    label = { Text(m, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (providers.isNotEmpty()) {
            Text("Saved AI Providers", style = MaterialTheme.typography.titleSmall, color = ElectricBlue)
            providers.forEach { p ->
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleSmall)
                            Text("${p.modelName} • ${p.baseUrl}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Spacer(Modifier.height(4.dp))
                            StatusPill(p.lastStatusMessage.take(34), p.isVerified)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            editingId = p.id
                            name = p.name
                            adapter = runCatching { AiAdapterType.valueOf(p.adapterType) }.getOrDefault(AiAdapterType.OPENAI_COMPATIBLE)
                            baseUrl = p.baseUrl
                            chatPath = p.chatEndpointPath
                            modelName = p.modelName
                            customHeaders = p.customHeadersJson
                            temperature = p.temperature
                            maxContext = p.maxContextMessages
                        }) { Text("Edit", style = MaterialTheme.typography.labelSmall) }
                        OutlinedButton(onClick = { onDeleteKey(p.id) }) {
                            Icon(Icons.Rounded.KeyOff, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Delete Key", style = MaterialTheme.typography.labelSmall, color = CyberAmber)
                        }
                        OutlinedButton(onClick = { onDeleteProvider(p.id) }) {
                            Icon(Icons.Rounded.Delete, null, modifier = Modifier.size(16.dp), tint = AlertCrimson)
                        }
                    }
                }
            }
        }
    }
}
