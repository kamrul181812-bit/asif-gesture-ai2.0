package com.asif.gestureai.core

import android.util.Log

/**
 * Redacting logger that prevents API keys, bearer tokens, or private user payloads
 * from ever being emitted to Android Logcat.
 */
object AppLogger {
    private const val PREFIX = "AsifGestureAI"
    private val secretPatterns = listOf(
        Regex("Bearer\\s+[A-Za-z0-9\\-._~+/]+=*", RegexOption.IGNORE_CASE),
        Regex("(sk-[A-Za-z0-9\\-_]{8,})"),
        Regex("(AIza[0-9A-Za-z\\-_]{16,})"),
        Regex("(\"api_key\"|\"apiKey\"|\"x-api-key\"|\"Authorization\")\\s*[:=]\\s*\"?[^\"\\s,}]+", RegexOption.IGNORE_CASE)
    )

    fun redact(message: String): String {
        var sanitized = message
        for (regex in secretPatterns) {
            sanitized = regex.replace(sanitized) { match ->
                val head = match.value.take(8)
                "$head***REDACTED***"
            }
        }
        return sanitized
    }

    fun d(tag: String, message: String) {
        Log.d("$PREFIX/$tag", redact(message))
    }

    fun i(tag: String, message: String) {
        Log.i("$PREFIX/$tag", redact(message))
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        if (throwable != null) {
            Log.w("$PREFIX/$tag", redact(message), throwable)
        } else {
            Log.w("$PREFIX/$tag", redact(message))
        }
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (throwable != null) {
            Log.e("$PREFIX/$tag", redact(message), throwable)
        } else {
            Log.e("$PREFIX/$tag", redact(message))
        }
    }
}
