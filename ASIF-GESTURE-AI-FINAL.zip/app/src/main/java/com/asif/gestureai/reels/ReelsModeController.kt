package com.asif.gestureai.reels

import com.asif.gestureai.accessibility.AccessibilityBridge
import com.asif.gestureai.eye.EyeTrackingState
import com.asif.gestureai.eye.GazeZone
import com.asif.gestureai.gesture.RecognizedGestureEvent
import com.asif.gestureai.settings.GestureAction
import com.asif.gestureai.settings.GestureType
import com.asif.gestureai.settings.ReelsModeSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ReelsRuntimeState(
    val active: Boolean = false,
    val selectedTargetAction: GestureAction = GestureAction.REELS_INTENTIONAL_LIKE,
    val lastTriggeredLabel: String = "Standby",
    val pausedByPalm: Boolean = false
)

/**
 * ASIF REELS MODE Controller:
 * Maps finger gestures and optional calibrated eye gaze zones to safe Reels navigation.
 *
 * Strict Safety Guarantees:
 * - Never auto-likes videos based on eye gaze alone.
 * - Like requires an intentional, user-configured gesture (Pinch) with cooldown.
 * - Does not automate follows, comments, or messages.
 */
class ReelsModeController {

    private val _state = MutableStateFlow(ReelsRuntimeState())
    val state: StateFlow<ReelsRuntimeState> = _state.asStateFlow()

    private var lastGazeScrollMs = 0L
    private var lastLikeMs = 0L

    fun setActive(active: Boolean) {
        _state.value = _state.value.copy(
            active = active,
            pausedByPalm = false,
            lastTriggeredLabel = if (active) "Reels Mode Armed" else "Stopped"
        )
    }

    fun handleGesture(
        event: RecognizedGestureEvent,
        settings: ReelsModeSettings,
        screenWidthPx: Int,
        screenHeightPx: Int
    ): String? {
        if (!settings.active) return null

        if (event.gesture == GestureType.OPEN_PALM) {
            val nextPaused = !_state.value.pausedByPalm
            _state.value = _state.value.copy(
                pausedByPalm = nextPaused,
                lastTriggeredLabel = if (nextPaused) "Paused via Open Palm" else "Resumed"
            )
            return _state.value.lastTriggeredLabel
        }

        if (_state.value.pausedByPalm) return null

        val mappedAction = when (event.gesture) {
            GestureType.SWIPE_UP -> settings.swipeUpAction
            GestureType.SWIPE_DOWN -> settings.swipeDownAction
            GestureType.PINCH -> settings.pinchAction
            GestureType.TWO_FINGER -> settings.twoFingerAction
            GestureType.THUMBS_UP -> settings.thumbsUpAction
            else -> return null
        }

        return executeReelsAction(mappedAction, event.timestampMs, screenWidthPx, screenHeightPx)
    }

    fun handleEyeGaze(
        eyeState: EyeTrackingState,
        settings: ReelsModeSettings,
        nowMs: Long
    ): String? {
        if (!settings.active || !settings.gazeScrollEnabled || _state.value.pausedByPalm) return null
        if (!eyeState.detected || eyeState.confidence < 0.55f) return null
        // Gaze scroll ONLY scrolls next/prev after intentional dwell; NEVER triggers Like!
        if (eyeState.dwellProgress < 0.98f || nowMs - lastGazeScrollMs < 2200L) return null

        val executed = when (eyeState.gazeZone) {
            GazeZone.DOWN -> {
                lastGazeScrollMs = nowMs
                AccessibilityBridge.performScroll(scrollDown = true)
                "Gaze Scroll: Next Video"
            }
            GazeZone.UP -> {
                lastGazeScrollMs = nowMs
                AccessibilityBridge.performScroll(scrollDown = false)
                "Gaze Scroll: Previous Video"
            }
            else -> null
        }
        if (executed != null) {
            _state.value = _state.value.copy(lastTriggeredLabel = executed)
        }
        return executed
    }

    private fun executeReelsAction(
        action: GestureAction,
        nowMs: Long,
        screenWidthPx: Int,
        screenHeightPx: Int
    ): String {
        val label = when (action) {
            GestureAction.REELS_NEXT, GestureAction.SCROLL_DOWN -> {
                AccessibilityBridge.performScroll(scrollDown = true)
                "Next Video"
            }
            GestureAction.REELS_PREVIOUS, GestureAction.SCROLL_UP -> {
                AccessibilityBridge.performScroll(scrollDown = false)
                "Previous Video"
            }
            GestureAction.REELS_PLAY_PAUSE -> {
                if (screenWidthPx > 0 && screenHeightPx > 0) {
                    AccessibilityBridge.performTap(screenWidthPx * 0.5f, screenHeightPx * 0.5f)
                }
                "Play / Pause"
            }
            GestureAction.REELS_INTENTIONAL_LIKE -> {
                if (nowMs - lastLikeMs >= 2000L && screenWidthPx > 0 && screenHeightPx > 0) {
                    lastLikeMs = nowMs
                    AccessibilityBridge.performDoubleTap(screenWidthPx * 0.5f, screenHeightPx * 0.48f)
                    "Intentional Like (Pinch)"
                } else {
                    "Like Cooldown Guard"
                }
            }
            GestureAction.REELS_COMMENTS -> {
                if (screenWidthPx > 0 && screenHeightPx > 0) {
                    AccessibilityBridge.performTap(screenWidthPx * 0.90f, screenHeightPx * 0.64f)
                }
                "Open Comments Zone"
            }
            GestureAction.REELS_PROFILE -> {
                if (screenWidthPx > 0 && screenHeightPx > 0) {
                    AccessibilityBridge.performTap(screenWidthPx * 0.16f, screenHeightPx * 0.80f)
                }
                "Open Profile Zone"
            }
            GestureAction.GLOBAL_BACK -> {
                AccessibilityBridge.performGlobalBack()
                "Back"
            }
            else -> action.displayName
        }
        _state.value = _state.value.copy(lastTriggeredLabel = label)
        return label
    }
}
