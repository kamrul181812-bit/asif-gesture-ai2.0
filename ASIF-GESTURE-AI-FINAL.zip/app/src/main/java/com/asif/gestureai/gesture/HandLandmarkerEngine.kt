package com.asif.gestureai.gesture

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import com.asif.gestureai.core.AppLogger
import com.asif.gestureai.core.CoordinateMapper
import com.asif.gestureai.core.UiState
import com.asif.gestureai.face.FacePoint
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

data class TrackedHand(
    val landmarks: List<FacePoint>, // 21 landmarks (0..20)
    val handedness: String,
    val confidence: Float
)

data class HandTrackingResult(
    val hands: List<TrackedHand> = emptyList(),
    val inferenceTimeMs: Long = 0L,
    /** Size of the UPRIGHT analysis image the normalized landmarks refer to (needed for FILL_CENTER mapping). */
    val imageWidth: Int = 0,
    val imageHeight: Int = 0
)

/**
 * Lifecycle-safe MediaPipe Hand Landmarker wrapper tracking 21 landmarks per hand.
 * Closes MPImage per frame in finally {} to prevent native memory growth in long sessions.
 */
class HandLandmarkerEngine(private val context: Context) {

    companion object {
        private const val TAG = "HandLandmarkerEngine"
        private const val MODEL_ASSET = "hand_landmarker.task"
    }

    private val _engineState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val engineState: StateFlow<UiState<String>> = _engineState.asStateFlow()

    private val _latestResult = MutableStateFlow(HandTrackingResult())
    val latestResult: StateFlow<HandTrackingResult> = _latestResult.asStateFlow()

    private val initAttempted = AtomicBoolean(false)
    @Volatile
    private var landmarker: HandLandmarker? = null
    private var lastMonotonicTimestampMs: Long = 0L

    @Synchronized
    fun ensureInitialized(maxHands: Int = 2): Boolean {
        if (landmarker != null) return true
        if (initAttempted.get() && _engineState.value is UiState.Error) return false
        initAttempted.set(true)
        _engineState.value = UiState.Loading

        return try {
            context.assets.open(MODEL_ASSET).close()

            val baseOptions = BaseOptions.builder()
                .setModelAssetPath(MODEL_ASSET)
                .setDelegate(Delegate.CPU)
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.VIDEO)
                .setNumHands(maxHands.coerceIn(1, 2))
                .setMinHandDetectionConfidence(0.55f)
                .setMinHandPresenceConfidence(0.55f)
                .setMinTrackingConfidence(0.55f)
                .build()

            landmarker = HandLandmarker.createFromOptions(context, options)
            _engineState.value = UiState.Success("Hand Landmarker Ready")
            AppLogger.i(TAG, "HandLandmarker initialized successfully.")
            true
        } catch (t: Throwable) {
            AppLogger.e(TAG, "HandLandmarker initialization failed", t)
            _engineState.value = UiState.Error(
                "Hand model unavailable (${t.localizedMessage ?: "missing or unsupported"}).",
                recoverable = true
            )
            false
        }
    }

    fun retryInitialization() {
        initAttempted.set(false)
        ensureInitialized()
    }

    @Synchronized
    fun processFrame(
        bitmap: Bitmap,
        rotationDegrees: Int,
        isFrontCamera: Boolean,
        timestampMs: Long,
        maxHandsLimit: Int = 2
    ): HandTrackingResult {
        if (bitmap.isRecycled) return HandTrackingResult()
        val instance = landmarker ?: if (ensureInitialized(maxHandsLimit)) landmarker else null
        if (instance == null) {
            return HandTrackingResult()
        }

        val start = SystemClock.elapsedRealtime()
        var mpImage: MPImage? = null
        return try {
            mpImage = BitmapImageBuilder(bitmap).build()
            val imageOptions = ImageProcessingOptions.builder()
                .setRotationDegrees(rotationDegrees)
                .build()

            val monotonicTs = max(timestampMs, lastMonotonicTimestampMs + 1L)
            lastMonotonicTimestampMs = monotonicTs

            val result = instance.detectForVideo(mpImage, imageOptions, monotonicTs)
            val elapsed = SystemClock.elapsedRealtime() - start

            val upW = CoordinateMapper.uprightWidth(bitmap.width, bitmap.height, rotationDegrees)
            val upH = CoordinateMapper.uprightHeight(bitmap.width, bitmap.height, rotationDegrees)
            val hands = result.landmarks().take(maxHandsLimit.coerceIn(1, 2)).mapIndexed { idx, lmList ->
                val handedness = result.handedness().getOrNull(idx)?.firstOrNull()
                val label = handedness?.categoryName() ?: "Hand"
                val score = handedness?.score() ?: 0.85f
                val pts = lmList.map { lm ->
                    val mx = CoordinateMapper.mirrorX(lm.x(), isFrontCamera)
                    FacePoint(x = mx.coerceIn(0f, 1f), y = lm.y().coerceIn(0f, 1f), z = lm.z())
                }
                TrackedHand(landmarks = pts, handedness = label, confidence = score)
            }

            val tracked = HandTrackingResult(hands = hands, inferenceTimeMs = elapsed, imageWidth = upW, imageHeight = upH)
            _latestResult.value = tracked
            tracked
        } catch (t: Throwable) {
            AppLogger.w(TAG, "Hand inference frame skipped", t)
            HandTrackingResult()
        } finally {
            runCatching { mpImage?.close() }
        }
    }

    fun clearResult() {
        _latestResult.value = HandTrackingResult()
    }

    @Synchronized
    fun close() {
        try {
            landmarker?.close()
        } catch (e: Exception) {
            AppLogger.w(TAG, "Error closing HandLandmarker", e)
        } finally {
            landmarker = null
            initAttempted.set(false)
            _engineState.value = UiState.Idle
            _latestResult.value = HandTrackingResult()
        }
    }
}
