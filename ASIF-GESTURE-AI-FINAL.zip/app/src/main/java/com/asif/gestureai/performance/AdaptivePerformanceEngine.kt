package com.asif.gestureai.performance

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import com.asif.gestureai.core.DeviceProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

enum class ThermalStateLabel(val label: String, val isWarning: Boolean) {
    NONE("Nominal", false),
    LIGHT("Warm", false),
    MODERATE("Elevated", true),
    SEVERE("Throttling", true),
    CRITICAL("Critical Heat", true),
    UNKNOWN("Unavailable", false)
}

data class PerformanceTelemetry(
    val mode: PerformanceMode = PerformanceMode.BALANCED,
    val adaptiveEnabled: Boolean = true,
    val thermalMonitoringEnabled: Boolean = true,
    val availableMemoryMb: Long = 0L,
    val totalMemoryMb: Long = 0L,
    val appUsedMemoryMb: Long = 0L,
    val lowMemoryWarning: Boolean = false,
    val thermalState: ThermalStateLabel = ThermalStateLabel.NONE,
    val cpuLoadEstimatePercent: Int = 0,
    val cameraFrameTimeMs: Long = 0L,
    val faceTrackingTimeMs: Long = 0L,
    val handTrackingTimeMs: Long = 0L,
    val effectiveFps: Float = 0f,
    val throttleFactor: Float = 1.0f, // 1.0 = normal, >1.0 = slowed down
    val prioritizeFaceOnly: Boolean = false,
    val reduceAnimations: Boolean = false,
    val pauseOptionalAi: Boolean = false,
    val warningMessage: String? = null
)

/**
 * Adaptive Performance Engine designed for extended-duration sessions on mid-range SoCs
 * (Symphony Inova 30: 6 GB RAM, 2.0 GHz Octa-Core, Mali-G57).
 *
 * Monitors available memory, process CPU time delta, thermal status, and per-pipeline latency.
 * Automatically scales down inference frequency and optional visual load before OOM or ANR occurs.
 */
class AdaptivePerformanceEngine(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager

    private val _telemetry = MutableStateFlow(PerformanceTelemetry())
    val telemetry: StateFlow<PerformanceTelemetry> = _telemetry.asStateFlow()

    private var monitorJob: Job? = null
    private var lastWallClockMs = SystemClock.elapsedRealtime()
    private var lastCpuTimeMs = Process.getElapsedCpuTime()

    private val frameTimestamps = ArrayDeque<Long>(32)

    fun startMonitoring() {
        if (monitorJob?.isActive == true) return
        lastWallClockMs = SystemClock.elapsedRealtime()
        lastCpuTimeMs = Process.getElapsedCpuTime()
        monitorJob = scope.launch {
            while (isActive) {
                sampleSystemMetrics()
                delay(1500L)
            }
        }
    }

    fun stopMonitoring() {
        monitorJob?.cancel()
        monitorJob = null
    }

    fun setMode(mode: PerformanceMode) {
        _telemetry.update {
            it.copy(
                mode = mode,
                reduceAnimations = mode == PerformanceMode.BATTERY_SAVER
            )
        }
        evaluateAdaptation()
    }

    fun setAdaptiveEnabled(enabled: Boolean) {
        _telemetry.update { it.copy(adaptiveEnabled = enabled) }
        evaluateAdaptation()
    }

    fun setThermalMonitoringEnabled(enabled: Boolean) {
        _telemetry.update { it.copy(thermalMonitoringEnabled = enabled) }
        evaluateAdaptation()
    }

    fun recordCameraFrame(frameDurationMs: Long) {
        val now = SystemClock.elapsedRealtime()
        synchronized(frameTimestamps) {
            frameTimestamps.addLast(now)
            while (frameTimestamps.size > 20 || (frameTimestamps.isNotEmpty() && now - frameTimestamps.first() > 2000L)) {
                frameTimestamps.removeFirst()
            }
        }
        val fps = synchronized(frameTimestamps) {
            if (frameTimestamps.size >= 2) {
                val spanMs = max(1L, frameTimestamps.last() - frameTimestamps.first())
                ((frameTimestamps.size - 1) * 1000f / spanMs)
            } else {
                0f
            }
        }
        _telemetry.update {
            it.copy(
                cameraFrameTimeMs = frameDurationMs,
                effectiveFps = (fps * 10f).roundToInt() / 10f
            )
        }
    }

    fun recordFaceLatency(durationMs: Long) {
        _telemetry.update { it.copy(faceTrackingTimeMs = durationMs) }
    }

    fun recordHandLatency(durationMs: Long) {
        _telemetry.update { it.copy(handTrackingTimeMs = durationMs) }
    }

    fun effectiveFaceIntervalMs(): Long {
        val t = _telemetry.value
        return (t.mode.faceIntervalMs * t.throttleFactor).toLong().coerceAtLeast(30L)
    }

    fun effectiveHandIntervalMs(): Long {
        val t = _telemetry.value
        val extra = if (t.prioritizeFaceOnly) 2.0f else 1.0f
        return (t.mode.handIntervalMs * t.throttleFactor * extra).toLong().coerceAtLeast(30L)
    }

    fun sampleSystemMetrics() {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memInfo)
        val availMb = memInfo.availMem / (1024L * 1024L)
        val totalMb = memInfo.totalMem / (1024L * 1024L)
        val runtime = Runtime.getRuntime()
        val appUsedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024L * 1024L)

        val nowWall = SystemClock.elapsedRealtime()
        val nowCpu = Process.getElapsedCpuTime()
        val wallDelta = max(1L, nowWall - lastWallClockMs)
        val cpuDelta = max(0L, nowCpu - lastCpuTimeMs)
        val cores = max(1, Runtime.getRuntime().availableProcessors())
        val cpuPct = ((cpuDelta.toFloat() / (wallDelta * cores)) * 100f).roundToInt().coerceIn(0, 100)
        lastWallClockMs = nowWall
        lastCpuTimeMs = nowCpu

        val thermalLabel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null && _telemetry.value.thermalMonitoringEnabled) {
            when (powerManager.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> ThermalStateLabel.NONE
                PowerManager.THERMAL_STATUS_LIGHT -> ThermalStateLabel.LIGHT
                PowerManager.THERMAL_STATUS_MODERATE -> ThermalStateLabel.MODERATE
                PowerManager.THERMAL_STATUS_SEVERE -> ThermalStateLabel.SEVERE
                PowerManager.THERMAL_STATUS_CRITICAL,
                PowerManager.THERMAL_STATUS_EMERGENCY,
                PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalStateLabel.CRITICAL
                else -> ThermalStateLabel.UNKNOWN
            }
        } else {
            ThermalStateLabel.UNKNOWN
        }

        _telemetry.update {
            it.copy(
                availableMemoryMb = availMb,
                totalMemoryMb = totalMb,
                appUsedMemoryMb = appUsedMb,
                lowMemoryWarning = memInfo.lowMemory || availMb in 1L..DeviceProfile.LOW_AVAILABLE_RAM_MB,
                thermalState = thermalLabel,
                cpuLoadEstimatePercent = cpuPct
            )
        }
        evaluateAdaptation()
    }

    private fun evaluateAdaptation() {
        val current = _telemetry.value
        if (!current.adaptiveEnabled) {
            _telemetry.update {
                it.copy(
                    throttleFactor = 1.0f,
                    prioritizeFaceOnly = false,
                    reduceAnimations = it.mode == PerformanceMode.BATTERY_SAVER,
                    pauseOptionalAi = false,
                    warningMessage = null
                )
            }
            return
        }

        val isCriticalMemory = current.availableMemoryMb in 1L..DeviceProfile.CRITICAL_AVAILABLE_RAM_MB
        val isLowMemory = current.lowMemoryWarning
        val isThermalSevere = current.thermalState == ThermalStateLabel.SEVERE || current.thermalState == ThermalStateLabel.CRITICAL
        val isThermalModerate = current.thermalState == ThermalStateLabel.MODERATE
        val isHighLatency = current.faceTrackingTimeMs + current.handTrackingTimeMs > 120L

        var throttle = 1.0f
        var prioritizeFace = false
        var reduceAnim = current.mode == PerformanceMode.BATTERY_SAVER
        var pauseOpt = false
        var warning: String? = null

        when {
            isCriticalMemory || current.thermalState == ThermalStateLabel.CRITICAL -> {
                throttle = 2.4f
                prioritizeFace = true
                reduceAnim = true
                pauseOpt = true
                warning = "Critical device load (${current.thermalState.label}, ${current.availableMemoryMb} MB free): AI frequency throttled to protect stability."
            }
            isThermalSevere || isLowMemory -> {
                throttle = 1.75f
                prioritizeFace = true
                reduceAnim = true
                warning = "System pressure detected (${current.thermalState.label}): prioritizing face tracking & reducing animations."
            }
            isThermalModerate || isHighLatency || current.cpuLoadEstimatePercent > 80 -> {
                throttle = 1.35f
                reduceAnim = true
                warning = "Adaptive load balancing active to keep frame latency smooth."
            }
        }

        _telemetry.update {
            it.copy(
                throttleFactor = throttle,
                prioritizeFaceOnly = prioritizeFace,
                reduceAnimations = reduceAnim,
                pauseOptionalAi = pauseOpt,
                warningMessage = warning
            )
        }
    }
}
