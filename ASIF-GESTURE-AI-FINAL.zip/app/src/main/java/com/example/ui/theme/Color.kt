package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBlack = Color(0xFF05080D)
val DeepSlate = Color(0xFF0A1019)
val GlassSurface = Color(0xCC0F1724)
val GlassSurfaceElevated = Color(0xE6152032)
val GlassBorder = Color(0x3300FF88)
val GlassBorderBlue = Color(0x3D00D4FF)

val NeonEmerald = Color(0xFF00FF88)
val NeonEmeraldDim = Color(0xFF00C96B)
val NeonEmeraldContainer = Color(0xFF082E1E)

val ElectricBlue = Color(0xFF00D4FF)
val ElectricBlueDim = Color(0xFF009EC2)
val ElectricBlueContainer = Color(0xFF072838)

val CyberAmber = Color(0xFFFFB800)
val CyberAmberContainer = Color(0xFF332500)
val AlertCrimson = Color(0xFFFF4D6D)
val AlertCrimsonContainer = Color(0xFF3A0C18)

val TextPrimary = Color(0xFFF2F7FA)
val TextSecondary = Color(0xFF9FB2C6)
val TextMuted = Color(0xFF63768C)
