package com.example

import android.Manifest
import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.asif.gestureai.core.AppLogger
import com.asif.gestureai.core.DeviceProfile
import com.asif.gestureai.ui.MainViewModel
import com.asif.gestureai.ui.navigation.AsifGestureAiRoot
import com.example.ui.theme.AsifGestureAiTheme
import java.lang.ref.WeakReference

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var activePreviewRef: WeakReference<PreviewView>? = null
    private var isInPipModeState by mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        viewModel.refreshPermissions()
        val camGranted = results[Manifest.permission.CAMERA] == true
        if (camGranted) {
            viewModel.startCamera(this, activePreviewRef?.get())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppLogger.i("MainActivity", "Launched on ${DeviceProfile.currentDeviceLabel()}")

        setContent {
            AsifGestureAiTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .then(if (isInPipModeState) Modifier else Modifier.statusBarsPadding())
                ) {
                    AsifGestureAiRoot(
                        viewModel = viewModel,
                        lifecycleOwner = this@MainActivity,
                        isInPipMode = isInPipModeState,
                        previewViewHolder = { pv -> activePreviewRef = pv?.let { WeakReference(it) } },
                        currentPreviewView = { activePreviewRef?.get() },
                        onRequestPermissions = ::requestCorePermissions,
                        onEnterPip = ::triggerPictureInPicture
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshPermissions()
    }

    override fun onDestroy() {
        activePreviewRef?.clear()
        activePreviewRef = null
        super.onDestroy()
    }

    private fun requestCorePermissions() {
        val perms = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }

    private fun triggerPictureInPicture() {
        if (!DeviceProfile.supportsPip()) return
        try {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(3, 4))
                .build()
            enterPictureInPictureMode(params)
        } catch (e: Exception) {
            AppLogger.w("MainActivity", "Picture-in-Picture unavailable on this device/state", e)
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isInPipModeState = isInPictureInPictureMode
    }
}
